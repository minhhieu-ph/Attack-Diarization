"""Run experiments on several GPUs at once: one process per GPU, one (dataset, seed) job
per process. Each process sees a single GPU through CUDA_VISIBLE_DEVICES, so no code
inside the package needs to know about multiple GPUs. Results go to the same
outputs/results/*.jsonl files; finished jobs are skipped on rerun.

Examples (8x A100):
  python scripts/run_multi_gpu.py --config configs/a100.yaml --exp E2 E4 E6 E7 E8
  python scripts/run_multi_gpu.py --config configs/a100.yaml --exp E2 --gpus 0,1,2,3 --seeds 0 1
  python scripts/run_multi_gpu.py --config configs/a100.yaml --pilot          # pilot per dataset

Prepare is run first (CPU, `--prep-jobs` datasets at a time). E3, the cross-dataset part
of E5 and the report need all seeds/datasets, so they run once at the end.
"""
import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from attackdiar.config import load_config  # noqa: E402

PER_JOB = {"E2", "E4", "E6", "E7", "E8"}   # can be split by (dataset, seed)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--config", action="append", default=[])
    p.add_argument("--set", action="append", default=[], dest="overrides")
    p.add_argument("--exp", nargs="*", default=["E2", "E4", "E6", "E7", "E8"])
    p.add_argument("--datasets", nargs="*", default=None)
    p.add_argument("--seeds", nargs="*", type=int, default=None)
    p.add_argument("--gpus", default=None, help="e.g. 0,1,2,3 (default: all visible)")
    p.add_argument("--prep-jobs", type=int, default=2, help="datasets prepared in parallel (RAM bound)")
    p.add_argument("--pilot", action="store_true", help="run scripts/feasibility.py per dataset instead")
    a = p.parse_args()

    cfg = load_config(a.config, a.overrides)
    datasets = a.datasets or cfg["data"]["datasets"]
    seeds = a.seeds if a.seeds is not None else cfg["seeds"]
    if a.gpus:
        gpus = a.gpus.split(",")
    else:
        out = subprocess.run(["nvidia-smi", "-L"], capture_output=True, text=True).stdout
        gpus = [str(i) for i in range(len([l for l in out.splitlines() if l.startswith("GPU")]))] or ["0"]
    common = sum((["--config", c] for c in a.config), []) + sum((["--set", o] for o in a.overrides), [])
    log_dir = ROOT / "outputs" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    print(f"GPUs {gpus} | datasets {datasets} | seeds {seeds}")

    # 1) prepare (CPU)
    if not a.pilot:
        run_pool([[sys.executable, "scripts/prepare.py", *common, "--datasets", d] for d in datasets],
                 [None] * a.prep_jobs, log_dir, "prepare")

    # 2) GPU jobs
    if a.pilot:
        jobs = [[sys.executable, "scripts/feasibility.py", *common, "--datasets", d, "--flowdiar"] for d in datasets]
    else:
        exps = [e.upper() for e in a.exp if e.upper() in PER_JOB]
        jobs = [[sys.executable, "scripts/run.py", *common, "--datasets", d, "--set", f"seeds=[{s}]",
                 "--exp", *exps, "--no-report"] for d in datasets for s in seeds] if exps else []
    run_pool(jobs, gpus, log_dir, "gpu")

    # 3) global steps
    if not a.pilot:
        final = [e.upper() for e in a.exp if e.upper() in {"E1", "E3", "E5"}]
        subprocess.run([sys.executable, "scripts/run.py", *common, "--exp", *final, "report"], cwd=ROOT, check=False)


def run_pool(cmds, slots, log_dir, tag):
    """Run commands with at most len(slots) at a time; a slot is a GPU id or None."""
    free = list(slots)
    running = {}
    queue = list(enumerate(cmds))
    failed = 0
    while queue or running:
        while queue and free:
            i, cmd = queue.pop(0)
            slot = free.pop(0)
            env = dict(os.environ)
            if slot is not None:
                env["CUDA_VISIBLE_DEVICES"] = slot
            log = open(log_dir / f"{tag}_{i:03d}.log", "w")
            print(f"[{tag}] start #{i} on {'GPU ' + slot if slot is not None else 'CPU'}: {' '.join(cmd[1:])}")
            running[subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)] = (i, slot, log)
        time.sleep(2)
        for proc in [pr for pr in running if pr.poll() is not None]:
            i, slot, log = running.pop(proc)
            log.close()
            free.append(slot)
            failed += proc.returncode != 0
            print(f"[{tag}] done  #{i} rc={proc.returncode} (log: outputs/logs/{tag}_{i:03d}.log)")
    if failed:
        print(f"[{tag}] {failed} job(s) failed - see the logs above")


if __name__ == "__main__":
    main()
