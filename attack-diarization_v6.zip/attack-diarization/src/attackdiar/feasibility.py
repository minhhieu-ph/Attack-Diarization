"""Pilot study: is the episode-level direction worth pursuing?

Short version of the H1 gate (E1-E3) with one seed and no hyper-parameter search, plus
one extra measurement that decides how strong the research story is:

  ORACLE = true flow labels + the B1 grouping rule (tau tuned on val).
  * oracle close to 1.0  -> grouping is easy once flows are labelled correctly; any gap of
                            B1 comes from per-flow mistakes (weaker story for an episode model)
  * oracle clearly < 1.0 -> even perfect flow labels + time-gap grouping gets boundaries or
                            attribution wrong: the episode problem exists on its own

Checks are reported as PASS / WARN / FAIL with a final GO / STOP / UNCLEAR.
"""
from __future__ import annotations

import copy

import numpy as np
import pandas as pd

from .config import output_dir
from .data.episodes import episodes_from_flow_labels
from .data.prepare import Dataset
from .metrics.episode import episode_metrics
from .metrics.errors import categorize, summarize
from .pipeline import run_flow_baselines, run_flowdiar
from .utils import LOG, save_json, to_set

PARTS = ("train", "val", "test")


def _oracle(cfg, parts):
    (_, _), (va, gva), (te, gte) = parts
    jacc = cfg["episodes"]["merge_victim_jaccard"]
    best_tau, best = None, -1.0
    for tau in cfg["post"]["sessionize"]["tau_grid_sec"]:
        eps, _ = episodes_from_flow_labels(va, va["attack"].to_numpy(), tau * 1000, jacc)
        f1 = episode_metrics(gva, eps, cfg["metrics"])["f1_macro"]
        if f1 > best:
            best_tau, best = tau, f1
    eps, _ = episodes_from_flow_labels(te, te["attack"].to_numpy(), best_tau * 1000, jacc)
    m = episode_metrics(gte, eps, cfg["metrics"], te)
    return m, best_tau, eps


def _overlap_stats(eps: pd.DataFrame):
    o = np.argsort(eps["t_start"].to_numpy())
    s, e = eps["t_start"].to_numpy()[o], eps["t_end"].to_numpy()[o]
    ov = np.zeros(len(eps), bool)
    for i in range(len(eps)):
        j = i + 1
        while j < len(eps) and s[j] <= e[i]:
            ov[i] = ov[j] = True
            j += 1
    return float(ov.mean()) if len(eps) else 0.0


def _gap(f1, attr):
    return 100 * (1 - min(f1, attr if attr == attr else 1.0))


def pilot_dataset(cfg: dict, name: str, seed: int = 0, with_flowdiar: bool = False,
                  models=("B1raw", "B1", "B2", "B7"), trials: int = 6):
    cfg = copy.deepcopy(cfg)
    cfg["tuning"]["enabled"] = trials > 0
    cfg["tuning"]["n_trials"] = trials
    ds = Dataset(cfg, name)
    checks = []

    def add(cid, title, status, value, note=""):
        checks.append({"check": cid, "noi_dung": title, "trang_thai": status, "gia_tri": value, "ghi_chu": note})

    # C1 ground truth independence
    indep = bool(ds.meta["gt_independent"])
    add("C1", "Ground truth độc lập với cách gom của B1", "PASS" if indep else "FAIL", ds.meta["gt_source"],
        "" if indep else "điền dataset/schedules/<tên>.csv rồi chạy lại prepare --force")

    # C2 sample size
    parts = [ds.part("temporal", p) for p in PARTS]
    n_eps = {p: len(parts[i][1]) for i, p in enumerate(PARTS)}
    per_cls_test = parts[2][1]["attack"].value_counts().to_dict()
    train_cls = set(parts[0][1]["attack"])
    unseen = sorted(set(per_cls_test) - train_cls)
    st = "PASS" if n_eps["test"] >= 20 else ("WARN" if n_eps["test"] >= 8 else "FAIL")
    add("C2", "Số đợt ở train/val/test", st, n_eps,
        f"test theo loại: {per_cls_test}" + (f"; loại không có ở train: {unseen}" if unseen else ""))

    # C3 overlap
    ov = _overlap_stats(ds.episodes)
    add("C3", "Tỉ lệ đợt chồng thời gian với đợt khác", "PASS" if ov >= 0.05 else "WARN", round(ov, 4),
        "" if ov >= 0.05 else "không kiểm được luận điểm đợt chồng nhau trên bộ này")

    # C4 attribution non-trivial
    att = set().union(*[to_set(a) for a in ds.episodes["attackers"]]) if len(ds.episodes) else set()
    add("C4", "Số IP tấn công khác nhau", "PASS" if len(att) >= 5 else "WARN", len(att),
        "" if len(att) >= 5 else "quy kết kẻ tấn công gần như hiển nhiên; split tách host không có ý nghĩa")
    adequate = {"chồng lấn": ov >= 0.05, "quy kết": len(att) >= 5, "cỡ mẫu": n_eps["test"] >= 20}

    # C5 oracle ceiling of the grouping rule
    om, otau, oeps = _oracle(cfg, parts)
    ocat = categorize(parts[2][1], oeps, cfg["metrics"])
    oshare = ocat["category"].value_counts(normalize=True).round(3).to_dict() if len(ocat) else {}
    add("C5", "Trần ORACLE: nhãn flow đúng + gom theo tau", "INFO",
        {"f1": round(om["f1_macro"], 4), "precision": round(om["precision_macro"], 4),
         "recall": round(om["recall_macro"], 4), "attr": round(om["attr_acc_macro"], 4), "tau_sec": otau,
         "loi_oracle": oshare},
        "oracle < 0.95: gom theo khoảng hở thời gian sai ngay cả khi nhãn flow đúng" if om["f1_macro"] < 0.95
        else "oracle cao: gom đợt dễ khi nhãn flow đúng; khoảng trống (nếu có) đến từ lỗi phân loại flow")

    # C6 baselines on the temporal split (XGB tuned; episode filter tuned on val)
    xgb_posts = {b: cfg["baselines"][b]["post"] for b in models if cfg["baselines"][b]["flow_model"] == "xgb"}
    rows = run_flow_baselines(cfg, "PILOT", name, parts, "xgb", xgb_posts, seed, "temporal")
    res = {r["model"]: r for r in rows}
    cand = {k: v for k, v in res.items() if k != "B1raw"}
    best = max(cand, key=lambda k: cand[k]["f1_macro"])
    bf1, battr = res[best]["f1_macro"], res[best]["attr_acc_macro"]
    ci = (res[best].get("f1_ci_low"), res[best].get("f1_ci_high"))
    for b, r in res.items():
        add(f"C6-{b}", f"{b} split thời gian", "INFO",
            {"f1": round(r["f1_macro"], 4), "f1_ci95": [round(r.get("f1_ci_low", float("nan")), 3),
                                                       round(r.get("f1_ci_high", float("nan")), 3)],
             "precision": round(r["precision_macro"], 4), "recall": round(r["recall_macro"], 4),
             "attr": round(r["attr_acc_macro"], 4), "flow_f1": round(r["flow_f1_macro"], 4),
             "post_params": r.get("post_params")},
            "không có bộ lọc đợt (chỉ để so sánh)" if b == "B1raw" else "")
    if "B1raw" in res and "B1" in res:
        add("C6-loc", "Tác dụng của bộ lọc đợt (B1 so với B1raw)", "INFO",
            round(100 * (res["B1"]["f1_macro"] - res["B1raw"]["f1_macro"]), 2), "điểm F1 đợt")

    # C7 host-disjoint split
    host = None
    hp = [ds.part("host", p) for p in PARTS] if "host" in ds.splits() else None
    if hp and len(hp[2][1]) and len(hp[0][1]):
        host = run_flow_baselines(cfg, "PILOT", name, hp, "xgb", {"B1": "sessionize"}, seed, "host")[0]
        add("C7", "B1 split tách host tấn công", "INFO",
            {"f1": round(host["f1_macro"], 4), "attr": round(host["attr_acc_macro"], 4)})
    else:
        add("C7", "B1 split tách host tấn công", "WARN", "không chạy được",
            f"chỉ có {len(att)} IP tấn công, không chia được train/val/test theo kẻ tấn công")

    # C8 error analysis of the best baseline
    from .pipeline import pred_path
    from .utils import load_df

    cat = categorize(parts[2][1], load_df(pred_path(cfg, "PILOT", name, "temporal", best, seed)), cfg["metrics"])
    err = summarize(cat)
    share = cat["category"].value_counts(normalize=True).round(3).to_dict() if len(cat) else {}
    add("C8", f"Phân loại lỗi của {best} (theo đợt thật)", "INFO", share)

    # C9 optional quick FlowDiar
    fd = None
    if with_flowdiar:
        try:
            fd = run_flowdiar(cfg, "PILOT", name, parts, seed, "temporal", save_model=False)
            add("C9", "FlowDiar nhanh (1 seed)", "INFO",
                {"f1": round(fd["f1_macro"], 4), "precision": round(fd["precision_macro"], 4),
                 "recall": round(fd["recall_macro"], 4), "attr": round(fd["attr_acc_macro"], 4),
                 "diff_vs_best_points": round(100 * (fd["f1_macro"] - bf1), 2)})
        except ImportError as e:
            add("C9", "FlowDiar nhanh", "WARN", "bỏ qua", f"thiếu thư viện: {e}")

    # verdict
    g = cfg["gate"]
    gap_t = _gap(bf1, battr)
    gap_h = _gap(host["f1_macro"], host["attr_acc_macro"]) if host else float("nan")
    gap = max(gap_t, gap_h if gap_h == gap_h else 0.0)
    missing = [k for k, ok in adequate.items() if not ok]
    if not indep:
        verdict = "KHÔNG KẾT LUẬN ĐƯỢC: ground truth là heuristic"
    elif n_eps["test"] < 8:
        verdict = "KHÔNG ĐỦ DỮ LIỆU: quá ít đợt ở test"
    elif gap < 5:
        verdict = f"STOP trên bộ này: baseline mạnh (đã lọc) chỉ còn kém {gap:.1f} điểm"
    elif gap < g["go_gap_points"]:
        verdict = f"CHƯA RÕ: khoảng trống {gap:.1f} điểm, dưới ngưỡng {g['go_gap_points']}"
    elif missing:
        verdict = (f"GO CÓ ĐIỀU KIỆN: còn {gap:.1f} điểm, nhưng bộ này không kiểm được: {', '.join(missing)} "
                   f"-> cần thêm bộ dữ liệu khác")
    else:
        verdict = f"GO: còn khoảng trống {gap:.1f} điểm"
    if ci[0] is not None and ci[0] == ci[0]:
        verdict += f"; F1 baseline tốt nhất {bf1:.3f}, CI95 [{ci[0]:.3f}, {ci[1]:.3f}]"
    if fd is not None:
        d = 100 * (fd["f1_macro"] - bf1)
        verdict += f"; FlowDiar nhanh {'hơn' if d >= 0 else 'kém'} baseline {abs(d):.1f} điểm"
    out = {"dataset": name, "verdict": verdict, "best_baseline": best, "gap_temporal_points": gap_t,
           "gap_host_points": gap_h, "oracle_f1": om["f1_macro"], "adequate": adequate, "checks": checks,
           "errors_by_class": err.to_dict(orient="records") if len(err) else []}
    save_json(out, output_dir(cfg) / "feasibility" / f"{name}.json")
    LOG.info("[%s] %s", name, verdict)
    return out


def write_summary(cfg: dict, results: list[dict]) -> str:
    lines = ["# Kết quả thử khả thi (pilot)", ""]
    lines += ["| Bộ dữ liệu | Kết luận | Baseline tốt nhất | Khoảng trống (thời gian / tách host) | Trần oracle F1 |",
              "|---|---|---|---|---|"]
    for r in results:
        gh = r["gap_host_points"]
        lines.append(f"| {r['dataset']} | {r['verdict']} | {r['best_baseline']} | "
                     f"{r['gap_temporal_points']:.1f} / {'-' if gh != gh else f'{gh:.1f}'} | {r['oracle_f1']:.3f} |")
    for r in results:
        lines += ["", f"## {r['dataset']}", "", "| Mã | Nội dung | Trạng thái | Giá trị | Ghi chú |", "|---|---|---|---|---|"]
        for c in r["checks"]:
            lines.append(f"| {c['check']} | {c['noi_dung']} | {c['trang_thai']} | {c['gia_tri']} | {c['ghi_chu']} |")
    lines += ["", "Cách đọc: khoảng trống = 100 x (1 - min(F1 đợt, quy kết)) của baseline tốt nhất ĐÃ có bộ lọc đợt.",
              "STOP < 5 điểm, CHƯA RÕ 5-10, GO >= 10. GO CÓ ĐIỀU KIỆN khi bộ dữ liệu thiếu chồng lấn, thiếu kẻ tấn công",
              "hoặc thiếu đợt để kiểm các luận điểm. Trần oracle cho biết khó khăn nằm ở gom đợt hay ở phân loại flow."]
    text = "\n".join(lines)
    p = output_dir(cfg) / "feasibility" / "summary.md"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text)
    return text
