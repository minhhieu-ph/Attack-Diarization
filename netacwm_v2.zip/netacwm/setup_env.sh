#!/usr/bin/env bash
# Set up the Python environment. Works with an existing conda install; it never installs conda.
# If the "attackdiar" env from the previous project exists, reuse it:
#   conda activate attackdiar && USE_CURRENT_ENV=1 bash setup_env.sh
#
#   bash setup_env.sh                      # create/update a conda env "netacwm"
#   USE_CURRENT_ENV=1 bash setup_env.sh    # install into the env that is active now (no new env)
#   ENV_NAME=myenv bash setup_env.sh       # create/update an env with another name
#   TORCH_CUDA=cu126 bash setup_env.sh     # force a torch wheel: cu130 cu128 cu126 cu118 cpu
#   FORCE_TORCH=1 ...                      # reinstall torch even if a working CUDA torch exists
#
# Torch wheel choice (from the CUDA version nvidia-smi reports):
#   >= 13.0 -> cu130 | 12.8-12.9 -> cu128 | 12.0-12.7 -> cu126 | 11.x -> cu118 (torch 2.7.1)
#   A100 (sm_80) works with all of them; B300 (Blackwell) needs >= cu128.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

if [[ "${USE_CURRENT_ENV:-0}" == "1" ]]; then
  echo "[setup] installing into the current environment: $(command -v python)"
  python -m pip install -r requirements.txt
else
  ENV_NAME="${ENV_NAME:-netacwm}"
  if command -v mamba >/dev/null 2>&1; then CONDA=mamba
  elif command -v conda >/dev/null 2>&1; then CONDA=conda
  else
    echo "[setup] conda not found. Either activate a Python env and run: USE_CURRENT_ENV=1 bash setup_env.sh"
    echo "        or install Miniforge (https://github.com/conda-forge/miniforge)."
    exit 1
  fi
  if conda env list | awk '{print $1}' | grep -qx "$ENV_NAME"; then
    echo "[setup] updating existing env $ENV_NAME"
    $CONDA env update -n "$ENV_NAME" -f environment.yml
  else
    echo "[setup] creating env $ENV_NAME"
    $CONDA env create -n "$ENV_NAME" -f environment.yml
  fi
  # shellcheck disable=SC1091
  source "$(conda info --base)/etc/profile.d/conda.sh"
  conda activate "$ENV_NAME"
fi

# ---- PyTorch -----------------------------------------------------------------
if [[ "${FORCE_TORCH:-0}" != "1" ]] && python -c "import torch,sys; sys.exit(0 if torch.cuda.is_available() else 1)" 2>/dev/null; then
  echo "[setup] keeping existing torch $(python -c 'import torch;print(torch.__version__)') (CUDA works). FORCE_TORCH=1 to reinstall."
else
  TORCH_SPEC="torch>=2.8"
  if [[ -z "${TORCH_CUDA:-}" ]]; then
    if command -v nvidia-smi >/dev/null 2>&1; then
      CUDA_VER="$(nvidia-smi | grep -oP 'CUDA Version:\s*\K[0-9]+\.[0-9]+' | head -1 || true)"
      GPU="$(nvidia-smi --query-gpu=name --format=csv,noheader | head -1 || true)"
      echo "[setup] GPU=${GPU:-?} driver CUDA=${CUDA_VER:-?} count=$(nvidia-smi -L | wc -l)"
      MAJOR="${CUDA_VER%%.*}"; MINOR="${CUDA_VER#*.}"
      if   [[ "$MAJOR" -ge 13 ]]; then TORCH_CUDA=cu130
      elif [[ "$MAJOR" -eq 12 && "$MINOR" -ge 8 ]]; then TORCH_CUDA=cu128
      elif [[ "$MAJOR" -eq 12 ]]; then TORCH_CUDA=cu126
      elif [[ "$MAJOR" -eq 11 ]]; then TORCH_CUDA=cu118
      else TORCH_CUDA=cu126
      fi
    else
      TORCH_CUDA=cpu
    fi
  fi
  [[ "$TORCH_CUDA" == "cu118" ]] && TORCH_SPEC="torch==2.7.1"
  echo "[setup] installing $TORCH_SPEC from wheel index $TORCH_CUDA"
  python -m pip install --upgrade "$TORCH_SPEC" --index-url "https://download.pytorch.org/whl/${TORCH_CUDA}"
fi

python -m pip install -e . --no-deps
python scripts/check_env.py
echo "[setup] done."
