"""End-to-end E0 on a small synthetic stream (CPU, sklearn/PCA fallbacks are fine)."""
import numpy as np

from netacwm.config import load_config
from netacwm.e0 import SCORERS, Stream, run_one
from netacwm.synth import make_synth


def test_e0_on_synthetic(tmp_path):
    raw = tmp_path / "dataset" / "raw" / "synth_nf"
    raw.mkdir(parents=True)
    make_synth(30_000, seed=1).to_csv(raw / "synth.csv", index=False)
    cfg = load_config(["configs/smoke.yaml"], [
        f"paths.data_roots=[{tmp_path / 'dataset'}]", f"paths.output_dir={tmp_path / 'out'}",
        "models.regressor.n_estimators=60", "models.iforest.n_estimators=50", "eval.bootstrap=10",
        "compute.n_jobs=2"])
    st = Stream(cfg, "synth_nf")
    res = run_one(cfg, st, "default", 0, "cpu")
    assert set(SCORERS) <= set(res["metrics"])
    assert res["h1"]["r2_gain"] > 0.1                 # the reply depends on the request
    cons = res["metrics"]["s_C"]["consequence"]
    assert cons["n_attack"] > 0 and cons["tpr@0.01"] > 0.5
    assert np.isfinite(res["h2"]["diff"])
