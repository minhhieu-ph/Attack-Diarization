"""End-to-end v2 shift experiments on small synthetic networks (CPU fallbacks)."""
import numpy as np

from netacwm.config import load_config
from netacwm.e0 import Stream
from netacwm.shift import run_cross, run_time, time_targets
from netacwm.shift_report import write_shift_summary
from netacwm.synth import make_synth
from netacwm.utils import save_json


def _cfg(tmp_path):
    envs = {"sa": dict(days=3, seed=21), "sb": dict(days=3, seed=22, n_clients=25, size_scale=1.5, subnet="172.16",
                                                     probs=[0.15, 0.45, 0.15, 0.15, 0.05, 0.05]),
            "sc": dict(days=3, seed=23, law={"http": 4.0, "https": 0.3, "dns": 2.0}, subnet="192.168")}
    for name, kw in envs.items():
        raw = tmp_path / "dataset" / "raw" / name
        raw.mkdir(parents=True)
        make_synth(24_000, **kw).to_csv(raw / f"{name}.csv", index=False)
    return load_config(["configs/smoke_shift.yaml"], [
        f"paths.data_roots=[{tmp_path / 'dataset'}]", f"paths.output_dir={tmp_path / 'out'}",
        "models.regressor.n_estimators=40", "models.iforest.n_estimators=30", "models.ae.epochs=2",
        "eval.bootstrap=5", "compute.n_jobs=2", "shift.calib_min_flows=1500", "shift.time.datasets=[sa]",
        "shift.cross.datasets=[sa, sb, sc]", "shift.onboard.enabled=true", "shift.onboard.sizes_sec=[14400]",
        "shift.min_scratch_rows=300"])


def test_time_and_cross_shift(tmp_path):
    cfg = _cfg(tmp_path)
    streams = {d: Stream(cfg, d) for d in ("sa", "sb", "sc")}
    segs, targets = time_targets(cfg, streams["sa"])
    assert len(targets) == 2
    r = run_time(cfg, streams["sa"], targets[0], segs, "strict", 0, "cpu")
    assert set(r["arms"]) == {"fresh", "stale"}
    assert r["arms"]["fresh"]["h1"]["r2_cond_median"] > 0.8
    assert np.isfinite(r["h2"]["fresh/s_max|all"]["diff"])
    save_json(r, tmp_path / "out" / "shift" / "time" / "sa" / r["segment"]["label"] / "strict_seed0.json")

    c = run_cross(cfg, streams, "sa", "strict", 0, "cpu")
    arms = set(c["arms"])
    assert {"loc", "src:sb", "src:sc", "src:sb+sc", "scr3600", "ft14400", "scr14400"} <= arms
    for a in ("loc", "src:sb", "src:sc"):
        assert {"s_C", "s_C_mech", "s_C_content", "s_A", "s_max"} <= set(c["arms"][a]["metrics"])
    # the network with the same consequence law transfers; the one with a different law does not
    sb = c["arms"]["src:sb"]["h1"]["r2_cond_median"]
    sc = c["arms"]["src:sc"]["h1"]["r2_cond_median"]
    assert sb > 0.9 and sb - sc > 0.1
    assert c["h2"]["src:sb|s_max|all"]["best"].endswith(("AE_conf", "IF_conf"))
    save_json(c, tmp_path / "out" / "shift" / "cross" / "sa" / "strict_seed0.json")

    text = write_shift_summary(tmp_path / "out" / "shift", cfg).read_text()
    for s in ("G1 sa", "H1-T", "H2-T", "C3-T", "đường cong làm quen"):
        assert s in text
