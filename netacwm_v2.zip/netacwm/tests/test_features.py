import numpy as np

from netacwm.features import causal_context, delayed_consequence
from netacwm.schema import DROPPED, family_of, get_profile


def test_context_counts_and_gap():
    # host 0 sends at 0s, 5s, 30s; host 1 sends at 6s
    t = np.array([0, 5000, 6000, 30000], dtype=np.int64)
    src = np.array([0, 0, 1, 0])
    dst = np.array([2, 2, 2, 3])
    X, names = causal_context(t, src, dst, [10])
    col = {n: X[:, i] for i, n in enumerate(names)}
    assert np.allclose(np.expm1(col["ctx_src_n10s"]), [0, 1, 0, 0])
    assert np.allclose(np.expm1(col["ctx_dst_n10s"]), [0, 1, 2, 0])
    assert np.allclose(np.expm1(col["ctx_pair_n10s"]), [0, 1, 0, 0])
    assert np.isclose(np.expm1(col["ctx_src_gap"][1]), 5.0)


def test_delayed_consequence_counts_flows_started_by_destination():
    # flow 0: host 0 -> host 1 ends at 1s; host 1 then opens flows at 2s and 100s
    t = np.array([0, 2000, 100000], dtype=np.int64)
    t_end = np.array([1000, 2500, 100500], dtype=np.int64)
    src, dst = np.array([0, 1, 1]), np.array([1, 5, 6])
    sent = np.array([10.0, 300.0, 50.0])
    X, _ = delayed_consequence(t, t_end, src, dst, sent, 60)
    assert np.isclose(np.expm1(X[0, 0]), 1)          # only the flow at 2s is within 60s
    assert np.isclose(np.expm1(X[0, 1]), 300)


def test_profiles_keep_action_and_consequence_apart():
    for name in ("default", "strict"):
        p = get_profile(name)
        a = set(p.action_num + p.action_flags + p.action_cat)
        c = set(p.conseq_num + p.conseq_flags)
        assert not (a & c)
        assert not (a | c) & set(DROPPED)
    assert "L7_PROTO" not in get_profile("strict").action_cat


def test_families():
    fam = {"consequence": ["backdoor", "bot", "infilt", "theft"], "action": ["scan", "dos", "brute", "password"]}
    assert family_of("Benign", fam) == "benign"
    assert family_of("Bot", fam) == "consequence"
    assert family_of("DDoS attacks-LOIC-HTTP", fam) == "action"
    assert family_of("Brute Force -XSS", fam) == "action"
    assert family_of("Exploits", fam) == "mixed"
