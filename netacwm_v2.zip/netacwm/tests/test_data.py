"""The processed format of the attack-diarization project and the raw UQ CSV give the same table."""
import numpy as np
import pandas as pd

from netacwm.config import load_config
from netacwm.data import load_flows
from netacwm.schema import NEEDED
from netacwm.synth import make_synth


def _processed_like(raw: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame({
        "t_start": raw["FLOW_START_MILLISECONDS"], "t_end": raw["FLOW_END_MILLISECONDS"],
        "src_ip": raw["IPV4_SRC_ADDR"], "dst_ip": raw["IPV4_DST_ADDR"], "src_port": raw["L4_SRC_PORT"],
        "dst_port": raw["L4_DST_PORT"], "protocol": raw["PROTOCOL"], "label": raw["Label"],
        "attack": raw["Attack"],
    })
    for c in raw.columns:
        if c not in {"IPV4_SRC_ADDR", "IPV4_DST_ADDR", "L4_SRC_PORT", "FLOW_START_MILLISECONDS",
                     "FLOW_END_MILLISECONDS", "Label", "Attack"}:
            out["f_" + c.lower()] = raw[c].astype("float32")
    return out


def test_processed_and_raw_agree(tmp_path):
    raw = make_synth(5000, seed=3)
    (tmp_path / "a" / "raw" / "x").mkdir(parents=True)
    raw.to_csv(tmp_path / "a" / "raw" / "x" / "x.csv", index=False)
    (tmp_path / "b" / "processed" / "x").mkdir(parents=True)
    _processed_like(raw).to_pickle(tmp_path / "b" / "processed" / "x" / "flows.pkl")
    a = load_flows(load_config(None, [f"paths.data_roots=[{tmp_path / 'a'}]", f"paths.output_dir={tmp_path / 'oa'}"]), "x")
    b = load_flows(load_config(None, [f"paths.data_roots=[{tmp_path / 'b'}]", f"paths.output_dir={tmp_path / 'ob'}"]), "x")
    assert len(a) == len(b)
    for c in ["t", "t_end", "label", "src", "dst"] + [c for c in NEEDED if c in a.columns]:
        assert np.allclose(a[c].values.astype(float), b[c].values.astype(float)), c
    assert (a["attack"].astype(str).values == b["attack"].astype(str).values).all()
