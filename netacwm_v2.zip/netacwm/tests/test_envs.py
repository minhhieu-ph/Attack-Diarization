import numpy as np
import pandas as pd

from netacwm.envs import plan_target, segments, window_after, window_before
from netacwm.features import CtxNorm, _port_codes, n_port_codes
from netacwm.schema import WELL_KNOWN_PORTS, target_category

DAY = 86_400_000


def _table():
    # 3 days, benign every minute 08:00-18:00 local (UTC-5), one attack burst per day at noon
    t, lab, att = [], [], []
    for d in range(3):
        base = d * DAY + 5 * 3_600_000        # local midnight = 05:00 UTC
        for m in range(8 * 60, 18 * 60):
            t.append(base + m * 60_000)
            lab.append(0)
            att.append("Benign")
        for k in range(30):
            t.append(base + 12 * 3_600_000 + k * 1000 + 7)
            lab.append(1)
            att.append(f"atk{d}")
    o = np.argsort(t, kind="stable")
    return pd.DataFrame({"t": np.array(t)[o], "label": np.array(lab)[o], "attack": np.array(att)[o]})


def test_segments_by_local_day_and_gap():
    df = _table()
    s = segments(df["t"].values, df["label"].values, df["attack"].values, "day", -5)
    assert [x.n_benign for x in s] == [600, 600, 600] and [x.n_attack for x in s] == [30, 30, 30]
    assert s[1].attacks == {"atk1": 30}
    g = segments(df["t"].values, df["label"].values, df["attack"].values, "gap", 0, gap_hours=3)
    assert len(g) == 3


def test_windows():
    df = _table()
    t, lab = df["t"].values, df["label"].values
    start = DAY + 5 * 3_600_000 + 8 * 3_600_000          # day 1, 08:00 local
    rows, end = window_after(t, lab, start, 3600, 0)
    assert len(rows) == 60 and end == start + 3_600_000
    rows, end = window_after(t, lab, start, 3600, 100)     # extended to 100 flows
    assert len(rows) == 100 and end > start + 3_600_000
    before = window_before(t, lab, start, 3600, 0)         # previous evening: nothing within 1 h
    assert len(before) == 0
    before = window_before(t, lab, start, 3600, 50)        # extended back into day 0
    assert len(before) == 50 and t[before].max() < start


def test_plan_target_keeps_test_after_calibration():
    df = _table()
    s = segments(df["t"].values, df["label"].values, df["attack"].values, "day", -5)
    scfg = {"calib_sec": 3600, "calib_min_flows": 0}
    plan = plan_target(df, s[1].t0, scfg, np.random.default_rng(0), t_stop=s[1].t1, t_start=s[1].t0, stale=True)
    tt = df["t"].values
    assert len(plan.cal_fit) + len(plan.cal_ref) == 60
    test_b = plan.test[df["label"].values[plan.test] == 0]
    assert tt[test_b].min() >= plan.cal_end and tt[test_b].max() <= s[1].t1
    assert set(df["attack"].values[plan.test[df["label"].values[plan.test] == 1]]) == {"atk1"}
    assert tt[plan.history].max() < s[1].t0 and len(plan.history) == 600
    assert tt[np.r_[plan.stale_fit, plan.stale_ref]].max() < s[1].t0


def test_port_buckets_are_the_same_for_every_network():
    top = [float(p) for p in WELL_KNOWN_PORTS]
    v = np.array([80.0, 445.0, 999.0, 3000.0, 60000.0])
    c = _port_codes(v, top)
    assert c[0] == WELL_KNOWN_PORTS.index(80) and c[1] == WELL_KNOWN_PORTS.index(445)
    assert list(c[2:]) == [len(top), len(top) + 1, len(top) + 2]
    assert n_port_codes({"L4_DST_PORT": top}) == len(top) + 3


def test_ctx_norm_aligns_scales_and_keeps_order():
    rng = np.random.default_rng(0)
    small = np.log1p(rng.poisson(3, size=(5000, 1)).astype(float))
    big = np.log1p(rng.poisson(300, size=(5000, 1)).astype(float))
    qs, qb = CtxNorm("quantile").fit(small), CtxNorm("quantile").fit(big)
    assert abs(np.median(qs.transform(small)) - np.median(qb.transform(big))) < 0.05
    x = np.array([[0.0], [np.log1p(3)], [np.log1p(50)], [np.log1p(5000)]])
    z = qs.transform(x)[:, 0]
    assert np.all(np.diff(z) > 0) and z[-1] > 1.0          # beyond the reference: still ordered
    assert np.allclose(CtxNorm("none").fit(small).transform(x), x)


def test_target_categories():
    assert target_category("c_sflag_RST") == "mechanics"
    assert target_category("c_out_pkts") == "mechanics"
    assert target_category("c_out_bytes") == "content"
    assert target_category("c_dst_to_src_iat_avg") == "timing"
    assert target_category("c_retransmitted_out_pkts") == "netcond"
    assert target_category("c2_dst_new_flows") == "delayed"
