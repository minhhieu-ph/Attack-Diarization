import numpy as np

from netacwm.metrics import tpr_at_fpr
from netacwm.scoring import MondrianConformal, ResidualScorer


def test_mondrian_conformal_controls_fpr_per_group():
    rng = np.random.default_rng(0)
    # two groups with very different score scales: a global threshold would hit group 1 hard
    ref_g = np.r_[np.zeros(5000, int), np.ones(5000, int)]
    ref = np.r_[rng.normal(0, 1, 5000), rng.normal(0, 5, 5000)]
    test_g = np.r_[np.zeros(20000, int), np.ones(20000, int)]
    test = np.r_[rng.normal(0, 1, 20000), rng.normal(0, 5, 20000)]
    conf = MondrianConformal().fit(ref, ref_g, min_group=100)
    alpha = 0.01
    s = conf.score(test, test_g)
    for g in (0, 1):
        fpr = np.mean(s[test_g == g] > -np.log(alpha))
        assert fpr < alpha * 1.5, (g, fpr)


def test_residual_scorer_flags_large_residuals():
    rng = np.random.default_rng(1)
    R_fit, R_ref = rng.normal(0, 1, (4000, 5)), rng.normal(0, 1, (4000, 5))
    g_fit, g_ref = rng.integers(0, 3, 4000), rng.integers(0, 3, 4000)
    sc = ResidualScorer().fit(R_fit, g_fit, R_ref, g_ref, min_group=200)
    benign = rng.normal(0, 1, (5000, 5))
    attack = rng.normal(0, 1, (500, 5))
    attack[:, 0] += 6
    gb, ga = rng.integers(0, 3, 5000), rng.integers(0, 3, 500)
    assert tpr_at_fpr(sc.score(benign, gb), sc.score(attack, ga), 0.01) > 0.9
