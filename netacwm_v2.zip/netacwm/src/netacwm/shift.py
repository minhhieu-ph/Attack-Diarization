"""v2: does the consequence law learned on one environment hold in another?

Two experiments share the code below.

time   (step 1, gate G1) one dataset split into capture days. For each target day the world model
       is trained on the benign flows of all EARLIER days, then calibrated (C3) either on the first
       hour of the target day ("fresh") or on the last hour before it ("stale", what E0 did).
cross  (step 2) one dataset is the target network, the others are sources. Arms:
         src:<A>       trained on benign flows of network A only (zero-shot transfer)
         src:<A>+<B>   trained on several other networks (leave-one-out)
         loc           trained on the target's own history (in-domain reference)
         scr<k>        trained from scratch on the k seconds of target benign before the cut
                       (scr<calib_sec> is the "just train on the local window" baseline)
         ft<k>         (step 3, onboarding) the leave-one-out model fine-tuned on those k seconds
       Every arm is calibrated on the SAME target window W_cal and tested on the same flows.

Scorers per arm (higher = more anomalous):
  s_C          conditional surprise over all consequence targets (conformal per service group)
  s_C_mech     only the protocol-mechanics targets (server flags, reply packets)
  s_C_content  only the content targets (reply bytes, throughput)
  s_A          action novelty (autoencoder over context + action)
  s_max        max(s_C, s_A): the full detector
  AE_conf, IF_conf   unconditional baselines over context + action + consequence
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from . import __version__
from .e0 import Stream
from .envs import cap, plan_target, segments
from .features import PORT_BUCKETS, CtxNorm, Matrices, build, fit_vocab, n_port_codes
from .metrics import bootstrap_tpr_diff, pr_auc, r2_per_target, roc_auc, tpr_at_fpr
from .models import Autoencoder, IForest, MultiRegressor
from .schema import PROTOCOLS, get_profile, target_category
from .scoring import MondrianConformal, ResidualScorer
from .utils import LOG, check_memory, save_json, set_seed, timer

GROUPS = ["all", "consequence", "action", "mixed"]
SUBSETS = {"s_C": None, "s_C_mech": "mechanics", "s_C_content": "content"}


# ---------------------------------------------------------------- matrices
def mats(st: Stream, rows: np.ndarray, vocab: dict, prof, norm: CtxNorm) -> Matrices:
    m = build(st.df, rows, st.ctx, st.ctx_names, st.c2, st.c2_names, vocab, prof)
    m.ctx = norm.transform(m.ctx)
    return m


def take(m: Matrices, idx: np.ndarray) -> Matrices:
    return Matrices(m.rows[idx], m.ctx[idx], m.act[idx], m.y[idx], m.group[idx], m.names_ctx, m.names_act, m.names_y)


def concat(ms: list[Matrices], rng=None) -> Matrices:
    """Stack matrices of several environments; shuffled so that early stopping validates on all."""
    out = Matrices(np.concatenate([m.rows for m in ms]), np.vstack([m.ctx for m in ms]), np.vstack([m.act for m in ms]),
                   np.vstack([m.y for m in ms]), np.concatenate([m.group for m in ms]), ms[0].names_ctx,
                   ms[0].names_act, ms[0].names_y)
    if rng is not None and len(ms) > 1:
        out = take(out, rng.permutation(len(out.rows)))
    return out


def xa(m: Matrices) -> np.ndarray:
    return np.hstack([m.ctx, m.act])


def group_label(g: int, vocab: dict) -> str:
    ports = vocab.get("L4_DST_PORT", [])
    n_port = n_port_codes(vocab)
    pr, pc = divmod(int(g), n_port)
    protos = vocab.get("PROTOCOL", PROTOCOLS)
    proto = {6: "tcp", 17: "udp", 1: "icmp"}.get(int(protos[pr]), str(protos[pr])) if pr < len(protos) else "other"
    port = str(int(ports[pc])) if pc < len(ports) else PORT_BUCKETS[pc - len(ports)]
    return f"{proto}/{port}"


# ---------------------------------------------------------------- arms
@dataclass
class Arm:
    name: str
    active: np.ndarray            # boolean mask over all consequence targets
    cond: MultiRegressor
    ctxonly: MultiRegressor | None
    ae_act: Autoencoder
    ae_full: Autoencoder | None
    iforest: IForest | None
    n_train: int

    def Y(self, m: Matrices) -> np.ndarray:
        return m.y[:, self.active]


def train_arm(name: str, m: Matrices, cfg: dict, device: str, seed: int, n_jobs: int,
              with_ctx: bool = True, with_baselines: bool = True) -> Arm:
    active = m.y.std(0) > 1e-6
    Y = m.y[:, active]
    X = xa(m)
    rc, ac = cfg["models"]["regressor"], cfg["models"]["ae"]
    with timer(f"[{name}] regressor context+action ({len(X):,} rows)"):
        cond = MultiRegressor(rc, device, seed, n_jobs).fit(X, Y)
    ctxonly = None
    if with_ctx:
        with timer(f"[{name}] regressor context only"):
            ctxonly = MultiRegressor(rc, device, seed, n_jobs).fit(m.ctx, Y)
    with timer(f"[{name}] autoencoder context+action (s_A)"):
        ae_act = Autoencoder(ac, device, seed).fit(X)
    ae_full = iff = None
    if with_baselines:
        F = np.hstack([X, Y])
        with timer(f"[{name}] baselines AE + IF"):
            ae_full = Autoencoder(ac, device, seed).fit(F)
            iff = IForest(cfg["models"]["iforest"], seed, n_jobs).fit(F)
    return Arm(name, active, cond, ctxonly, ae_act, ae_full, iff, len(X))


def finetune_arm(base: Arm, name: str, m: Matrices, ocfg: dict) -> Arm:
    X, Y = xa(m), base.Y(m)
    with timer(f"[{name}] fine-tune on {len(X):,} rows"):
        cond = base.cond.finetune(X, Y, ocfg["ft_trees"], ocfg["ft_lr"])
        ae_act = base.ae_act.finetune(X, ocfg["ft_ae_epochs"])
        ae_full = base.ae_full.finetune(np.hstack([X, Y]), ocfg["ft_ae_epochs"]) if base.ae_full else None
    return Arm(name, base.active, cond, None, ae_act, ae_full, None, len(X))


# ---------------------------------------------------------------- scoring one arm
def score_arm(arm: Arm, fit: Matrices, ref: Matrices, test: Matrices, cfg: dict) -> dict[str, np.ndarray]:
    sc_cfg = cfg["shift"]
    floor, mg = float(sc_cfg["scale_floor"]), int(sc_cfg["scoring_min_group"])
    names = [n for n, a in zip(test.names_y, arm.active) if a]
    cats = np.array([target_category(n) for n in names])
    Rf = arm.Y(fit) - arm.cond.predict(xa(fit))
    Rr = arm.Y(ref) - arm.cond.predict(xa(ref))
    Rt = arm.Y(test) - arm.cond.predict(xa(test))
    out = {}
    for sname, cat in SUBSETS.items():
        cols = None if cat is None else np.flatnonzero(cats == cat)
        if cols is not None and len(cols) == 0:
            continue
        rs = ResidualScorer(cols=cols, scale_floor=floor).fit(Rf, fit.group, Rr, ref.group, mg)
        out[sname] = rs.score(Rt, test.group)
    conf_a = MondrianConformal().fit(arm.ae_act.score(xa(ref)), ref.group, mg)
    out["s_A"] = conf_a.score(arm.ae_act.score(xa(test)), test.group)
    out["s_max"] = np.maximum(out["s_C"], out["s_A"])

    def full(m):
        return np.hstack([xa(m), arm.Y(m)])

    if arm.ae_full is not None:
        ft = full(test)
        out["AE_conf"] = MondrianConformal().fit(arm.ae_full.score(full(ref)), ref.group, mg).score(
            arm.ae_full.score(ft), test.group)
    if arm.iforest is not None:
        ft = full(test)
        out["IF_conf"] = MondrianConformal().fit(arm.iforest.score(full(ref)), ref.group, mg).score(
            arm.iforest.score(ft), test.group)
    return out


def h1_arm(arm: Arm, test_b: Matrices, fit: Matrices) -> dict:
    """R2 of the consequence on held-out target benign flows: with action, context only, and with
    action after removing the median residual of the calibration window (a per-target offset that
    a local calibration can absorb)."""
    names = [n for n, a in zip(test_b.names_y, arm.active) if a]
    Y = arm.Y(test_b)
    P = arm.cond.predict(xa(test_b))
    off = np.median(arm.Y(fit) - arm.cond.predict(xa(fit)), axis=0)
    out = {"r2_cond": dict(zip(names, r2_per_target(Y, P).tolist())),
           "r2_offset": dict(zip(names, r2_per_target(Y, P + off).tolist()))}
    if arm.ctxonly is not None:
        out["r2_ctx"] = dict(zip(names, r2_per_target(Y, arm.ctxonly.predict(test_b.ctx)).tolist()))
    for k in list(out):
        v = np.array([x for x in out[k].values() if x is not None and np.isfinite(x)])
        out[k + "_median"] = float(np.median(v)) if len(v) else None
    return out


# ---------------------------------------------------------------- evaluation
def evaluate(scores: dict, lab: np.ndarray, att: np.ndarray, fam: np.ndarray, fprs, gate_fpr) -> tuple[dict, dict]:
    masks = {"all": lab, "consequence": lab & (fam == "consequence"), "action": lab & (fam == "action"),
             "mixed": lab & (fam == "mixed")}
    ben = ~lab
    metrics = {}
    for s, v in scores.items():
        metrics[s] = {}
        for g in GROUPS:
            sa, sb = v[masks[g]], v[ben]
            row = {"n_attack": int(masks[g].sum())}
            for f in fprs:
                row[f"tpr@{f:g}"] = tpr_at_fpr(sb, sa, f)
            row["roc_auc"] = roc_auc(sb, sa) if len(sa) else None
            row["pr_auc"] = pr_auc(sb, sa) if len(sa) else None
            metrics[s][g] = row
    per_class = {}
    for a in pd.unique(att[lab]):
        m = lab & (att == a)
        per_class[str(a)] = {"n": int(m.sum()), **{s: tpr_at_fpr(v[ben], v[m], gate_fpr) for s, v in scores.items()}}
    return metrics, per_class


def c3_check(score: np.ndarray, ben: np.ndarray, groups: np.ndarray, t: np.ndarray, t0: int, horizons,
             alphas, min_n_factor: float, vocab: dict) -> dict:
    """Observed false-alarm rate of a conformal score on target benign test flows, per service
    group, for flows within each horizon after the calibration window."""
    out = {}
    for h in horizons:
        hm = ben & ((t < t0 + int(h * 1000)) if h else True)
        hk = "all" if not h else f"{h / 3600:g}h"
        out[hk] = {"n_benign": int(hm.sum())}
        for a in alphas:
            alarm = score[hm] > -np.log(a)
            g = pd.Series(alarm).groupby(groups[hm]).agg(["mean", "size"])
            g = g[g["size"] >= min_n_factor / a]
            worst = g["mean"].idxmax() if len(g) else None
            out[hk][f"alpha={a:g}"] = {
                "global_fpr": float(alarm.mean()) if len(alarm) else None,
                "groups_checked": int(len(g)),
                "max_group_fpr": float(g["mean"].max()) if len(g) else None,
                "worst_group": group_label(worst, vocab) if worst is not None else None,
                "groups_over_2alpha": [group_label(i, vocab) for i in g.index[g["mean"] > 2 * a]],
            }
    return out


def arm_report(arm: Arm, scores: dict, test: Matrices, lab, att, fam, ben, t_test, t0, cfg, vocab,
               h1: dict | None) -> dict:
    ec, sc = cfg["eval"], cfg["shift"]
    metrics, per_class = evaluate(scores, lab, att, fam, ec["fprs"], ec["gate_fpr"])
    c3 = {s: c3_check(scores[s], ben, test.group, t_test, t0, sc["c3_horizons_sec"], sc["c3_alphas"],
                      sc["c3_min_n_factor"], vocab) for s in ("s_C", "s_max") if s in scores}
    return {"n_train": arm.n_train, "targets": [n for n, a in zip(test.names_y, arm.active) if a],
            "h1": h1, "metrics": metrics, "per_class": per_class, "c3": c3}


def h2_compare(scores_all: dict, ben: np.ndarray, att_mask: np.ndarray, main: str, comparators: list[str],
               cfg: dict, seed: int) -> dict:
    gf = cfg["eval"]["gate_fpr"]
    have = [c for c in comparators if c in scores_all]
    if main not in scores_all or not have or not att_mask.any():
        return {"main": main, "comparators": have, "diff": None}
    tprs = {c: tpr_at_fpr(scores_all[c][ben], scores_all[c][att_mask], gf) for c in have}
    best = max(have, key=lambda c: np.nan_to_num(tprs[c], nan=-1))
    d, lo, hi = bootstrap_tpr_diff(scores_all[main][ben], scores_all[main][att_mask], scores_all[best][ben],
                                   scores_all[best][att_mask], gf, cfg["eval"]["bootstrap"], seed,
                                   cfg["eval"]["bootstrap_max_benign"])
    return {"main": main, "comparators": have, "best": best, "tpr_main": tpr_at_fpr(scores_all[main][ben],
            scores_all[main][att_mask], gf), "tpr_best": tprs[best], "tpr_comparators": tprs,
            "diff": d, "ci_low": lo, "ci_high": hi}


def _labels(st: Stream, rows: np.ndarray):
    lab = st.df["label"].values[rows] == 1
    att = np.asarray(st.df["attack"].values[rows]).astype(str)
    fam = np.array([st.family.get(a, "mixed") for a in att])
    return lab, att, fam


def _norm(cfg: dict, X: np.ndarray, seed: int) -> CtxNorm:
    return CtxNorm(cfg["features"].get("ctx_norm", "quantile"), seed=seed).fit(X)


# ---------------------------------------------------------------- experiment: time shift
def run_time(cfg: dict, st: Stream, seg_index: int, segs, profile: str, seed: int, device: str) -> dict:
    t0 = time.time()
    set_seed(seed)
    rng = np.random.default_rng(seed)
    sc, n_jobs = cfg["shift"], int(cfg["compute"]["n_jobs"])
    prof = get_profile(profile)
    seg = segs[seg_index]
    plan = plan_target(st.df, seg.t0, sc, rng, t_stop=seg.t1, t_start=seg.t0, stale=True)
    LOG.info("[%s/%s/seed%d] plan %s", st.name, seg.label, seed,
             {k: v for k, v in plan.summary.items() if k != "test_attack_per_class"})
    hist = cap(plan.history, sc["max_train_per_env"], rng)
    vocab = fit_vocab(st.df, hist, cfg, prof)
    raw_hist = build(st.df, hist, st.ctx, st.ctx_names, st.c2, st.c2_names, vocab, prof)
    norm = _norm(cfg, raw_hist.ctx, seed)
    raw_hist.ctx = norm.transform(raw_hist.ctx)
    with timer("build target matrices"):
        fit, ref, test = (mats(st, r, vocab, prof, norm) for r in (plan.cal_fit, plan.cal_ref, plan.test))
        sfit, sref = (mats(st, r, vocab, prof, norm) for r in (plan.stale_fit, plan.stale_ref))
    arm = train_arm("hist", raw_hist, cfg, device, seed, n_jobs)
    lab, att, fam = _labels(st, plan.test)
    ben = ~lab
    t_test = st.df["t"].values[plan.test]
    tb = np.flatnonzero(ben)
    tb = tb if len(tb) <= sc["r2_eval_max"] else np.sort(rng.choice(tb, sc["r2_eval_max"], replace=False))
    test_b = take(test, tb)
    res_arms, all_scores = {}, {}
    for cal_name, (f, r) in {"fresh": (fit, ref), "stale": (sfit, sref)}.items():
        with timer(f"score ({cal_name} calibration)"):
            scores = score_arm(arm, f, r, test, cfg)
        res_arms[cal_name] = arm_report(arm, scores, test, lab, att, fam, ben, t_test, plan.cal_end, cfg, vocab,
                                        h1_arm(arm, test_b, f))
        all_scores.update({f"{cal_name}/{k}": v for k, v in scores.items()})
    h2 = {}
    for main in ("fresh/s_C", "fresh/s_max"):
        for grp, m in (("all", lab), ("consequence", lab & (fam == "consequence"))):
            h2[f"{main}|{grp}"] = h2_compare(all_scores, ben, m, main, ["fresh/AE_conf", "fresh/IF_conf"], cfg, seed)
    check_memory(cfg, "time shift")
    return {"version": __version__, "experiment": "time", "dataset": st.name, "segment": seg.as_dict(),
            "profile": profile, "seed": seed, "device": device, "regressor_backend": arm.cond.backend,
            "regressor_device": getattr(arm.cond, "used_device", "cpu"), "ae_backend": arm.ae_act.backend,
            "ctx_norm": norm.mode, "plan": plan.summary, "families": st.family,
            "target_category": {n: target_category(n) for n in test.names_y},
            "arms": res_arms, "h2": h2, "seconds": round(time.time() - t0, 1)}


def time_targets(cfg: dict, st: Stream) -> list:
    tc = cfg["shift"]["time"]
    tz = tc.get("tz_offset_hours", {})
    tz = tz.get(st.name, 0.0) if isinstance(tz, dict) else float(tz)
    segs = segments(st.df["t"].values, st.df["label"].values, st.df["attack"].values, tc["segment"], tz,
                    tc.get("gap_hours", 3))
    hist_benign = np.cumsum([0] + [s.n_benign for s in segs])
    ok = [s.index for s in segs if s.index >= tc.get("first_target", 1) and s.n_benign >= tc["min_benign"]
          and hist_benign[s.index] >= tc.get("min_history", 100_000)]
    return segs, ok


def run_time_dataset(cfg: dict, name: str, profile: str, seeds, device: str, out_root: Path, force=False,
                     only=None) -> list[Path]:
    st = Stream(cfg, name)
    segs, targets = time_targets(cfg, st)
    LOG.info("%s: %d segments, targets %s", name, len(segs), [segs[i].label for i in targets])
    save_json({"dataset": name, "segments": [s.as_dict() for s in segs], "targets": targets},
              out_root / name / "segments.json")
    written = []
    for i in targets:
        if only is not None and segs[i].label not in only:
            continue
        for s in seeds:
            path = out_root / name / segs[i].label / f"{profile}_seed{s}.json"
            if path.exists() and not force:
                continue
            res = run_time(cfg, st, i, segs, profile, s, device)
            save_json(res, path)
            f = res["arms"]["fresh"]["metrics"]
            gf = f"tpr@{cfg['eval']['gate_fpr']:g}"
            LOG.info("[%s/%s/seed%d] TPR all s_max %.3f AE %.3f | C3 max group FPR fresh %s stale %s | %.0fs",
                     name, segs[i].label, s, _g(f, "s_max", gf), _g(f, "AE_conf", gf),
                     _c3(res["arms"]["fresh"]), _c3(res["arms"]["stale"]), res["seconds"])
            written.append(path)
    return written


def _g(metrics, s, key, grp="all"):
    v = metrics.get(s, {}).get(grp, {}).get(key)
    return float("nan") if v is None else v


def _c3(arm_res, s="s_C"):
    c = arm_res["c3"].get(s, {}).get("all", {}).get("alpha=0.001", {})
    return None if c.get("max_group_fpr") is None else round(c["max_group_fpr"], 4)


# ---------------------------------------------------------------- experiment: cross network
def source_sets(target: str, datasets: list[str], loo: bool) -> list[list[str]]:
    others = [d for d in datasets if d != target]
    sets = [[d] for d in others]
    if loo and len(others) > 1:
        sets.append(others)
    return sets


def run_cross(cfg: dict, streams: dict, target: str, profile: str, seed: int, device: str) -> dict:
    t0 = time.time()
    set_seed(seed)
    rng = np.random.default_rng(seed)
    sc, n_jobs = cfg["shift"], int(cfg["compute"]["n_jobs"])
    cc, oc = sc["cross"], sc["onboard"]
    prof = get_profile(profile)
    tst = streams[target]
    df = tst.df
    b = np.flatnonzero(df["label"].values == 0)
    t_cal = int(df["t"].values[b[int(cc["target_train_frac"] * len(b))]])
    k_win = int(sc["calib_sec"])
    sizes = sorted({k_win} | ({int(k) for k in oc["sizes_sec"]} if oc.get("enabled") else set()))
    plan = plan_target(df, t_cal, sc, rng, attacks_from=t_cal if cc.get("attacks") == "after_cal" else None,
                       onboard_sec=sizes)
    LOG.info("[cross %s/seed%d] plan %s", target, seed, {k: v for k, v in plan.summary.items()
                                                          if k != "test_attack_per_class"})
    sets = source_sets(target, list(streams), cc.get("leave_one_out", True))
    srcs = sorted({d for s in sets for d in s})
    # vocabulary: fixed ports/protocols; other categories (default profile only) from the sources
    first = cap(np.flatnonzero(streams[srcs[0]].df["label"].values == 0), 500_000, rng)
    vocab = fit_vocab(streams[srcs[0]].df, first, cfg, prof)

    # target environment: one normalizer fitted on the calibration window
    cal_rows = np.sort(np.concatenate([plan.cal_fit, plan.cal_ref]))
    tnorm = _norm(cfg, tst.ctx[cal_rows], seed)
    with timer("build target matrices"):
        fit, ref, test = (mats(tst, r, vocab, prof, tnorm) for r in (plan.cal_fit, plan.cal_ref, plan.test))
    lab, att, fam = _labels(tst, plan.test)
    ben = ~lab
    t_test = df["t"].values[plan.test]
    tb = np.flatnonzero(ben)
    tb = tb if len(tb) <= sc["r2_eval_max"] else np.sort(rng.choice(tb, sc["r2_eval_max"], replace=False))
    test_b = take(test, tb)

    res_arms, all_scores, norms = {}, {}, {"target": tnorm.mode}

    def run_arm(arm: Arm, with_h1: bool):
        with timer(f"[{arm.name}] score"):
            scores = score_arm(arm, fit, ref, test, cfg)
        res_arms[arm.name] = arm_report(arm, scores, test, lab, att, fam, ben, t_test, plan.cal_end, cfg, vocab,
                                        h1_arm(arm, test_b, fit) if with_h1 else None)
        all_scores.update({f"{arm.name}/{k}": v for k, v in scores.items()})

    # local reference: the target's own history
    hist = cap(plan.history, sc["max_train_per_env"], rng)
    run_arm(train_arm("loc", mats(tst, hist, vocab, prof, tnorm), cfg, device, seed, n_jobs), True)
    # scratch on the k seconds before the cut (k = calib_sec is the local-window baseline)
    for k in sizes:
        rows = plan.onboard.get(k, np.zeros(0, int))
        if len(rows) < sc.get("min_scratch_rows", 2000):
            LOG.warning("scr%d: only %d rows - skipped", k, len(rows))
            continue
        run_arm(train_arm(f"scr{k}", mats(tst, rows, vocab, prof, tnorm), cfg, device, seed, n_jobs,
                          with_ctx=False), False)
    # sources: each network normalized by its own benign training rows
    src_m = {}
    for d in srcs:
        sdf = streams[d].df
        rows = cap(np.flatnonzero(sdf["label"].values == 0), sc["max_train_per_env"], rng)
        raw = build(sdf, rows, streams[d].ctx, streams[d].ctx_names, streams[d].c2, streams[d].c2_names, vocab, prof)
        n = _norm(cfg, raw.ctx, seed)
        raw.ctx = n.transform(raw.ctx)
        src_m[d] = raw
        norms[d] = n.mode
    loo_arm = None
    for s in sets:
        name = "src:" + "+".join(s)
        per = int(sc["max_train_per_env"]) // len(s)
        parts = [take(src_m[d], np.sort(rng.choice(len(src_m[d].rows), min(per, len(src_m[d].rows)), replace=False)))
                 for d in s]
        arm = train_arm(name, concat(parts, rng), cfg, device, seed, n_jobs)
        run_arm(arm, True)
        if len(s) == max(len(x) for x in sets):
            loo_arm = arm
    # onboarding: fine-tune the widest source model on the k seconds before the cut
    if oc.get("enabled") and loo_arm is not None:
        for k in sizes:
            rows = plan.onboard.get(k, np.zeros(0, int))
            if len(rows) < sc.get("min_scratch_rows", 2000):
                continue
            run_arm(finetune_arm(loo_arm, f"ft{k}", mats(tst, rows, vocab, prof, tnorm), oc), False)

    # H2-T: each source arm vs the strongest unconditional detector that uses no more target data
    win = f"scr{k_win}"
    h2 = {}
    for s in sets:
        name = "src:" + "+".join(s)
        comps = [f"{name}/AE_conf", f"{name}/IF_conf", f"{win}/AE_conf", f"{win}/IF_conf"]
        for main in ("s_max", "s_C"):
            for grp, m in (("all", lab), ("consequence", lab & (fam == "consequence"))):
                h2[f"{name}|{main}|{grp}"] = h2_compare(all_scores, ben, m, f"{name}/{main}", comps, cfg, seed)
    check_memory(cfg, "cross")
    first_arm = next(iter(res_arms.values()))
    return {"version": __version__, "experiment": "cross", "target": target, "sources": sets, "profile": profile,
            "seed": seed, "device": device, "regressor_backend": loo_arm.cond.backend if loo_arm else None,
            "ae_backend": loo_arm.ae_act.backend if loo_arm else None, "ctx_norm": norms, "plan": plan.summary,
            "families": tst.family, "target_category": {n: target_category(n) for n in test.names_y},
            "n_features": {"context": test.ctx.shape[1], "action": test.act.shape[1],
                           "targets": len(first_arm["targets"])},
            "arms": res_arms, "h2": h2, "seconds": round(time.time() - t0, 1)}


def run_cross_target(cfg: dict, target: str, profile: str, seeds, device: str, out_root: Path,
                     force=False) -> list[Path]:
    todo = [s for s in seeds if force or not (out_root / target / f"{profile}_seed{s}.json").exists()]
    if not todo:
        LOG.info("cross %s: all results exist (use --force to rerun)", target)
        return []
    names = cfg["shift"]["cross"]["datasets"]
    if target not in names:
        raise ValueError(f"target {target!r} not in shift.cross.datasets {names}")
    streams = {d: Stream(cfg, d) for d in names}
    written = []
    for s in todo:
        res = run_cross(cfg, streams, target, profile, s, device)
        path = out_root / target / f"{profile}_seed{s}.json"
        save_json(res, path)
        for k, v in res["h2"].items():
            if k.endswith("|s_max|all") and v.get("diff") is not None:
                LOG.info("[cross %s/seed%d] %s: s_max %.3f vs %s %.3f (diff %.3f, CI [%.3f, %.3f])", target, s,
                         k.split("|")[0], v["tpr_main"], v["best"], v["tpr_best"], v["diff"], v["ci_low"],
                         v["ci_high"])
        written.append(path)
    return written
