"""Environments and time windows for the v2 shift experiments.

An environment is a network (one dataset) or one period of it (one capture day). All row
indices refer to a flow table sorted by start time (data.load_flows guarantees that).

Target timeline used by every shift experiment (benign flows only, except the test set):

    ... history ... | onboarding window W_on(k) | calibration window W_cal | test ...
                  t_cal - k                   t_cal                    cal_end

  W_cal  short benign window right after the cut t_cal; split at random in two halves:
         'fit' (residual centre / scale / covariance) and 'ref' (conformal reference)
  W_on   the k seconds of benign traffic right before t_cal (fine-tuning / training from scratch)
  test   benign flows after cal_end + attack flows
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

DAY_MS = 86_400_000


@dataclass
class Segment:
    index: int
    label: str
    lo: int                  # row range [lo, hi) in the time-sorted table
    hi: int
    t0: int                  # first / last start time (ms)
    t1: int
    n_benign: int
    n_attack: int
    attacks: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        return {"index": self.index, "label": self.label, "t0": self.t0, "t1": self.t1,
                "hours": round((self.t1 - self.t0) / 3.6e6, 2), "n_benign": self.n_benign,
                "n_attack": self.n_attack, "attacks": self.attacks}


def segments(t_ms: np.ndarray, label: np.ndarray, attack, mode: str = "day", tz_offset_hours: float = 0.0,
             gap_hours: float = 3.0) -> list[Segment]:
    """Split the time-sorted table into capture periods.
    day  calendar days in the capture's local time (UTC + tz_offset_hours)
    gap  a new segment starts after a pause longer than gap_hours"""
    t = np.asarray(t_ms, dtype=np.int64)
    if len(t) == 0:
        return []
    if np.any(np.diff(t) < 0):
        raise ValueError("flows must be sorted by start time")
    if mode == "day":
        key = (t + int(round(tz_offset_hours * 3_600_000))) // DAY_MS
        cuts = np.flatnonzero(np.diff(key)) + 1
    elif mode == "gap":
        cuts = np.flatnonzero(np.diff(t) > gap_hours * 3_600_000) + 1
    else:
        raise ValueError(f"segment mode must be day | gap, got {mode!r}")
    bounds = np.r_[0, cuts, len(t)]
    att = np.asarray(attack).astype(str)
    lab = np.asarray(label)
    out = []
    for i, (lo, hi) in enumerate(zip(bounds[:-1], bounds[1:])):
        lo, hi = int(lo), int(hi)
        a = att[lo:hi][lab[lo:hi] == 1]
        counts = {str(k): int(v) for k, v in pd.Series(a).value_counts().items()} if len(a) else {}
        if mode == "day":
            lab_s = str(pd.Timestamp(int(t[lo]) + int(round(tz_offset_hours * 3_600_000)), unit="ms").date())
        else:
            lab_s = f"seg{i:02d}"
        out.append(Segment(i, lab_s, lo, hi, int(t[lo]), int(t[hi - 1]), int((lab[lo:hi] == 0).sum()),
                           int((lab[lo:hi] == 1).sum()), counts))
    return out


# ---------------------------------------------------------------- benign windows
def _benign(t, label):
    b = np.flatnonzero(np.asarray(label) == 0)
    return b, np.asarray(t, dtype=np.int64)[b]


def window_after(t, label, start_ms: int, sec: float, min_flows: int = 0, stop_ms: int | None = None):
    """Benign rows with start_ms <= t < start_ms + sec; extended forward until min_flows rows
    (never past stop_ms). Returns (rows, end_ms) with end_ms = first time AFTER the window."""
    b, tb = _benign(t, label)
    i0 = int(np.searchsorted(tb, start_ms, side="left"))
    i1 = int(np.searchsorted(tb, start_ms + int(sec * 1000), side="left"))
    lim = len(b) if stop_ms is None else int(np.searchsorted(tb, stop_ms, side="right"))
    if i1 - i0 < min_flows:
        i1 = min(i0 + min_flows, lim)
    i1 = min(i1, lim)
    rows = b[i0:i1]
    end_ms = int(start_ms + sec * 1000)
    if i1 > i0:
        end_ms = max(end_ms, int(tb[i1 - 1]) + 1)
    if stop_ms is not None:
        end_ms = min(end_ms, int(stop_ms) + 1)
    return rows, end_ms


def window_before(t, label, end_ms: int, sec: float, min_flows: int = 0, start_ms: int | None = None):
    """Benign rows with end_ms - sec <= t < end_ms; extended backward until min_flows rows
    (never before start_ms)."""
    b, tb = _benign(t, label)
    i1 = int(np.searchsorted(tb, end_ms, side="left"))
    i0 = int(np.searchsorted(tb, end_ms - int(sec * 1000), side="left"))
    lim = 0 if start_ms is None else int(np.searchsorted(tb, start_ms, side="left"))
    if i1 - i0 < min_flows:
        i0 = max(i1 - min_flows, lim)
    i0 = max(i0, lim)
    return b[i0:i1]


def split_fit_ref(rows: np.ndarray, rng) -> tuple[np.ndarray, np.ndarray]:
    perm = rng.permutation(rows)
    half = len(perm) // 2
    return np.sort(perm[:half]), np.sort(perm[half:])


def cap(idx: np.ndarray, m, rng) -> np.ndarray:
    if m and len(idx) > int(m):
        idx = np.sort(rng.choice(idx, int(m), replace=False))
    return idx


def cap_per_class(idx: np.ndarray, names: np.ndarray, m, rng) -> np.ndarray:
    if len(idx) == 0:
        return idx
    keep = [cap(idx[names == n], m, rng) for n in pd.unique(names)]
    return np.sort(np.concatenate(keep))


@dataclass
class TargetPlan:
    """Rows of one target environment for one seed."""
    t_cal: int
    cal_end: int
    cal_fit: np.ndarray
    cal_ref: np.ndarray
    test: np.ndarray
    history: np.ndarray                    # benign before t_cal (local / history model)
    onboard: dict = field(default_factory=dict)   # k seconds -> benign rows in [t_cal - k, t_cal)
    stale_fit: np.ndarray | None = None    # calibration from the end of the history (time shift)
    stale_ref: np.ndarray | None = None
    summary: dict = field(default_factory=dict)


def plan_target(df: pd.DataFrame, t_cal: int, scfg: dict, rng, t_stop: int | None = None,
                t_start: int | None = None, attacks_from: int | None = None, onboard_sec=(),
                stale: bool = False) -> TargetPlan:
    """Build the target timeline. t_stop/t_start bound the target period (a day for the time
    shift); attacks_from: only attacks starting at or after this time go to the test set
    (None = all attacks inside [t_start, t_stop])."""
    t = df["t"].values
    lab = df["label"].values
    cal_rows, cal_end = window_after(t, lab, t_cal, scfg["calib_sec"], scfg["calib_min_flows"], t_stop)
    cal_rows = cap(cal_rows, scfg.get("calib_max_flows"), rng)
    cal_fit, cal_ref = split_fit_ref(cal_rows, rng)

    b = np.flatnonzero(lab == 0)
    tb = t[b]
    hi = len(b) if t_stop is None else int(np.searchsorted(tb, t_stop, side="right"))
    test_b = b[int(np.searchsorted(tb, cal_end, side="left")):hi]
    test_b = cap(test_b, scfg.get("max_test_benign"), rng)

    a = np.flatnonzero(lab == 1)
    ta = t[a]
    lo_a = 0 if t_start is None else int(np.searchsorted(ta, t_start, side="left"))
    hi_a = len(a) if t_stop is None else int(np.searchsorted(ta, t_stop, side="right"))
    a = a[lo_a:hi_a]
    if attacks_from is not None:
        a = a[t[a] >= attacks_from]
    names = np.asarray(df["attack"].values[a]).astype(str)
    a = cap_per_class(a, names, scfg.get("max_test_attack_per_class"), rng)
    test = np.sort(np.concatenate([test_b, a]))

    history = b[:int(np.searchsorted(tb, t_cal, side="left"))]
    onboard = {int(k): window_before(t, lab, t_cal, k, 0) for k in onboard_sec}
    plan = TargetPlan(int(t_cal), int(cal_end), cal_fit, cal_ref, test, history, onboard)
    if stale:
        # at least as many flows as the fresh window, so the two calibrations are comparable
        st = window_before(t, lab, t_cal, scfg["calib_sec"], max(scfg["calib_min_flows"], len(cal_rows)))
        st = cap(st, scfg.get("calib_max_flows"), rng)
        plan.stale_fit, plan.stale_ref = split_fit_ref(st, rng)
    att_names = np.asarray(df["attack"].values[a]).astype(str)
    plan.summary = {
        "t_cal": int(t_cal), "cal_end": int(cal_end), "calib_minutes": round((cal_end - t_cal) / 60000, 1),
        "cal_fit": len(cal_fit), "cal_ref": len(cal_ref), "history": len(history), "test_benign": len(test_b),
        "test_attack": len(a), "onboard": {str(k): len(v) for k, v in onboard.items()},
        "test_attack_per_class": {str(k): int(v) for k, v in pd.Series(att_names).value_counts().items()},
    }
    if stale:
        plan.summary["stale"] = len(plan.stale_fit) + len(plan.stale_ref)
    return plan
