"""Synthetic NetFlow v3 table for smoke tests (same header as the UQ datasets).

Benign: clients use http/https/ssh/dns/ftp/smb; the reply size is a fixed function of the
request size per service (the "world" the model must learn). In the last 35% of time new
clients appear and upload bigger files: novel actions with normal consequences.
Attacks: scanning, password (action group), theft, backdoor (consequence group), xss (mixed).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

NF_COLUMNS = [
    "FLOW_START_MILLISECONDS", "FLOW_END_MILLISECONDS", "IPV4_SRC_ADDR", "L4_SRC_PORT", "IPV4_DST_ADDR",
    "L4_DST_PORT", "PROTOCOL", "L7_PROTO", "IN_BYTES", "IN_PKTS", "OUT_BYTES", "OUT_PKTS", "TCP_FLAGS",
    "CLIENT_TCP_FLAGS", "SERVER_TCP_FLAGS", "FLOW_DURATION_MILLISECONDS", "DURATION_IN", "DURATION_OUT",
    "MIN_TTL", "MAX_TTL", "LONGEST_FLOW_PKT", "SHORTEST_FLOW_PKT", "MIN_IP_PKT_LEN", "MAX_IP_PKT_LEN",
    "SRC_TO_DST_SECOND_BYTES", "DST_TO_SRC_SECOND_BYTES", "RETRANSMITTED_IN_BYTES", "RETRANSMITTED_IN_PKTS",
    "RETRANSMITTED_OUT_BYTES", "RETRANSMITTED_OUT_PKTS", "SRC_TO_DST_AVG_THROUGHPUT", "DST_TO_SRC_AVG_THROUGHPUT",
    "NUM_PKTS_UP_TO_128_BYTES", "NUM_PKTS_128_TO_256_BYTES", "NUM_PKTS_256_TO_512_BYTES",
    "NUM_PKTS_512_TO_1024_BYTES", "NUM_PKTS_1024_TO_1514_BYTES", "TCP_WIN_MAX_IN", "TCP_WIN_MAX_OUT",
    "ICMP_TYPE", "ICMP_IPV4_TYPE", "DNS_QUERY_ID", "DNS_QUERY_TYPE", "DNS_TTL_ANSWER", "FTP_COMMAND_RET_CODE",
    "SRC_TO_DST_IAT_MIN", "SRC_TO_DST_IAT_MAX", "SRC_TO_DST_IAT_AVG", "SRC_TO_DST_IAT_STDDEV",
    "DST_TO_SRC_IAT_MIN", "DST_TO_SRC_IAT_MAX", "DST_TO_SRC_IAT_AVG", "DST_TO_SRC_IAT_STDDEV",
    "Label", "Attack",
]

#            port proto  l7    in_mu in_sd  reply(in, rng)
SERVICES = {
    "http": (80, 6, 7.0, 6.0, 0.6, lambda x, r: 25 * x ** 0.85 * r.lognormal(0, 0.25, len(x))),
    "https": (443, 6, 91.0, 7.0, 0.8, lambda x, r: 6 * x * r.lognormal(0, 0.3, len(x))),
    "ssh": (22, 6, 92.0, 8.0, 1.0, lambda x, r: 1.2 * x * r.lognormal(0, 0.2, len(x))),
    "dns": (53, 17, 5.0, 4.1, 0.2, lambda x, r: x + 60 * r.lognormal(0, 0.3, len(x))),
    "ftp": (21, 6, 1.0, 6.0, 0.5, lambda x, r: 2 * x * r.lognormal(0, 0.2, len(x))),
    "smb": (445, 6, 41.0, 10.0, 1.0, lambda x, r: 300 + 0.002 * x * r.lognormal(0, 0.2, len(x))),
}
DAY_MS = 86_400_000


def _flows(rng, t, src, dst, svc, in_b, out_b, dur_in, dur_out, cflag=27, sflag=27, label=0, attack="Benign",
           dport=None, out_pkts=None, iat_out=None):
    n = len(t)
    port, proto, l7 = SERVICES[svc][:3] if svc in SERVICES else (0, 6, 0.0)
    in_b, out_b = np.maximum(in_b, 40).round(), np.maximum(out_b, 0).round()
    in_p = np.maximum(1, np.ceil(in_b / 600))
    out_p = np.maximum(1, np.ceil(out_b / 900)) if out_pkts is None else out_pkts
    out_p = np.where(out_b == 0, 0, out_p)
    dur = np.maximum(dur_in, dur_out)
    iat_o = dur_out / np.maximum(out_p - 1, 1) if iat_out is None else iat_out
    d = {
        "FLOW_START_MILLISECONDS": t.astype(np.int64), "FLOW_END_MILLISECONDS": (t + dur).astype(np.int64),
        "IPV4_SRC_ADDR": src, "L4_SRC_PORT": rng.integers(32768, 61000, n), "IPV4_DST_ADDR": dst,
        "L4_DST_PORT": np.full(n, port) if dport is None else dport, "PROTOCOL": np.full(n, proto),
        "L7_PROTO": np.full(n, l7), "IN_BYTES": in_b, "IN_PKTS": in_p, "OUT_BYTES": out_b, "OUT_PKTS": out_p,
        "TCP_FLAGS": np.full(n, cflag | sflag) if proto == 6 else 0,
        "CLIENT_TCP_FLAGS": np.full(n, cflag) if proto == 6 else 0,
        "SERVER_TCP_FLAGS": np.full(n, sflag) if proto == 6 else 0,
        "FLOW_DURATION_MILLISECONDS": dur.round(), "DURATION_IN": dur_in.round(), "DURATION_OUT": dur_out.round(),
        "MIN_TTL": 64, "MAX_TTL": 64, "LONGEST_FLOW_PKT": 1500, "SHORTEST_FLOW_PKT": 40,
        "MIN_IP_PKT_LEN": 40, "MAX_IP_PKT_LEN": 1500,
        "SRC_TO_DST_SECOND_BYTES": in_b, "DST_TO_SRC_SECOND_BYTES": out_b,
        "RETRANSMITTED_IN_BYTES": 0, "RETRANSMITTED_IN_PKTS": 0, "RETRANSMITTED_OUT_BYTES": 0,
        "RETRANSMITTED_OUT_PKTS": 0,
        "SRC_TO_DST_AVG_THROUGHPUT": (8000 * in_b / np.maximum(dur_in, 1)).round(),
        "DST_TO_SRC_AVG_THROUGHPUT": (8000 * out_b / np.maximum(dur_out, 1)).round(),
        "NUM_PKTS_UP_TO_128_BYTES": 1, "NUM_PKTS_128_TO_256_BYTES": 0, "NUM_PKTS_256_TO_512_BYTES": 0,
        "NUM_PKTS_512_TO_1024_BYTES": 0, "NUM_PKTS_1024_TO_1514_BYTES": in_p + out_p - 1,
        "TCP_WIN_MAX_IN": 64240, "TCP_WIN_MAX_OUT": 65160, "ICMP_TYPE": 0, "ICMP_IPV4_TYPE": 0,
        "DNS_QUERY_ID": rng.integers(0, 65535, n) if svc == "dns" else 0,
        "DNS_QUERY_TYPE": 1 if svc == "dns" else 0,
        "DNS_TTL_ANSWER": rng.integers(60, 600, n) if svc == "dns" else 0,
        "FTP_COMMAND_RET_CODE": np.where(rng.random(n) < 0.05, 530, 226) if svc == "ftp" else 0,
        "SRC_TO_DST_IAT_MIN": 0, "SRC_TO_DST_IAT_MAX": (dur_in / np.maximum(in_p - 1, 1) * 2).round(),
        "SRC_TO_DST_IAT_AVG": (dur_in / np.maximum(in_p - 1, 1)).round(), "SRC_TO_DST_IAT_STDDEV": 0,
        "DST_TO_SRC_IAT_MIN": 0, "DST_TO_SRC_IAT_MAX": (2 * iat_o).round(),
        "DST_TO_SRC_IAT_AVG": np.round(iat_o), "DST_TO_SRC_IAT_STDDEV": (0.3 * iat_o).round(),
        "Label": label, "Attack": attack,
    }
    return pd.DataFrame(d)


def make_synth(n_benign: int = 150_000, seed: int = 0, days: int = 2, n_clients: int = 60, probs=None,
               size_scale: float = 1.0, law: dict | None = None, subnet: str = "10.0",
               start_ms: int = 1_600_000_000_000 // DAY_MS * DAY_MS) -> pd.DataFrame:
    """One synthetic network. v2 knobs for the shift tests: `probs` (service mix), `size_scale`
    (clients send bigger/smaller requests: new actions, same law), `law` (service -> factor on the
    reply size: a network whose consequence law differs), `subnet` (other hosts), `days`."""
    r = np.random.default_rng(seed)
    law = law or {}
    t0, span = int(start_ms), int(days) * DAY_MS
    servers = {s: [f"{subnet}.1.{2 * i + 1}", f"{subnet}.1.{2 * i + 2}"] for i, s in enumerate(SERVICES)}
    parts = []
    clients = np.array([f"{subnet}.0.{i}" for i in range(1, n_clients + 1)])
    newcomers = np.array([f"{subnet}.2.{i}" for i in range(1, 16)])
    probs = np.array([0.35, 0.3, 0.08, 0.17, 0.05, 0.05] if probs is None else probs, dtype=float)
    counts = r.multinomial(n_benign, probs / probs.sum())
    for (svc, (port, proto, l7, mu, sd, reply)), n in zip(SERVICES.items(), counts):
        t = np.sort(r.uniform(t0, t0 + span, n))
        late = t > t0 + 0.65 * span
        src = r.choice(clients, n)
        nov = late & (r.random(n) < 0.3)
        src[nov] = r.choice(newcomers, nov.sum())
        in_b = r.lognormal(mu, sd, n) * size_scale
        if svc in ("smb", "https"):
            in_b[nov] *= 5.0                       # novel action, consequence follows the same law
        out_b = reply(in_b, r) * law.get(svc, 1.0)
        dur_in = r.lognormal(4, 1, n)
        dur_out = dur_in * r.lognormal(0, 0.2, n)
        dst = r.choice(servers[svc], n)
        df = _flows(r, t, src, dst, svc, in_b, out_b, dur_in, dur_out)
        if proto == 6:                             # 3% refused connections: SYN -> RST/ACK
            fail = r.random(n) < 0.03
            df.loc[fail, ["IN_BYTES", "IN_PKTS", "OUT_BYTES", "OUT_PKTS"]] = [60, 1, 40, 1]
            df.loc[fail, ["CLIENT_TCP_FLAGS", "SERVER_TCP_FLAGS", "DURATION_IN", "DURATION_OUT"]] = [2, 20, 0, 0]
        parts.append(df)

    att = [f"{subnet}.9.1", f"{subnet}.9.2", f"{subnet}.9.3"]
    all_servers = sum(servers.values(), [])
    # scanning (action group): SYN to many ports, refused - the reply is what a refusal looks like
    n = 3000
    t = np.sort(r.uniform(t0, t0 + span, n))
    sc = _flows(r, t, np.full(n, att[0]), r.choice(all_servers, n), "http", np.full(n, 44.0), np.full(n, 40.0),
                np.zeros(n), np.zeros(n), cflag=2, sflag=20, label=1, attack="scanning",
                dport=r.integers(1, 2000, n), out_pkts=np.ones(n))
    sc["IN_PKTS"] = 1
    parts.append(sc)
    # password (action group): bursts of ssh logins, normal-looking replies
    n = 2000
    starts = r.uniform(t0, t0 + span - 120_000, 5)
    t = np.sort(np.concatenate([s + r.uniform(0, 120_000, n // 5) for s in starts]))
    x = r.lognormal(7, 0.2, len(t))
    parts.append(_flows(r, t, np.full(len(t), att[1]), r.choice(servers["ssh"], len(t)), "ssh", x,
                        SERVICES["ssh"][5](x, r), r.lognormal(4, 1, len(t)), r.lognormal(4, 1, len(t)),
                        label=1, attack="password"))
    # theft (consequence group): ordinary http requests, replies ~200x too large
    n = 800
    t = np.sort(r.uniform(t0, t0 + span, n))
    x = r.lognormal(6, 0.6, n)
    parts.append(_flows(r, t, np.full(n, att[2]), r.choice(servers["http"], n), "http", x,
                        200 * SERVICES["http"][5](x, r), r.lognormal(4, 1, n), r.lognormal(7, 0.5, n),
                        label=1, attack="theft"))
    # backdoor (consequence group): http request opens an interactive session + callback flows
    n = 800
    t = np.sort(r.uniform(t0, t0 + span, n))
    x = r.lognormal(6, 0.6, n)
    srv = r.choice(servers["http"], n)
    dur_out = r.lognormal(11, 0.5, n)
    bd = _flows(r, t, np.full(n, att[2]), srv, "http", x, SERVICES["http"][5](x, r), r.lognormal(4, 1, n), dur_out,
                label=1, attack="backdoor", out_pkts=r.integers(150, 400, n), iat_out=dur_out / 200)
    parts.append(bd)
    cb_t = t + dur_out + r.uniform(1000, 20_000, n)
    cb = _flows(r, cb_t, srv, np.full(n, att[2]), "https", r.lognormal(9, 0.5, n), r.lognormal(5, 0.3, n),
                r.lognormal(6, 0.5, n), r.lognormal(6, 0.5, n), label=1, attack="backdoor", dport=np.full(n, 4444))
    parts.append(cb)
    # xss (mixed): slightly larger http requests, normal replies
    n = 500
    t = np.sort(r.uniform(t0, t0 + span, n))
    x = r.lognormal(7.5, 0.4, n)
    parts.append(_flows(r, t, np.full(n, att[0]), r.choice(servers["http"], n), "http", x,
                        SERVICES["http"][5](x, r), r.lognormal(4, 1, n), r.lognormal(4, 1, n),
                        label=1, attack="xss"))
    df = pd.concat(parts, ignore_index=True).sort_values("FLOW_START_MILLISECONDS", kind="stable")
    return df[NF_COLUMNS].reset_index(drop=True)
