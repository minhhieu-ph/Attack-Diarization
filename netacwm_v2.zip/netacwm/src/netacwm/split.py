"""Temporal split. Detectors are trained on early BENIGN flows only, calibrated on the next
benign slice, and tested on later benign flows plus attack flows."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class Split:
    train: np.ndarray
    calib_fit: np.ndarray      # fits residual centre/scale/covariance
    calib_ref: np.ndarray      # conformal reference (never used for fitting)
    test: np.ndarray
    cutoff_ms: int
    summary: dict = field(default_factory=dict)


def _cap(idx: np.ndarray, m, rng) -> np.ndarray:
    if m and len(idx) > int(m):
        idx = np.sort(rng.choice(idx, int(m), replace=False))
    return idx


def temporal_split(df: pd.DataFrame, cfg: dict, seed: int) -> Split:
    sc = cfg["split"]
    rng = np.random.default_rng(seed)
    label = df["label"].values
    t = df["t"].values
    benign = np.flatnonzero(label == 0)  # df is sorted by time
    nb = len(benign)
    if nb < 1000:
        raise ValueError(f"only {nb} benign flows - cannot train a benign world model")
    e1 = int(sc["train_frac"] * nb)
    e2 = int((sc["train_frac"] + sc["calib_frac"]) * nb)
    train, calib, test_b = benign[:e1], benign[e1:e2], benign[e2:]
    cutoff = int(t[benign[e2]]) if e2 < nb else int(t.max())

    attacks = np.flatnonzero(label == 1)
    if sc.get("attacks", "all") == "after_cutoff":
        attacks = attacks[t[attacks] >= cutoff]
    att_names = np.asarray(df["attack"].values[attacks]).astype(str)
    keep = []
    for name in pd.unique(att_names):
        keep.append(_cap(attacks[att_names == name], sc.get("max_test_attack_per_class"), rng))
    attacks = np.sort(np.concatenate(keep)) if keep else attacks[:0]

    train = _cap(train, sc.get("max_train"), rng)
    calib = _cap(calib, sc.get("max_calib"), rng)
    test_b = _cap(test_b, sc.get("max_test_benign"), rng)
    perm = rng.permutation(calib)
    half = len(perm) // 2
    calib_fit, calib_ref = np.sort(perm[:half]), np.sort(perm[half:])
    test = np.sort(np.concatenate([test_b, attacks]))

    summary = {
        "benign_total": int(nb), "train": len(train), "calib_fit": len(calib_fit), "calib_ref": len(calib_ref),
        "test_benign": len(test_b), "test_attack": len(attacks), "cutoff_ms": cutoff,
        "test_attack_per_class": {str(k): int(v) for k, v in
                                  pd.Series(np.asarray(df["attack"].values[attacks]).astype(str)).value_counts().items()},
    }
    return Split(train, calib_fit, calib_ref, test, cutoff, summary)
