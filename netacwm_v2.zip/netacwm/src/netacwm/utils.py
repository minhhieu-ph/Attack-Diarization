"""Shared helpers: logging, seeding, IO, CPU/GPU resources."""
from __future__ import annotations

import importlib.util
import json
import logging
import os
import random
import shutil
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

import numpy as np
import pandas as pd


def get_logger(name: str = "netacwm") -> logging.Logger:
    log = logging.getLogger(name)
    if not log.handlers:
        h = logging.StreamHandler(sys.stdout)
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s", "%H:%M:%S"))
        log.addHandler(h)
        log.setLevel(os.environ.get("NETACWM_LOG", "INFO"))
        log.propagate = False
    return log


LOG = get_logger()


def has_module(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    if has_module("torch"):
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)


@contextmanager
def timer(msg: str):
    t0 = time.time()
    yield
    LOG.info("%s: %.1fs (RSS %.1f GiB)", msg, time.time() - t0, rss_gib())


# ---------------------------------------------------------------- dataframe / json IO
def save_df(df: pd.DataFrame, stem: str | Path) -> Path:
    """Parquet when pyarrow exists, else pickle. `stem` has no suffix."""
    stem = Path(stem)
    stem.parent.mkdir(parents=True, exist_ok=True)
    suf = ".parquet" if has_module("pyarrow") else ".pkl"
    path = stem.with_suffix(suf)
    tmp = stem.with_name(f"{stem.name}.{os.getpid()}.tmp{suf}")   # atomic: parallel jobs may race
    if suf == ".parquet":
        df.to_parquet(tmp, index=False)
    else:
        df.to_pickle(tmp)
    tmp.replace(path)
    return path


def find_df(stem: str | Path) -> Path | None:
    stem = Path(stem)
    for suf in (".parquet", ".pkl"):
        p = stem.with_suffix(suf)
        if p.exists():
            if suf == ".parquet" and not has_module("pyarrow"):
                continue
            return p
    return None


def read_df(path: Path, columns: list[str] | None = None) -> pd.DataFrame:
    if path.suffix == ".parquet":
        if columns is not None:
            import pyarrow.parquet as pq

            have = set(pq.read_schema(path).names)
            columns = [c for c in columns if c in have]
        return pd.read_parquet(path, columns=columns)
    df = pd.read_pickle(path)
    return df if columns is None else df[[c for c in columns if c in df.columns]]


def _json_default(o):
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.floating):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (set, frozenset)):
        return sorted(o)
    if isinstance(o, Path):
        return str(o)
    return str(o)


def _clean(o):
    """NaN/inf -> None so the JSON stays valid."""
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, (float, np.floating)):
        return float(o) if np.isfinite(o) else None
    return o


def save_json(obj, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w") as f:
        json.dump(_clean(obj), f, indent=2, default=_json_default, allow_nan=False)
    tmp.replace(path)


def load_json(path: str | Path):
    with open(path) as f:
        return json.load(f)


# ---------------------------------------------------------------- resources
def rss_gib() -> float:
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) / 2**20
    except OSError:
        pass
    return float("nan")


def check_memory(cfg: dict, where: str = "") -> None:
    lim = cfg.get("compute", {}).get("ram_limit_gib")
    used = rss_gib()
    if lim and used == used and used > 0.8 * lim:
        LOG.warning("RAM %.0f GiB of %.0f GiB (%s): lower split.max_* or data.max_rows", used, lim, where)


def available_cpus() -> int:
    """CPUs this process may use (cgroup quota, then affinity, then os.cpu_count)."""
    n = None
    try:
        with open("/sys/fs/cgroup/cpu.max") as f:
            quota, period = f.read().split()[:2]
            if quota != "max":
                n = max(1, int(int(quota) // int(period)))
    except (OSError, ValueError):
        pass
    try:
        aff = len(os.sched_getaffinity(0))
    except AttributeError:
        aff = os.cpu_count() or 1
    return max(1, min(n, aff) if n else aff)


def setup_threads(cfg: dict) -> int:
    """Cap thread pools to compute.n_jobs; 'auto'/<=0 -> usable CPUs minus 2, clamped to [1, usable]."""
    comp = cfg.setdefault("compute", {})
    avail = available_cpus()
    try:
        n = int(comp.get("n_jobs", 0))
    except (TypeError, ValueError):
        n = 0
    if n <= 0:
        n = avail - 2
    n = max(1, min(n, avail))
    comp["n_jobs"] = n
    for var in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_MAX_THREADS"):
        os.environ[var] = str(n)
    if has_module("pyarrow"):
        import pyarrow

        pyarrow.set_cpu_count(n)
        pyarrow.set_io_thread_count(max(1, min(n, 8)))
    if has_module("torch"):
        import torch

        torch.set_num_threads(n)
    LOG.info("threads: n_jobs=%d (usable CPUs: %d)", n, avail)
    return n


def gpu_available() -> bool:
    if has_module("torch"):
        import torch

        if torch.cuda.is_available():
            return True
    if shutil.which("nvidia-smi"):
        try:
            out = subprocess.run(["nvidia-smi", "-L"], capture_output=True, text=True, timeout=10).stdout
            visible = os.environ.get("CUDA_VISIBLE_DEVICES")
            return "GPU" in out and visible not in ("", "-1")
        except (OSError, subprocess.SubprocessError):
            return False
    return False


def resolve_device(cfg: dict) -> str:
    want = cfg.get("compute", {}).get("device", "auto")
    if want == "cpu":
        return "cpu"
    ok = gpu_available()
    if want == "cuda" and not ok:
        LOG.warning("CUDA requested but no GPU is visible -> CPU")
    return "cuda" if ok else "cpu"
