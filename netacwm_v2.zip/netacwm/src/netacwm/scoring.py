"""C3: conditional surprise with a false-alarm guarantee.

s_C = Mahalanobis distance of the prediction residual, after robust per-service standardization,
turned into a Mondrian (per service group) conformal p-value. Under exchangeability of benign
flows, P(p <= alpha | benign, group) <= alpha, so a threshold on -log p gives FPR <= alpha in every
group. Groups with too few calibration flows fall back to the global reference.
"""
from __future__ import annotations

import numpy as np

TIE_EPS = 1e-7


def _robust(R: np.ndarray, floor: float = 1e-3):
    """Median centre; scale = max(1.4826*MAD, winsorized std, floor). The std term matters for
    sparse or binary targets (flag bits, FTP error) whose MAD is 0: without it one rare flip would
    get a huge z and dominate the distance of every other target. The floor matters when the
    scorer is fitted on a short calibration window of a NEW network (v2): a target that happens
    to be constant there must not turn every later deviation into an alarm. Targets are log1p
    sizes/times or 0/1 bits, so a floor of 0.05 means "about 5 %" or "1/20 of a flip"."""
    med = np.median(R, axis=0)
    mad = np.median(np.abs(R - med), axis=0) * 1.4826
    lo, hi = np.quantile(R, [0.005, 0.995], axis=0)
    wstd = np.clip(R, lo, hi).std(axis=0)
    scale = np.maximum(np.maximum(mad, wstd), floor)
    return med, scale


def _precision(Z: np.ndarray) -> np.ndarray:
    from sklearn.covariance import LedoitWolf

    sub = Z if len(Z) <= 300_000 else Z[np.random.default_rng(0).choice(len(Z), 300_000, replace=False)]
    cov = LedoitWolf().fit(sub).covariance_
    return np.linalg.pinv(cov)


def _mahal(Z: np.ndarray, prec: np.ndarray) -> np.ndarray:
    return np.sqrt(np.maximum(np.einsum("ij,jk,ik->i", Z, prec, Z), 0.0)).astype(np.float64)


class MondrianConformal:
    """Per-group conformal p-values from a held-out benign reference set."""

    def fit(self, ref: np.ndarray, groups: np.ndarray, min_group: int = 200) -> "MondrianConformal":
        self.global_ = np.sort(np.asarray(ref, dtype=np.float64))
        self.by_group = {}
        for g in np.unique(groups):
            r = ref[groups == g]
            if len(r) >= min_group:
                self.by_group[int(g)] = np.sort(np.asarray(r, dtype=np.float64))
        return self

    def pvalue(self, s: np.ndarray, groups: np.ndarray) -> np.ndarray:
        p = np.empty(len(s), dtype=np.float64)
        done = np.zeros(len(s), dtype=bool)
        for g, ref in self.by_group.items():
            m = groups == g
            if m.any():
                ge = len(ref) - np.searchsorted(ref, s[m], side="left")
                p[m] = (1.0 + ge) / (len(ref) + 1.0)
                done |= m
        if (~done).any():
            ref = self.global_
            ge = len(ref) - np.searchsorted(ref, s[~done], side="left")
            p[~done] = (1.0 + ge) / (len(ref) + 1.0)
        return p

    def score(self, s: np.ndarray, groups: np.ndarray) -> np.ndarray:
        """-log p, extended beyond the GLOBAL reference maximum M by log(s / M).
        Every score above its group's reference has the same p-value; the extension keeps the
        order among those extremes on one scale shared by all groups (a per-group extension would
        blow up groups whose benign reference is very tight). Below M the score is -log p, so the
        per-group FPR guarantee holds for any threshold up to log(n_ref + 1)."""
        s = np.asarray(s, dtype=np.float64)
        m = self.global_[-1]
        with np.errstate(divide="ignore", invalid="ignore"):
            ext = np.where((s > m) & (m > 0), np.log(s / m), 0.0)
        tb = np.where(s > 0, s / (1.0 + np.abs(s)), 0.0)
        return -np.log(self.pvalue(s, groups)) + ext + TIE_EPS * tb


class ResidualScorer:
    """Distance = Mahalanobis of the robustly standardized residual (one scale for all flows);
    calibration = Mondrian conformal per service group on that distance.

    cols: use only these residual columns (v2: e.g. only the 'mechanics' targets)."""

    def __init__(self, cols=None, scale_floor: float = 1e-3):
        self.cols = None if cols is None else np.asarray(cols, dtype=int)
        self.scale_floor = scale_floor

    def _sel(self, R):
        return R if self.cols is None else R[:, self.cols]

    def fit(self, R_fit: np.ndarray, g_fit: np.ndarray, R_ref: np.ndarray, g_ref: np.ndarray,
            min_group: int = 200) -> "ResidualScorer":
        self.med, self.scale = _robust(self._sel(R_fit), self.scale_floor)
        self.prec = _precision(self.z(R_fit))
        self.conf = MondrianConformal().fit(self.distance(R_ref), g_ref, min_group)
        return self

    def z(self, R):
        """Standardized residual per target (also used to explain which consequence deviated)."""
        return ((self._sel(R) - self.med) / self.scale).astype(np.float64)

    def distance(self, R):
        return _mahal(self.z(R), self.prec)

    def raw(self, R):
        return self.distance(R)

    def score(self, R, g):
        return self.conf.score(self.distance(R), g)
