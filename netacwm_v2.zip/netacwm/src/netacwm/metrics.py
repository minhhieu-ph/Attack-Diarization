"""Detection metrics. Scores: higher = more anomalous."""
from __future__ import annotations

import numpy as np


def tpr_at_fpr(sb: np.ndarray, sa: np.ndarray, fpr: float) -> float:
    if len(sa) == 0 or len(sb) == 0:
        return float("nan")
    thr = np.quantile(sb, 1.0 - fpr, method="higher")
    return float(np.mean(sa > thr))


def roc_auc(sb, sa) -> float:
    from sklearn.metrics import roc_auc_score

    if len(sa) == 0 or len(sb) == 0:
        return float("nan")
    y = np.r_[np.zeros(len(sb)), np.ones(len(sa))]
    return float(roc_auc_score(y, np.r_[sb, sa]))


def pr_auc(sb, sa) -> float:
    from sklearn.metrics import average_precision_score

    if len(sa) == 0 or len(sb) == 0:
        return float("nan")
    y = np.r_[np.zeros(len(sb)), np.ones(len(sa))]
    return float(average_precision_score(y, np.r_[sb, sa]))


def r2_per_target(Y: np.ndarray, P: np.ndarray) -> np.ndarray:
    ss_res = ((Y - P) ** 2).sum(0)
    ss_tot = ((Y - Y.mean(0)) ** 2).sum(0)
    with np.errstate(divide="ignore", invalid="ignore"):
        r2 = 1.0 - ss_res / ss_tot
    return np.where(ss_tot > 0, r2, np.nan)


def bootstrap_tpr_diff(sb1, sa1, sb2, sa2, fpr, n_boot=200, seed=0, max_benign=500_000):
    """Paired bootstrap of TPR@fpr(score 1) - TPR@fpr(score 2) on the same benign/attack flows.
    Returns (mean diff, 2.5%, 97.5%)."""
    rng = np.random.default_rng(seed)
    nb, na = len(sb1), len(sa1)
    if nb == 0 or na == 0:
        return float("nan"), float("nan"), float("nan")
    if nb > max_benign:
        keep = rng.choice(nb, max_benign, replace=False)
        sb1, sb2, nb = sb1[keep], sb2[keep], max_benign
    diffs = np.empty(n_boot)
    for b in range(n_boot):
        ib = rng.integers(0, nb, nb)
        ia = rng.integers(0, na, na)
        diffs[b] = tpr_at_fpr(sb1[ib], sa1[ia], fpr) - tpr_at_fpr(sb2[ib], sa2[ia], fpr)
    return float(diffs.mean()), float(np.quantile(diffs, 0.025)), float(np.quantile(diffs, 0.975))
