"""Aggregate the v2 shift results (outputs/shift/{time,cross}/...) into outputs/shift/summary.md
with the pre-registered verdicts (configs/default.yaml, gate_shift)."""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path

import numpy as np

from .schema import TARGET_CATEGORIES
from .utils import load_json


def _nan(x):
    return np.nan if x is None else float(x)


def _mean(xs):
    v = np.array([_nan(x) for x in xs], dtype=float)
    return float(np.nanmean(v)) if np.isfinite(v).any() else np.nan


def _pct(x, d=1):
    return "–" if x is None or not np.isfinite(x) else f"{100 * x:.{d}f}"


def _f3(x):
    return "–" if x is None or not np.isfinite(x) else f"{x:.3f}"


def _tpr(arm: dict, scorer: str, key: str, grp: str = "all"):
    return _nan(arm.get("metrics", {}).get(scorer, {}).get(grp, {}).get(key))


def _c3(arm: dict, scorer: str, horizon: str, alpha: float):
    c = arm.get("c3", {}).get(scorer, {}).get(horizon, {}).get(f"alpha={alpha:g}", {})
    return _nan(c.get("max_group_fpr")), _nan(c.get("global_fpr")), c.get("groups_checked", 0), c.get("worst_group")


def collect_time(root: Path) -> list[dict]:
    return [load_json(p) for p in sorted((root / "time").glob("*/*/*_seed*.json"))]


def collect_cross(root: Path) -> list[dict]:
    return [load_json(p) for p in sorted((root / "cross").glob("*/*_seed*.json"))]


# ---------------------------------------------------------------- time shift (G1)
def time_section(results: list[dict], cfg: dict) -> tuple[list[str], dict]:
    g = cfg["gate_shift"]
    gf = cfg["eval"]["gate_fpr"]
    key = f"tpr@{gf:g}"
    a = g["c3_alpha"]
    L, verdict = [], {}
    by_ds = defaultdict(lambda: defaultdict(list))
    for r in results:
        by_ds[r["dataset"]][r["segment"]["label"]].append(r)
    for ds, days in by_ds.items():
        L += [f"### {ds}", "",
              f"Mô hình học trên benign của mọi ngày trước đó; hiệu chỉnh **fresh** = giờ đầu của chính ngày đó, "
              f"**stale** = giờ cuối trước ngày đó (giống E0). TPR (%) tại FPR {gf:g} trên mọi tấn công của ngày; "
              f"FPR nhóm lớn nhất của s_C ở α = {a:g} (nhóm có ≥ {cfg['shift']['c3_min_n_factor'] / a:,.0f} flow benign).", "",
              "| Ngày | Seed | Benign test | Tấn công | R² có HĐ / chỉ NC | s_max | s_C | AE | IF | FPR nhóm max fresh | stale |",
              "|---|---|---|---|---|---|---|---|---|---|---|"]
        c3_ok, c3_n, wins = 0, 0, []
        for day in sorted(days):
            rs = days[day]
            fr = [r["arms"]["fresh"] for r in rs]
            st = [r["arms"]["stale"] for r in rs]
            r2c = _mean([x["h1"]["r2_cond_median"] for x in fr])
            r2x = _mean([x["h1"].get("r2_ctx_median") for x in fr])
            mf = _mean([_c3(x, "s_C", "all", a)[0] for x in fr])
            ms = _mean([_c3(x, "s_C", "all", a)[0] for x in st])
            if np.isfinite(mf):
                c3_n += 1
                c3_ok += mf <= g["c3_factor"] * a
            top = sorted(rs[0]["plan"]["test_attack_per_class"].items(), key=lambda kv: -kv[1])[:2]
            L.append(f"| {day} | {len(rs)} | {rs[0]['plan']['test_benign']:,} | "
                     f"{rs[0]['plan']['test_attack']:,} ({', '.join(k for k, _ in top) or '–'}) | "
                     f"{_f3(r2c)} / {_f3(r2x)} | " + " | ".join(
                         _pct(_mean([_tpr(x, s, key) for x in fr])) for s in ("s_max", "s_C", "AE_conf", "IF_conf"))
                     + f" | {_pct(mf, 2)} | {_pct(ms, 2)} |")
            classes = set().union(*[x["per_class"].keys() for x in fr])
            for c in classes:
                sc = _mean([x["per_class"].get(c, {}).get("s_C") for x in fr])
                base = max(_mean([x["per_class"].get(c, {}).get(b) for x in fr]) for b in ("AE_conf", "IF_conf"))
                if np.isfinite(sc) and np.isfinite(base) and sc - base >= g["g1_unique_gain"]:
                    wins.append((day, c, sc, base))
        L += ["", f"Giới hạn C3 là {g['c3_factor']:g}α = {100 * g['c3_factor'] * a:.2f}%.", ""]
        if wins:
            L += ["Lớp tấn công mà s_C (fresh) hơn mọi baseline ≥ "
                  f"{100 * g['g1_unique_gain']:.0f} điểm:", "", "| Ngày | Lớp | s_C | baseline tốt nhất |", "|---|---|---|---|"]
            L += [f"| {d} | {c} | {_pct(s)} | {_pct(b)} |" for d, c, s, b in sorted(wins)]
            L.append("")
        frac = c3_ok / c3_n if c3_n else np.nan
        c3_pass = bool(c3_n) and frac >= g["g1_c3_days_frac"]
        go = c3_pass and bool(wins)
        verdict[ds] = {"c3_days": f"{c3_ok}/{c3_n}", "c3_pass": c3_pass, "unique_wins": len(wins), "go": go}
        L += [f"**G1 ({ds}): {'GO' if go else 'STOP'}** — C3 đạt ở {c3_ok}/{c3_n} ngày "
              f"(cần ≥ {100 * g['g1_c3_days_frac']:.0f}%) → {'đạt' if c3_pass else 'không đạt'}; "
              f"{len(wins)} cặp (ngày, lớp) s_C thắng riêng → {'đạt' if wins else 'không đạt'}.", ""]
    return L, verdict


# ---------------------------------------------------------------- cross network (H1-T, H2-T, C3-T)
def _common_median(a: dict, b: dict):
    ks = [k for k in a if k in b and a[k] is not None and b[k] is not None and np.isfinite(a[k]) and np.isfinite(b[k])]
    if not ks:
        return np.nan, np.nan
    return float(np.median([a[k] for k in ks])), float(np.median([b[k] for k in ks]))


def _cat_median(d: dict, cats: dict, cat: str, keys=None):
    v = [x for k, x in d.items() if cats.get(k) == cat and x is not None and np.isfinite(x)
         and (keys is None or k in keys)]
    return float(np.median(v)) if v else np.nan


def cross_section(results: list[dict], cfg: dict) -> tuple[list[str], dict]:
    g = cfg["gate_shift"]
    gf = cfg["eval"]["gate_fpr"]
    key = f"tpr@{gf:g}"
    a, hz = g["c3_alpha"], g["c3_horizon"]
    win = f"scr{int(cfg['shift']['calib_sec'])}"
    pairs = defaultdict(list)          # (target, source arm) -> list of (result, arm dict)
    for r in results:
        for name, arm in r["arms"].items():
            if name.startswith("src:"):
                pairs[(r["target"], name)].append(r)
    rows, cat_rows, verdict_pairs = [], [], {}
    for (tgt, name), rs in sorted(pairs.items()):
        src, loc, ctxg, off, ret = [], [], [], [], []
        cat_src = defaultdict(list)
        cat_loc = defaultdict(list)
        for r in rs:
            s_h1, l_h1 = r["arms"][name]["h1"], r["arms"]["loc"]["h1"]
            ms, ml = _common_median(s_h1["r2_cond"], l_h1["r2_cond"])
            src.append(ms)
            loc.append(ml)
            ctxg.append(ms - _nan(s_h1.get("r2_ctx_median")))
            off.append(_nan(s_h1.get("r2_offset_median")))
            ret.append(ms / ml if ml and ml > 0 else np.nan)
            common = set(s_h1["r2_cond"]) & set(l_h1["r2_cond"])
            for c in TARGET_CATEGORIES:
                cat_src[c].append(_cat_median(s_h1["r2_cond"], r["target_category"], c, common))
                cat_loc[c].append(_cat_median(l_h1["r2_cond"], r["target_category"], c, common))
        h2 = [r["h2"].get(f"{name}|{g['h2_scorer']}|{g['h2_group']}", {}) for r in rs]
        diff = _mean([x.get("diff") for x in h2])
        ci_lo = _mean([x.get("ci_low") for x in h2])
        best = h2[0].get("best", "–") if h2 else "–"
        c3m = _mean([_c3(r["arms"][name], "s_C", hz, a)[0] for r in rs])
        retention, gain = _mean(ret), _mean(ctxg)
        h1_ok = np.isfinite(retention) and retention >= g["h1_retention_min"] and gain >= g["h1_gain_min"]
        h2_ok = np.isfinite(diff) and diff >= g["h2_gain_min"]
        c3_ok = np.isfinite(c3m) and c3m <= g["c3_factor"] * a
        verdict_pairs[(tgt, name)] = {"h1": h1_ok if np.isfinite(retention) else None, "h2": h2_ok, "c3": c3_ok
                                      if np.isfinite(c3m) else None}
        tp = {s: _mean([_tpr(r["arms"][name], s, key) for r in rs]) for s in ("s_max", "s_C", "s_C_mech", "s_C_content",
                                                                               "AE_conf", "IF_conf")}
        tp["win_AE"] = _mean([_tpr(r["arms"].get(win, {}), "AE_conf", key) for r in rs])
        tp["loc_s_max"] = _mean([_tpr(r["arms"]["loc"], "s_max", key) for r in rs])
        tp["loc_AE"] = _mean([_tpr(r["arms"]["loc"], "AE_conf", key) for r in rs])
        rows.append((tgt, name[4:], len(rs), _mean(src), _mean(loc), retention, gain, _mean(off), h1_ok, tp, diff,
                     ci_lo, best, h2_ok, c3m, c3_ok))
        cat_rows.append((tgt, name[4:], {c: (_mean(cat_src[c]), _mean(cat_loc[c])) for c in TARGET_CATEGORIES}))

    L = ["Mỗi cặp: học trên benign của mạng nguồn, hiệu chỉnh trên 1 giờ benign đầu của mạng đích, test trên phần sau. "
         "`loc` = học trên lịch sử của chính mạng đích (mốc tham chiếu); "
         f"`{win}` = học từ đầu trên 1 giờ benign của mạng đích ngay trước cửa sổ hiệu chỉnh.", "",
         "#### H1-T: quy luật hệ quả có chuyển giao không (R² trung vị trên các trường hệ quả chung, benign test của mạng đích)", "",
         "| Đích | Nguồn | Seed | R² chuyển giao | R² tại chỗ | Giữ lại | Hơn chỉ ngữ cảnh | R² sau bù lệch | H1-T |",
         "|---|---|---|---|---|---|---|---|---|"]
    for t, s, n, rs_, rl, ret, gain, off, ok, *_ in rows:
        L.append(f"| {t} | {s} | {n} | {_f3(rs_)} | {_f3(rl)} | {_pct(ret, 0)}% | {_f3(gain)} | {_f3(off)} | "
                 f"{'đạt' if ok else 'không'} |")
    L += ["", f"Ngưỡng: giữ lại ≥ {100 * g['h1_retention_min']:.0f}% và hơn mô hình chỉ ngữ cảnh ≥ {g['h1_gain_min']}. "
          "'R² sau bù lệch' trừ đi độ lệch trung vị đo trên cửa sổ hiệu chỉnh: nếu cao hơn hẳn R² chuyển giao thì "
          "quy luật đúng hình dạng nhưng lệch mức (hiệu chỉnh tại chỗ xử lý được).", "",
          "#### Bản đồ chuyển giao theo loại hệ quả (R² trung vị: chuyển giao / tại chỗ)", "",
          "| Đích | Nguồn | " + " | ".join(TARGET_CATEGORIES) + " |", "|---|---|" + "---|" * len(TARGET_CATEGORIES)]
    for t, s, cats in cat_rows:
        L.append(f"| {t} | {s} | " + " | ".join(f"{_f3(cats[c][0])} / {_f3(cats[c][1])}" for c in TARGET_CATEGORIES) + " |")
    L += ["", "mechanics = cờ TCP phía server, số gói trả lời; content = số byte, thông lượng; timing = thời lượng, "
          "khoảng cách gói; netcond = truyền lại; delayed = C2 (host đích làm gì sau đó).", "",
          f"#### H2-T: phát hiện (TPR % tại FPR {gf:g}, mọi tấn công của mạng đích)", "",
          "| Đích | Nguồn | s_max | s_C | s_C_mech | s_C_content | AE | IF | AE 1 giờ | loc s_max | loc AE | "
          f"{g['h2_scorer']} − tốt nhất (CI dưới) | Đối thủ tốt nhất | H2-T |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for t, s, n, *_, tp, diff, ci, best, ok, c3m, c3ok in rows:
        L.append(f"| {t} | {s} | " + " | ".join(_pct(tp[k]) for k in ("s_max", "s_C", "s_C_mech", "s_C_content",
                                                                      "AE_conf", "IF_conf", "win_AE", "loc_s_max",
                                                                      "loc_AE"))
                 + f" | {_pct(diff)} ({_pct(ci)}) | {best} | {'đạt' if ok else 'không'} |")
    L += ["", f"Đối thủ = AE/IF học trên cùng mạng nguồn và AE/IF học 1 giờ tại chỗ (chọn cái mạnh nhất, tức thiên về "
          f"baseline). Ngưỡng: hơn ≥ {100 * g['h2_gain_min']:.0f} điểm.", "",
          f"#### C3-T: báo động giả của s_C sau hiệu chỉnh tại chỗ (α = {a:g}, benign trong {hz} sau cửa sổ)", "",
          "| Đích | Nguồn | FPR nhóm lớn nhất | C3-T |", "|---|---|---|---|"]
    for t, s, n, *_, c3m, c3ok in rows:
        L.append(f"| {t} | {s} | {_pct(c3m, 2)}% | {'đạt' if c3ok else 'không'} |")
    L += ["", f"Ngưỡng: ≤ {g['c3_factor']:g}α = {100 * g['c3_factor'] * a:.2f}%.", ""]

    def frac(k):
        v = [x[k] for x in verdict_pairs.values() if x[k] is not None]
        return (sum(v), len(v))

    out = {}
    for k, need in (("h1", g["pairs_frac"]), ("h2", g["pairs_frac"]), ("c3", g["c3_pairs_frac"])):
        p, n = frac(k)
        out[k] = {"passed": p, "n": n, "need": need, "ok": bool(n) and p / n >= need}
    return L, out


# ---------------------------------------------------------------- onboarding (step 3)
def onboard_section(results: list[dict], cfg: dict) -> list[str]:
    gf = cfg["eval"]["gate_fpr"]
    key = f"tpr@{gf:g}"
    by_t = defaultdict(list)
    for r in results:
        if any(k.startswith("ft") for k in r["arms"]):
            by_t[r["target"]].append(r)
    if not by_t:
        return []
    L = ["### Bước 3: đường cong làm quen", "",
         f"TPR (%) của s_max tại FPR {gf:g}, mọi tấn công. `ftK` = mô hình học trên các mạng khác rồi fine-tune "
         "trên K giây benign tại chỗ; `scrK` = học từ đầu trên đúng K giây đó; K = 0 là chuyển giao zero-shot.", ""]
    for t, rs in by_t.items():
        ks = sorted({int(k[2:]) for r in rs for k in r["arms"] if k.startswith("ft")})
        loo = max((k for k in rs[0]["arms"] if k.startswith("src:")), key=lambda k: k.count("+"))
        loc = _mean([_tpr(r["arms"]["loc"], "s_max", key) for r in rs])
        L += [f"**{t}** (tại chỗ đầy đủ: {_pct(loc)})", "", "| K (giây) | ft s_max | scr s_max | ft AE | scr AE |",
              "|---|---|---|---|---|",
              f"| 0 | {_pct(_mean([_tpr(r['arms'][loo], 's_max', key) for r in rs]))} | – | "
              f"{_pct(_mean([_tpr(r['arms'][loo], 'AE_conf', key) for r in rs]))} | – |"]
        zero = _mean([_tpr(r["arms"][loo], "s_max", key) for r in rs])
        reach = 0 if np.isfinite(zero) and np.isfinite(loc) and zero >= 0.9 * loc else None
        for k in ks:
            ft = _mean([_tpr(r["arms"].get(f"ft{k}", {}), "s_max", key) for r in rs])
            scr = _mean([_tpr(r["arms"].get(f"scr{k}", {}), "s_max", key) for r in rs])
            L.append(f"| {k} | {_pct(ft)} | {_pct(scr)} | "
                     f"{_pct(_mean([_tpr(r['arms'].get(f'ft{k}', {}), 'AE_conf', key) for r in rs]))} | "
                     f"{_pct(_mean([_tpr(r['arms'].get(f'scr{k}', {}), 'AE_conf', key) for r in rs]))} |")
            if reach is None and np.isfinite(ft) and np.isfinite(loc) and ft >= 0.9 * loc:
                reach = k
        msg = ("chưa đạt trong các mức đã thử" if reach is None else
               "0 giây (zero-shot đã đạt)" if reach == 0 else f"{reach} giây")
        L += ["", f"Lượng dữ liệu tại chỗ để đạt 90% mức tại chỗ đầy đủ: {msg}.", ""]
    return L


# ---------------------------------------------------------------- summary
def write_shift_summary(root: Path, cfg: dict) -> Path:
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    tres, cres = collect_time(root), collect_cross(root)
    L = ["# NetACWM v2 — dịch chuyển môi trường", ""]
    if not tres and not cres:
        L.append("Chưa có kết quả trong outputs/shift/.")
    tv, cv = {}, {}
    if tres:
        tl, tv = time_section(tres, cfg)
        L += ["## Bước 1: dịch chuyển thời gian (G1)", ""] + tl
    if cres:
        cl, cv = cross_section(cres, cfg)
        L += ["## Bước 2: chuyển sang mạng khác", ""] + cl + onboard_section(cres, cfg)
    head = ["## Kết luận", ""]
    for ds, v in tv.items():
        head.append(f"- **G1 {ds}: {'GO' if v['go'] else 'STOP'}** (C3 đạt {v['c3_days']} ngày, "
                    f"{v['unique_wins']} lớp s_C thắng riêng)")
    names = {"h1": "H1-T (quy luật chuyển giao)", "h2": "H2-T (phát hiện hơn baseline)",
             "c3": "C3-T (báo động giả sau hiệu chỉnh tại chỗ)"}
    for k, v in cv.items():
        head.append(f"- **{names[k]}: {'ĐẠT' if v['ok'] else 'KHÔNG ĐẠT'}** — {v['passed']}/{v['n']} cặp "
                    f"(cần ≥ {100 * v['need']:.0f}%)")
    if len(head) > 2:
        L[2:2] = head + [""]
    path = root / "summary.md"
    path.write_text("\n".join(L), encoding="utf-8")
    return path
