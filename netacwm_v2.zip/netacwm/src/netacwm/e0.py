"""E0 feasibility gate (proposal, section "Các thực nghiệm").

For one dataset x feature profile x seed:
  H1  does knowing the action make the consequence predictable?   R2(context+action) vs R2(context)
  H2  does the conditional surprise s_C catch consequence-group attacks better than unconditional
      baselines at a low FPR?                                         TPR@FPR, paired bootstrap CI

Scorers (higher = more anomalous):
  s_C      Mondrian-conformal surprise of the consequence given context + action   (C1 + C3)
  s_C_raw  same distance without the per-service conformal calibration
  s_A      action novelty: autoencoder over context + action, conformal per service
  s_max    max(s_C, s_A) - the full triage score
  AE, AE_conf   autoencoder over context + action + consequence (raw / conformal)
  IF, IF_conf   isolation forest over context + action + consequence (raw / conformal)
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd

from . import __version__
from .data import load_flows
from .features import build, causal_context, delayed_consequence, fit_vocab
from .metrics import bootstrap_tpr_diff, pr_auc, r2_per_target, roc_auc, tpr_at_fpr
from .models import Autoencoder, IForest, MultiRegressor
from .schema import family_of, get_profile
from .scoring import MondrianConformal, ResidualScorer
from .split import temporal_split
from .utils import LOG, check_memory, save_json, set_seed, timer

BASELINES = ["AE", "AE_conf", "IF", "IF_conf"]
SCORERS = ["s_C", "s_C_raw", "s_A", "s_max"] + BASELINES
GROUPS = ["consequence", "action", "mixed", "all"]


class Stream:
    """Everything computed once per dataset (shared by profiles and seeds)."""

    def __init__(self, cfg: dict, name: str):
        self.name = name
        self.df = load_flows(cfg, name)
        df = self.df
        with timer("causal context"):
            self.ctx, self.ctx_names = causal_context(df["t"].values, df["src"].values, df["dst"].values,
                                                      cfg["features"]["context_windows_sec"])
        self.c2, self.c2_names = None, []
        dcfg = cfg["features"].get("delayed", {})
        if dcfg.get("enabled", True):
            sent = df["IN_BYTES"].values if "IN_BYTES" in df.columns else np.zeros(len(df), np.float32)
            with timer("delayed consequence C2"):
                self.c2, self.c2_names = delayed_consequence(df["t"].values, df["t_end"].values, df["src"].values,
                                                             df["dst"].values, sent, dcfg.get("delta_sec", 60))
        fam = cfg["families"]
        col = df["attack"]
        names = [str(a) for a in (col.cat.categories if hasattr(col, "cat") else pd.unique(col))]
        self.family = {a: family_of(a, fam) for a in names}
        check_memory(cfg, "stream")


def run_one(cfg: dict, st: Stream, profile_name: str, seed: int, device: str) -> dict:
    t0 = time.time()
    set_seed(seed)
    n_jobs = int(cfg["compute"]["n_jobs"])
    prof = get_profile(profile_name)
    df = st.df
    sp = temporal_split(df, cfg, seed)
    LOG.info("[%s/%s/seed%d] split %s", st.name, profile_name, seed,
             {k: v for k, v in sp.summary.items() if k != "test_attack_per_class"})
    vocab = fit_vocab(df, sp.train, cfg, prof)

    def mats(rows):
        return build(df, rows, st.ctx, st.ctx_names, st.c2, st.c2_names, vocab, prof)

    with timer("build matrices"):
        tr, cf, cr, te = mats(sp.train), mats(sp.calib_fit), mats(sp.calib_ref), mats(sp.test)
    active = tr.y.std(0) > 1e-6
    yn = [n for n, a in zip(tr.names_y, active) if a]
    Ytr, Ycf, Ycr, Yte = tr.y[:, active], cf.y[:, active], cr.y[:, active], te.y[:, active]

    def xa(m):
        return np.hstack([m.ctx, m.act])

    rc = cfg["models"]["regressor"]
    with timer("regressor context+action"):
        cond = MultiRegressor(rc, device, seed, n_jobs).fit(xa(tr), Ytr)
    with timer("regressor context only"):
        ctxonly = MultiRegressor(rc, device, seed, n_jobs).fit(tr.ctx, Ytr)

    # H1: predictability of the consequence on held-out benign flows
    P_cr = cond.predict(xa(cr))
    r2c = r2_per_target(Ycr, P_cr)
    r20 = r2_per_target(Ycr, ctxonly.predict(cr.ctx))

    # C3: conditional surprise
    with timer("score s_C"):
        R_cf = Ycf - cond.predict(xa(cf))
        R_cr = Ycr - P_cr
        R_te = Yte - cond.predict(xa(te))
        sc = ResidualScorer().fit(R_cf, cf.group, R_cr, cr.group, cfg["scoring"]["min_group_calib"])
        scores = {"s_C": sc.score(R_te, te.group), "s_C_raw": sc.raw(R_te)}

    mg = cfg["scoring"]["min_group_calib"]
    with timer("score s_A"):
        # an autoencoder, not an isolation forest: IF cannot split on a feature that is constant in
        # training (e.g. a port bucket never seen in benign), so it is blind to exactly that novelty
        aea = Autoencoder(cfg["models"]["ae"], device, seed).fit(xa(tr))
        conf_a = MondrianConformal().fit(aea.score(xa(cr)), cr.group, mg)
        scores["s_A"] = conf_a.score(aea.score(xa(te)), te.group)
    scores["s_max"] = np.maximum(scores["s_C"], scores["s_A"])

    def full(m, y):
        return np.hstack([m.ctx, m.act, y])

    with timer("baseline autoencoder"):
        ae = Autoencoder(cfg["models"]["ae"], device, seed).fit(full(tr, Ytr))
        scores["AE"] = ae.score(full(te, Yte))
        scores["AE_conf"] = MondrianConformal().fit(ae.score(full(cr, Ycr)), cr.group, mg).score(scores["AE"], te.group)
    with timer("baseline isolation forest"):
        iff = IForest(cfg["models"]["iforest"], seed, n_jobs).fit(full(tr, Ytr))
        scores["IF"] = iff.score(full(te, Yte))
        scores["IF_conf"] = MondrianConformal().fit(iff.score(full(cr, Ycr)), cr.group, mg).score(scores["IF"], te.group)

    # ---- evaluation
    ec = cfg["eval"]
    lab = df["label"].values[sp.test] == 1
    att = np.asarray(df["attack"].values[sp.test]).astype(str)
    fam = np.array([st.family.get(a, "mixed") for a in att])
    masks = {"consequence": lab & (fam == "consequence"), "action": lab & (fam == "action"),
             "mixed": lab & (fam == "mixed"), "all": lab}
    ben = ~lab
    metrics = {}
    for s in SCORERS:
        v = scores[s]
        metrics[s] = {}
        for g in GROUPS:
            sa, sb = v[masks[g]], v[ben]
            row = {"n_attack": int(masks[g].sum())}
            for f in ec["fprs"]:
                row[f"tpr@{f:g}"] = tpr_at_fpr(sb, sa, f)
            row["roc_auc"] = roc_auc(sb, sa)
            row["pr_auc"] = pr_auc(sb, sa)
            metrics[s][g] = row
    gf = ec["gate_fpr"]
    per_class = {}
    for a in pd.unique(att[lab]):
        m = lab & (att == a)
        per_class[str(a)] = {"family": st.family.get(a, "mixed"), "n": int(m.sum()),
                             **{s: tpr_at_fpr(scores[s][ben], scores[s][m], gf) for s in SCORERS}}

    key = f"tpr@{gf:g}"
    cons = masks["consequence"]
    best = max(BASELINES, key=lambda b: np.nan_to_num(metrics[b]["consequence"][key], nan=-1))
    diff, lo, hi = bootstrap_tpr_diff(scores["s_C"][ben], scores["s_C"][cons], scores[best][ben], scores[best][cons],
                                      gf, ec["bootstrap"], seed, ec["bootstrap_max_benign"])
    # does s_C keep FPR <= alpha on benign test flows of each service group? (C3 check)
    alpha = gf
    thr = -np.log(alpha)
    fpr_by_group = pd.Series(scores["s_C"][ben] > thr).groupby(te.group[ben]).agg(["mean", "size"])
    fpr_by_group = fpr_by_group[fpr_by_group["size"] >= 1000]

    res = {
        "version": __version__, "dataset": st.name, "profile": profile_name, "seed": seed, "device": device,
        "regressor_backend": cond.backend, "regressor_device": getattr(cond, "used_device", "cpu"),
        "ae_backend": ae.backend, "split": sp.summary,
        "n_features": {"context": tr.ctx.shape[1], "action": tr.act.shape[1], "targets": int(active.sum())},
        "targets": yn,
        "h1": {"r2_cond_mean": float(np.nanmean(r2c)), "r2_ctx_mean": float(np.nanmean(r20)),
               "r2_gain": float(np.nanmean(r2c) - np.nanmean(r20)),
               "r2_cond": dict(zip(yn, r2c.tolist())), "r2_ctx": dict(zip(yn, r20.tolist()))},
        "h2": {"gate_fpr": gf, "best_baseline": best, "tpr_s_C": metrics["s_C"]["consequence"][key],
               "tpr_best_baseline": metrics[best]["consequence"][key], "diff": diff, "ci_low": lo, "ci_high": hi,
               "n_consequence_attacks": int(cons.sum())},
        "c3_check": {"alpha": alpha, "groups_checked": int(len(fpr_by_group)),
                     "max_group_fpr": float(fpr_by_group["mean"].max()) if len(fpr_by_group) else None,
                     "global_fpr": float(np.mean(scores["s_C"][ben] > thr))},
        "families": {str(k): v for k, v in st.family.items() if k != "Benign"},
        "metrics": metrics, "per_class": per_class, "seconds": round(time.time() - t0, 1),
    }
    if ec.get("save_scores"):
        res["_scores"] = {"rows": sp.test, "label": lab, "attack": att, **scores}
    return res


def run_dataset(cfg: dict, name: str, profiles: list[str], seeds: list[int], device: str, out_root: Path,
                force: bool = False) -> list[Path]:
    todo = [(p, s) for p in profiles for s in seeds
            if force or not (out_root / name / f"{p}_seed{s}.json").exists()]
    if not todo:
        LOG.info("%s: all results exist (use --force to rerun)", name)
        return []
    st = Stream(cfg, name)
    written = []
    for p, s in todo:
        res = run_one(cfg, st, p, s, device)
        sc = res.pop("_scores", None)
        path = out_root / name / f"{p}_seed{s}.json"
        save_json(res, path)
        if sc is not None:
            np.savez_compressed(path.with_suffix(".npz"), **{k: np.asarray(v) for k, v in sc.items()})
        h1, h2 = res["h1"], res["h2"]
        LOG.info("[%s/%s/seed%d] H1 R2 gain %.3f | H2 s_C %.3f vs %s %.3f (diff %.3f, CI [%.3f, %.3f]) | %.0fs",
                 name, p, s, h1["r2_gain"], h2["tpr_s_C"], h2["best_baseline"], h2["tpr_best_baseline"],
                 h2["diff"], h2["ci_low"], h2["ci_high"], res["seconds"])
        written.append(path)
    return written
