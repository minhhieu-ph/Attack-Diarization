"""Load one NetFlow v3 dataset into a time-ordered flow table.

Sources, searched in every folder of `paths.data_roots`:
  1. processed/<name>/flows.{parquet,pkl}  written by the attack-diarization project
     (canonical columns + f_<lowercase NetFlow field>)
  2. raw/<name>/  NetFlow v3 CSV / parquet files, or zips containing them

Output columns: t, t_end (epoch ms), src, dst (int32 codes over one shared IP vocabulary),
label (0/1), attack (str), and the NetFlow fields listed in schema.NEEDED (float32).
"""
from __future__ import annotations

import io
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

from .config import output_dir, resolve
from .schema import NEEDED
from .utils import LOG, find_df, has_module, read_df, save_df, timer

BENIGN_NAMES = {"benign", "normal", "---", "", "nan", "none"}
ID_COLS = ["IPV4_SRC_ADDR", "IPV4_DST_ADDR", "FLOW_START_MILLISECONDS", "FLOW_END_MILLISECONDS", "Label", "Attack"]


def locate(cfg: dict, name: str) -> tuple[str, Path] | None:
    """('processed', file) | ('raw', folder) | None."""
    for root in cfg["paths"]["data_roots"]:
        root = resolve(root)
        p = find_df(root / "processed" / name / "flows")
        if p is not None:
            return "processed", p
        raw = root / "raw" / name
        if raw.is_dir() and any(raw.rglob("*")):
            return "raw", raw
    return None


# ---------------------------------------------------------------- raw NetFlow v3 files
def _read_csv(src, usecols=None) -> pd.DataFrame:
    if has_module("pyarrow"):
        try:
            return pd.read_csv(src, engine="pyarrow", usecols=usecols)
        except Exception:  # noqa: BLE001
            if hasattr(src, "seek"):
                src.seek(0)
    return pd.read_csv(src, usecols=usecols, low_memory=False)


def _wanted(header) -> list[str]:
    cols = [c.strip() for c in header]
    want = set(ID_COLS + NEEDED)
    return [c for c in header if c.strip() in want] if "IPV4_SRC_ADDR" in cols else []


def _iter_raw(folder: Path):
    files = sorted(p for p in folder.rglob("*") if p.is_file())
    for p in files:
        suf = p.suffix.lower()
        if suf == ".csv":
            use = _wanted(pd.read_csv(p, nrows=0).columns)
            if use:
                yield p.name, _read_csv(p, usecols=use)
        elif suf == ".parquet" and has_module("pyarrow"):
            import pyarrow.parquet as pq

            use = _wanted(pq.read_schema(p).names)
            if use:
                yield p.name, pd.read_parquet(p, columns=use)
        elif suf == ".zip":
            with zipfile.ZipFile(p) as zf:
                for m in zf.namelist():
                    if not m.lower().endswith(".csv"):
                        continue
                    with zf.open(m) as fh:
                        use = _wanted(pd.read_csv(fh, nrows=0).columns)
                    if use:
                        with zf.open(m) as fh:
                            yield m, _read_csv(io.BytesIO(fh.read()), usecols=use)


def _from_raw(folder: Path) -> pd.DataFrame:
    parts = []
    for name, df in _iter_raw(folder):
        LOG.info("  read %s: %d rows", name, len(df))
        df.columns = [c.strip() for c in df.columns]
        parts.append(df)
    if not parts:
        raise FileNotFoundError(f"no NetFlow v3 table (with IPV4_SRC_ADDR) under {folder}")
    df = pd.concat(parts, ignore_index=True)
    out = pd.DataFrame({
        "t": pd.to_numeric(df["FLOW_START_MILLISECONDS"], errors="coerce"),
        "t_end": pd.to_numeric(df["FLOW_END_MILLISECONDS"], errors="coerce"),
        "src_ip": df["IPV4_SRC_ADDR"].astype(str).values,
        "dst_ip": df["IPV4_DST_ADDR"].astype(str).values,
        "label": pd.to_numeric(df["Label"], errors="coerce"),
        "attack": df["Attack"].astype(str).values if "Attack" in df.columns else "Unknown",
    })
    for c in NEEDED:
        if c in df.columns:
            out[c] = pd.to_numeric(df[c], errors="coerce")
    return out


def _from_processed(path: Path) -> pd.DataFrame:
    canon = ["t_start", "t_end", "src_ip", "dst_ip", "dst_port", "protocol", "label", "attack"]
    fcols = ["f_" + c.lower() for c in NEEDED]
    df = read_df(path, columns=canon + fcols)
    out = pd.DataFrame({
        "t": df["t_start"].values, "t_end": df["t_end"].values,
        "src_ip": df["src_ip"].astype(str).values, "dst_ip": df["dst_ip"].astype(str).values,
        "label": df["label"].values, "attack": df["attack"].astype(str).values,
    })
    for c in NEEDED:
        f = "f_" + c.lower()
        if f in df.columns:
            out[c] = df[f].values
    if "L4_DST_PORT" not in out.columns and "dst_port" in df.columns:
        out["L4_DST_PORT"] = df["dst_port"].values
    if "PROTOCOL" not in out.columns and "protocol" in df.columns:
        out["PROTOCOL"] = df["protocol"].values
    return out


# ---------------------------------------------------------------- public API
def load_flows(cfg: dict, name: str) -> pd.DataFrame:
    cache = output_dir(cfg) / "cache" / name / "flows"
    hit = find_df(cache)
    if hit is not None:
        with timer(f"load cache {hit.name}"):
            df = read_df(hit)
    else:
        found = locate(cfg, name)
        if found is None:
            roots = ", ".join(str(resolve(r)) for r in cfg["paths"]["data_roots"])
            raise FileNotFoundError(f"dataset {name!r} not found under processed/ or raw/ of: {roots}")
        kind, path = found
        with timer(f"read {name} ({kind}: {path})"):
            df = _from_processed(path) if kind == "processed" else _from_raw(path)
        df = _finalize(df)
        with timer("write cache"):
            save_df(df, cache)
    missing = [c for c in NEEDED if c not in df.columns]
    if missing:
        LOG.warning("%s: NetFlow fields not found (treated as absent): %s", name, missing)
    mr = cfg.get("data", {}).get("max_rows")
    if mr:
        df = df.iloc[: int(mr)].reset_index(drop=True)
    LOG.info("%s: %d flows, %d attack flows, %d hosts, %d classes", name, len(df), int(df["label"].sum()),
             int(max(df["src"].max(), df["dst"].max()) + 1), df["attack"].nunique())
    return df


def _finalize(df: pd.DataFrame) -> pd.DataFrame:
    df = df[np.isfinite(df["t"].astype(float))].copy()
    df["t"] = df["t"].astype("int64")
    df["t_end"] = df["t_end"].fillna(df["t"]).astype("int64")
    df["label"] = df["label"].fillna(0).astype("int8").clip(0, 1)
    att = df["attack"].astype(str).str.strip()
    att = att.where(~att.str.lower().isin(BENIGN_NAMES), "Benign")
    att = att.where(df["label"] == 1, "Benign")
    att = att.where(~((df["label"] == 1) & (att == "Benign")), "Unknown")
    df["attack"] = att.astype("category")
    n = len(df)
    codes, _ = pd.factorize(np.concatenate([df["src_ip"].values, df["dst_ip"].values]))
    df["src"] = codes[:n].astype("int32")
    df["dst"] = codes[n:].astype("int32")
    df = df.drop(columns=["src_ip", "dst_ip"])
    for c in NEEDED:
        if c in df.columns:
            df[c] = df[c].astype("float32").fillna(0)
    df = df.sort_values("t", kind="stable").reset_index(drop=True)
    return df
