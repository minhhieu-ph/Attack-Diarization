"""Aggregate E0 results (outputs/e0/<dataset>/<profile>_seed<k>.json) into the gate verdict."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .utils import load_json

SHOW = ["s_C", "s_C_raw", "s_A", "s_max", "AE", "AE_conf", "IF", "IF_conf"]


def _nan(x):
    return np.nan if x is None else x


def collect(root: Path) -> list[dict]:
    return [load_json(p) for p in sorted(root.glob("*/*_seed*.json"))]


def _fmt(m, s=None, pct=True):
    if m is None or (isinstance(m, float) and np.isnan(m)):
        return "–"
    if pct:
        return f"{100 * m:.1f}" + (f" ± {100 * s:.1f}" if s is not None and s == s and s > 0 else "")
    return f"{m:.3f}" + (f" ± {s:.3f}" if s is not None and s == s and s > 0 else "")


def verdicts(results: list[dict], gate: dict) -> tuple[pd.DataFrame, dict]:
    rows = []
    for r in results:
        h1, h2 = r["h1"], r["h2"]
        rows.append({"dataset": r["dataset"], "profile": r["profile"], "seed": r["seed"],
                     "r2_cond": _nan(h1["r2_cond_mean"]), "r2_ctx": _nan(h1["r2_ctx_mean"]),
                     "r2_gain": _nan(h1["r2_gain"]), "tpr_s_C": _nan(h2["tpr_s_C"]),
                     "best_baseline": h2["best_baseline"], "tpr_best": _nan(h2["tpr_best_baseline"]),
                     "diff": _nan(h2["diff"]), "ci_low": _nan(h2["ci_low"]), "ci_high": _nan(h2["ci_high"]),
                     "n_cons": h2["n_consequence_attacks"],
                     "c3_max_group_fpr": _nan(r.get("c3_check", {}).get("max_group_fpr"))})
    tab = pd.DataFrame(rows)
    out = {}
    if tab.empty:
        return tab, {"overall": "CHƯA CÓ KẾT QUẢ", "datasets": {}}
    for ds, g in tab.groupby("dataset"):
        d = g[g["profile"] == "default"]
        s = g[g["profile"] == "strict"]
        if d.empty:
            out[ds] = {"verdict": "THIẾU PROFILE default", "reasons": []}
            continue
        reasons = []
        n_cons = int(d["n_cons"].min())
        h1 = d["r2_gain"].mean() >= gate["r2_gain_min"]
        h2 = d["diff"].mean() >= gate["tpr_gain_min"] and (d["ci_low"] > 0).mean() > 0.5
        reasons.append(f"H1 R² tăng {d['r2_gain'].mean():.3f} (ngưỡng {gate['r2_gain_min']}) → {'đạt' if h1 else 'không đạt'}")
        reasons.append(f"H2 s_C hơn {d['best_baseline'].mode().iat[0]} {100 * d['diff'].mean():.1f} điểm TPR, "
                       f"CI dưới > 0 ở {(d['ci_low'] > 0).sum()}/{len(d)} seed (ngưỡng {100 * gate['tpr_gain_min']:.0f} điểm) "
                       f"→ {'đạt' if h2 else 'không đạt'}")
        if s.empty:
            shortcut = None
            reasons.append("Shortcut: chưa chạy profile strict")
        else:
            keep = s["diff"].mean() / d["diff"].mean() if d["diff"].mean() > 0 else np.nan
            shortcut = bool(keep >= gate["shortcut_keep_frac"]) if keep == keep else False
            reasons.append(f"Shortcut: profile strict giữ {100 * keep:.0f}% mức chênh (ngưỡng "
                           f"{100 * gate['shortcut_keep_frac']:.0f}%) → {'đạt' if shortcut else 'không đạt'}"
                           if keep == keep else "Shortcut: không tính được (mức chênh mặc định ≤ 0)")
        if n_cons < gate["min_attacks"]:
            verdict = "KHÔNG ĐỦ DỮ LIỆU"
            reasons.insert(0, f"chỉ có {n_cons} flow tấn công nhóm hệ quả trong tập test (cần ≥ {gate['min_attacks']})")
        elif h1 and h2 and shortcut is not False:
            verdict = "ĐẠT" if shortcut else "ĐẠT (chưa kiểm shortcut)"
        else:
            verdict = "KHÔNG ĐẠT"
        out[ds] = {"verdict": verdict, "reasons": reasons, "h1": h1, "h2": h2, "shortcut": shortcut,
                   "n_cons": n_cons}
    passed = sum(v["verdict"].startswith("ĐẠT") for v in out.values())
    enough = sum(v["verdict"] != "KHÔNG ĐỦ DỮ LIỆU" for v in out.values())
    need = gate["datasets_needed"]
    if passed >= need:
        overall = f"GO — {passed}/{len(out)} bộ dữ liệu đạt (cần {need})"
    elif enough < need:
        overall = f"KHÔNG KẾT LUẬN ĐƯỢC — chỉ {enough} bộ có đủ tấn công nhóm hệ quả (cần {need})"
    else:
        overall = f"STOP — {passed}/{len(out)} bộ dữ liệu đạt (cần {need})"
    return tab, {"overall": overall, "datasets": out}


def write_summary(results: list[dict], gate: dict, out_dir: Path) -> Path:
    tab, v = verdicts(results, gate)
    out_dir.mkdir(parents=True, exist_ok=True)
    tab.to_csv(out_dir / "summary.csv", index=False)
    L = ["# E0 — Cổng khả thi NetACWM", "", f"**Kết luận: {v['overall']}**", ""]
    if tab.empty:
        L.append("Chưa có file kết quả nào trong outputs/e0/.")
    for ds, info in v["datasets"].items():
        L += [f"## {ds}: {info['verdict']}", ""] + [f"- {x}" for x in info["reasons"]] + [""]
        rs = [r for r in results if r["dataset"] == ds]
        for prof in ("default", "strict"):
            rp = [r for r in rs if r["profile"] == prof]
            if not rp:
                continue
            gf = rp[0]["h2"]["gate_fpr"]
            key = f"tpr@{gf:g}"
            r0 = rp[0]
            L += [f"### Profile `{prof}` — {len(rp)} seed; regressor {r0['regressor_backend']} "
                  f"({r0['regressor_device']}), AE {r0['ae_backend']}", ""]
            L += [f"Tập test: {r0['split']['test_benign']:,} flow benign, {r0['split']['test_attack']:,} flow tấn công. "
                  f"R² trung bình: có hành động {_fmt(np.mean([_nan(r['h1']['r2_cond_mean']) for r in rp]), pct=False)}, "
                  f"chỉ ngữ cảnh {_fmt(np.mean([_nan(r['h1']['r2_ctx_mean']) for r in rp]), pct=False)}.", ""]
            L += [f"TPR (%) tại FPR {gf:g}, theo nhóm tấn công (trung bình ± độ lệch giữa các seed):", "",
                  "| Bộ chấm | Nhóm hệ quả | Nhóm hành động | Nhóm hỗn hợp | Tất cả | ROC-AUC tất cả |",
                  "|---|---|---|---|---|---|"]
            for s in SHOW:
                cells = []
                for g in ("consequence", "action", "mixed", "all"):
                    vals = np.array([_nan(r["metrics"][s][g][key]) for r in rp], dtype=float)
                    cells.append(_fmt(np.nanmean(vals), np.nanstd(vals)) if np.isfinite(vals).any() else "–")
                auc = np.array([_nan(r["metrics"][s]["all"]["roc_auc"]) for r in rp], dtype=float)
                cells.append(_fmt(np.nanmean(auc), np.nanstd(auc), pct=False) if np.isfinite(auc).any() else "–")
                L.append(f"| {s} | " + " | ".join(cells) + " |")
            n = rp[0]["metrics"]["s_C"]
            L += ["", f"Số flow tấn công: hệ quả {n['consequence']['n_attack']:,}, hành động {n['action']['n_attack']:,}, "
                      f"hỗn hợp {n['mixed']['n_attack']:,}.", ""]
            c3 = [r.get("c3_check", {}) for r in rp]
            mx = [c.get("max_group_fpr") for c in c3 if c.get("max_group_fpr") is not None]
            if mx:
                L += [f"Kiểm tra C3: với ngưỡng α = {gf:g}, FPR lớn nhất trên một nhóm dịch vụ (≥ 1000 flow benign "
                      f"test) là {100 * max(mx):.3f}%; FPR toàn cục {100 * np.mean([c['global_fpr'] for c in c3]):.3f}%.", ""]
            if prof == "default":
                L += [f"TPR (%) tại FPR {gf:g} theo từng lớp tấn công (seed {rp[0]['seed']}):", "",
                      "| Lớp | Nhóm | n | s_C | s_A | s_max | AE | IF |", "|---|---|---|---|---|---|---|---|"]
                for cls, d in sorted(rp[0]["per_class"].items(), key=lambda kv: (kv[1]["family"], kv[0])):
                    L.append(f"| {cls} | {d['family']} | {d['n']:,} | " + " | ".join(
                        _fmt(_nan(d[s])) for s in ("s_C", "s_A", "s_max", "AE", "IF")) + " |")
                L.append("")
    L += ["---", "Ghi chú: nhóm hệ quả = backdoor, bot, infiltration, ransomware, theft, exfil; nhóm hành động = "
          "scan, DoS/DDoS, brute force, password, fuzzers; còn lại là hỗn hợp (`families` trong configs/default.yaml).",
          "s_C so với baseline tốt nhất trong AE, AE_conf, IF, IF_conf (chọn theo TPR nhóm hệ quả, tức thiên về baseline).", ""]
    path = out_dir / "summary.md"
    path.write_text("\n".join(L), encoding="utf-8")
    return path
