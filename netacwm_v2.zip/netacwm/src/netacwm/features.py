"""Feature construction: causal context, delayed consequence (C2), and the action /
consequence matrices for a subset of rows.

Context and C2 are computed on the FULL time-ordered stream (benign + attack), as a sensor
would see it; matrices are then built only for the rows a split selects.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .schema import PROTOCOLS, TCP_FLAG_BITS, WELL_KNOWN_PORTS, Profile

I64_MAX = 9.0e18


def _offset_keys(key: np.ndarray, t: np.ndarray, extra: int):
    """Sort by (key, t) and return order, sorted keys, sorted times and a monotone int64
    'adjusted time' adj = key * span + t, so window queries become one searchsorted."""
    key = key.astype(np.int64)
    span = int(t.max()) + extra + 2
    if (int(key.max()) + 1) * span > I64_MAX:
        raise OverflowError("time span x number of keys too large for int64 offsets")
    order = np.lexsort((t, key))
    k, tt = key[order], t[order]
    return order, k, tt, k * span + tt, span


def causal_context(t_ms: np.ndarray, src: np.ndarray, dst: np.ndarray, windows_sec) -> tuple[np.ndarray, list[str]]:
    """Per flow, from the flows that STARTED BEFORE it: counts from the same source, to the same
    destination and between the same pair in the last W seconds, plus the gap since the previous one."""
    t = (t_ms - t_ms.min()).astype(np.int64)
    w_ms = [int(round(w * 1000)) for w in windows_sec]
    n_ip = int(max(src.max(), dst.max())) + 1
    pair = pd.factorize(src.astype(np.int64) * n_ip + dst.astype(np.int64))[0]
    cols, names = [], []
    for kname, key in (("src", src), ("dst", dst), ("pair", pair)):
        order, k, tt, adj, _ = _offset_keys(key, t, max(w_ms))
        pos = np.arange(len(adj))
        inv = np.empty_like(order)
        inv[order] = pos
        for w, wm in zip(windows_sec, w_ms):
            cnt = pos - np.searchsorted(adj, adj - wm, side="left")
            cols.append(np.log1p(cnt.astype(np.float64))[inv])
            names.append(f"ctx_{kname}_n{w:g}s")
        gap = np.full(len(adj), 3600.0)
        same = k[1:] == k[:-1]
        gap[1:] = np.where(same, np.minimum((tt[1:] - tt[:-1]) / 1000.0, 3600.0), 3600.0)
        cols.append(np.log1p(gap)[inv])
        names.append(f"ctx_{kname}_gap")
    return np.column_stack(cols).astype(np.float32), names


def delayed_consequence(t_ms, t_end_ms, src, dst, sent_bytes, delta_sec: float) -> tuple[np.ndarray, list[str]]:
    """C2: what the destination host initiates itself in (flow end, flow end + delta]:
    number of flows and bytes it sends (e.g. a callback, lateral movement, exfiltration)."""
    t0 = min(int(t_ms.min()), int(t_end_ms.min()))
    ts = (t_ms - t0).astype(np.int64)
    te = np.maximum(t_end_ms - t0, ts).astype(np.int64)
    d = int(round(delta_sec * 1000))
    order, k, tt, adj, span = _offset_keys(src, np.maximum(ts, 0), int(te.max() - ts.min()) + d)
    if (int(max(src.max(), dst.max())) + 1) * span > I64_MAX:
        raise OverflowError("time span x number of hosts too large for int64 offsets")
    cs = np.concatenate([[0.0], np.cumsum(sent_bytes[order].astype(np.float64))])
    q = dst.astype(np.int64) * span + te
    lo = np.searchsorted(adj, q, side="right")
    hi = np.searchsorted(adj, q + d, side="right")
    cnt = (hi - lo).astype(np.float64)
    byt = np.maximum(cs[hi] - cs[lo], 0.0)
    return (np.column_stack([np.log1p(cnt), np.log1p(byt)]).astype(np.float32),
            ["c2_dst_new_flows", "c2_dst_sent_bytes"])


# ---------------------------------------------------------------- categorical vocab
def _top(values: np.ndarray, k: int) -> list:
    vc = pd.Series(values).value_counts()
    return list(vc.index[:k])


def _codes(values: np.ndarray, top: list) -> np.ndarray:
    m = {v: i for i, v in enumerate(top)}
    return np.array(pd.Series(values).map(m).fillna(len(top)).astype(np.int32).values, copy=True)


def _cat_values(df: pd.DataFrame, col: str, rows: np.ndarray) -> np.ndarray:
    if col not in df.columns:
        return np.zeros(len(rows), dtype=np.float64)
    v = df[col].values[rows].astype(np.float64)
    return np.round(v, 3)


def fit_vocab(df: pd.DataFrame, rows: np.ndarray, cfg: dict, profile: Profile) -> dict:
    """Category lists. features.port_vocab = fixed (v2 default): one port / protocol list for every
    network, so models trained on one network see the same columns on another. = data (v1): top-K
    ports by frequency in the TRAINING benign rows. Other categorical fields (L7, DNS type, ICMP;
    default profile only) are always taken from the training rows."""
    fc = cfg["features"]
    fixed = fc.get("port_vocab", "fixed") == "fixed"
    voc = {}
    for col in profile.action_cat:
        if fixed and col == "L4_DST_PORT":
            voc[col] = [float(p) for p in WELL_KNOWN_PORTS]
        elif fixed and col == "PROTOCOL":
            voc[col] = [float(p) for p in PROTOCOLS]
        else:
            k = {"L4_DST_PORT": fc["top_ports"], "L7_PROTO": fc["top_l7"], "PROTOCOL": 3}.get(col, 8)
            voc[col] = _top(_cat_values(df, col, rows), k)
    return voc


PORT_BUCKETS = ["other_lt1024", "other_registered", "other_ephemeral"]


def _port_codes(values: np.ndarray, top: list) -> np.ndarray:
    """Listed ports keep their own code; the rest go to <1024, 1024-49151 or >=49152."""
    c = _codes(values, top)
    other = c == len(top)
    c[other & (values >= 1024)] = len(top) + 1
    c[other & (values >= 49152)] = len(top) + 2
    return c


def n_port_codes(vocab: dict) -> int:
    return len(vocab.get("L4_DST_PORT", [])) + len(PORT_BUCKETS)


def _onehot(codes: np.ndarray, n: int) -> np.ndarray:
    out = np.zeros((len(codes), n), dtype=np.float32)
    out[np.arange(len(codes)), codes] = 1.0
    return out


def _log1p_cols(df, cols, rows):
    out = np.zeros((len(rows), len(cols)), dtype=np.float32)
    for j, c in enumerate(cols):
        if c in df.columns:
            out[:, j] = np.log1p(np.clip(df[c].values[rows].astype(np.float64), 0, None))
    return out


def _flag_bits(df, col, rows, prefix):
    v = df[col].values[rows].astype(np.int64) if col in df.columns else np.zeros(len(rows), np.int64)
    bits = np.column_stack([(v >> b) & 1 for b in range(8)]).astype(np.float32)
    return bits, [f"{prefix}_{n}" for n in TCP_FLAG_BITS]


@dataclass
class Matrices:
    rows: np.ndarray
    ctx: np.ndarray
    act: np.ndarray
    y: np.ndarray
    group: np.ndarray          # service group (protocol x port bucket) for Mondrian calibration
    names_ctx: list[str]
    names_act: list[str]
    names_y: list[str]


def build(df: pd.DataFrame, rows: np.ndarray, ctx_all: np.ndarray, ctx_names: list[str],
          c2_all: np.ndarray | None, c2_names: list[str], vocab: dict, profile: Profile) -> Matrices:
    rows = np.asarray(rows)
    # action
    parts, names = [_log1p_cols(df, profile.action_num, rows)], [f"a_{c.lower()}" for c in profile.action_num]
    for col in profile.action_flags:
        b, n = _flag_bits(df, col, rows, "a_cflag")
        parts.append(b)
        names += n
    port_codes = proto_codes = None
    for col in profile.action_cat:
        vals = _cat_values(df, col, rows)
        top = vocab[col]
        if col == "L4_DST_PORT":
            codes, n_cat = _port_codes(vals, top), len(top) + len(PORT_BUCKETS)
            port_codes = codes
            labels = [f"{int(p)}" for p in top] + PORT_BUCKETS
        else:
            codes, n_cat = _codes(vals, top), len(top) + 1
            labels = [f"{v:g}" for v in top] + ["other"]
            if col == "PROTOCOL":
                proto_codes = codes
        parts.append(_onehot(codes, n_cat))
        names += [f"a_{col.lower()}={lab}" for lab in labels]
    act = np.concatenate(parts, axis=1)

    # consequence C1 (+ C2)
    yparts, ynames = [_log1p_cols(df, profile.conseq_num, rows)], [f"c_{c.lower()}" for c in profile.conseq_num]
    for col in profile.conseq_flags:
        b, n = _flag_bits(df, col, rows, "c_sflag")
        yparts.append(b)
        ynames += n
    if profile.use_ftp:
        code = df["FTP_COMMAND_RET_CODE"].values[rows] if "FTP_COMMAND_RET_CODE" in df.columns else np.zeros(len(rows))
        yparts.append(np.column_stack([code > 0, code >= 400]).astype(np.float32))
        ynames += ["c_ftp_has_code", "c_ftp_error"]
    if c2_all is not None:
        yparts.append(c2_all[rows])
        ynames += c2_names
    y = np.concatenate(yparts, axis=1)

    n_port = n_port_codes(vocab)
    pc = port_codes if port_codes is not None else np.zeros(len(rows), np.int32)
    prc = proto_codes if proto_codes is not None else np.zeros(len(rows), np.int32)
    group = (prc.astype(np.int64) * n_port + pc).astype(np.int32)
    return Matrices(rows, ctx_all[rows], act, y, group, ctx_names, names, ynames)


# ---------------------------------------------------------------- per-network context scale
class CtxNorm:
    """Per-environment normalization of the causal-context columns (v2).

    Context counts ("this source opened 40 flows in the last 10 s") depend on the size of the
    network, so the same number means "busy" in one network and "quiet" in another. Each
    environment gets its own normalizer, fitted on that environment's own benign reference rows
    (the training rows of a source network, the calibration window of a target network).

    quantile  mid-rank in the reference (0..1), continued linearly beyond the reference range in
              units of the reference IQR so that extremes (scan bursts) stay ordered
    robust    (x - median) / IQR
    none      unchanged (v1 behaviour)
    """

    def __init__(self, mode: str = "quantile", max_ref: int = 200_000, seed: int = 0):
        if mode not in ("quantile", "robust", "none"):
            raise ValueError(f"ctx_norm must be quantile | robust | none, got {mode!r}")
        self.mode, self.max_ref, self.seed = mode, max_ref, seed

    def fit(self, X: np.ndarray) -> "CtxNorm":
        if self.mode == "none" or len(X) == 0:
            return self
        X = np.asarray(X, dtype=np.float64)
        if len(X) > self.max_ref:
            X = X[np.random.default_rng(self.seed).choice(len(X), self.max_ref, replace=False)]
        q25, q50, q75 = np.quantile(X, [0.25, 0.5, 0.75], axis=0)
        self.med = q50
        self.iqr = np.maximum(q75 - q25, np.maximum(X.std(0), 0.1))
        if self.mode == "quantile":
            self.ref = np.sort(X, axis=0)
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        if self.mode == "none" or not hasattr(self, "med"):
            return np.asarray(X, dtype=np.float32)
        X = np.asarray(X, dtype=np.float64)
        if self.mode == "robust":
            return ((X - self.med) / self.iqr).astype(np.float32)
        out = np.empty_like(X)
        n = len(self.ref)
        for j in range(X.shape[1]):
            r = self.ref[:, j]
            lo = np.searchsorted(r, X[:, j], side="left")
            hi = np.searchsorted(r, X[:, j], side="right")
            q = (lo + hi) / (2.0 * n)
            q += np.maximum(X[:, j] - r[-1], 0.0) / self.iqr[j] - np.maximum(r[0] - X[:, j], 0.0) / self.iqr[j]
            out[:, j] = q
        return out.astype(np.float32)
