"""Step 0 of v2 (minutes, CPU only): show how each dataset splits into capture days, how many benign
and attack flows each day holds, and which days the time-shift experiment will use as targets.

  python scripts/inspect_time.py --config configs/a100.yaml
  python scripts/inspect_time.py --config configs/a100.yaml --datasets nf_cse_cic_ids2018_v3 --mode gap

Writes outputs/inspect/<dataset>.md (send these back before running the long jobs).
"""
import numpy as np
import pandas as pd
from _cli import base_parser, setup

from netacwm.config import output_dir
from netacwm.data import load_flows
from netacwm.envs import segments
from netacwm.utils import LOG, save_json


def main():
    p = base_parser(__doc__)
    p.add_argument("--datasets", nargs="*", default=None)
    p.add_argument("--mode", choices=["day", "gap"], default=None)
    a = p.parse_args()
    cfg = setup(a)
    tc = cfg["shift"]["time"]
    names = a.datasets or sorted(set(tc["datasets"]) | set(cfg["shift"]["cross"]["datasets"]))
    out = output_dir(cfg) / "inspect"
    out.mkdir(parents=True, exist_ok=True)
    for name in names:
        df = load_flows(cfg, name)
        tz = tc.get("tz_offset_hours", {})
        tz = tz.get(name, 0.0) if isinstance(tz, dict) else float(tz)
        mode = a.mode or tc["segment"]
        segs = segments(df["t"].values, df["label"].values, df["attack"].values, mode, tz, tc.get("gap_hours", 3))
        hist = np.cumsum([0] + [s.n_benign for s in segs])
        t = df["t"].values
        L = [f"# {name}", "",
             f"{len(df):,} flows, {int(df['label'].sum()):,} attack flows. Start {pd.Timestamp(int(t[0]), unit='ms')} UTC, "
             f"end {pd.Timestamp(int(t[-1]), unit='ms')} UTC. Segment mode `{mode}`, UTC offset {tz:+g} h.", "",
             "| # | Segment | Hours | Benign | Attack | Target? | Attack classes (flows) |", "|---|---|---|---|---|---|---|"]
        for s in segs:
            target = (s.index >= tc.get("first_target", 1) and s.n_benign >= tc["min_benign"]
                      and hist[s.index] >= tc.get("min_history", 100_000))
            top = ", ".join(f"{k} ({v:,})" for k, v in list(s.attacks.items())[:6])
            L.append(f"| {s.index} | {s.label} | {(s.t1 - s.t0) / 3.6e6:.1f} | {s.n_benign:,} | {s.n_attack:,} | "
                     f"{'yes' if target else ''} | {top} |")
        # benign flows per hour of the day (local time) - shows when the capture is active
        hh = ((t[df['label'].values == 0] + int(tz * 3.6e6)) // 3_600_000) % 24
        per_h = np.bincount(hh, minlength=24)
        L += ["", "Benign flows by local hour: " + " ".join(f"{h}h:{v:,}" for h, v in enumerate(per_h)), ""]
        (out / f"{name}.md").write_text("\n".join(L), encoding="utf-8")
        save_json({"dataset": name, "mode": mode, "tz": tz, "segments": [s.as_dict() for s in segs]},
                  out / f"{name}.json")
        print("\n".join(L))
        LOG.info("written %s", out / f"{name}.md")


if __name__ == "__main__":
    main()
