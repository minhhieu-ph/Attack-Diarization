"""Rebuild outputs/shift/summary.md from the result files (no computation)."""
from _cli import base_parser, setup

from netacwm.config import output_dir
from netacwm.shift_report import write_shift_summary


def main():
    a = base_parser(__doc__).parse_args()
    cfg = setup(a)
    print(write_shift_summary(output_dir(cfg) / "shift", cfg))


if __name__ == "__main__":
    main()
