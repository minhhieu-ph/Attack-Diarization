"""v2 environment-shift experiments in ONE process (one GPU). Finished results are skipped.

  # step 1: time shift (train on earlier days, test the next day) on CSE-CIC-IDS2018
  python scripts/run_shift.py --config configs/a100.yaml --exp time --seeds 0
  # step 2: cross-network transfer with one target network
  python scripts/run_shift.py --config configs/a100.yaml --exp cross --targets nf_unsw_nb15_v3 --seeds 0
  # step 3: add the onboarding arms (fine-tune on 15 min / 1 h / 4 h of the target)
  python scripts/run_shift.py --config configs/a100.yaml --exp cross --set shift.onboard.enabled=true

For all jobs on several GPUs at once use scripts/run_shift_parallel.py.
"""
from _cli import base_parser, setup

from netacwm.config import output_dir
from netacwm.shift import run_cross_target, run_time_dataset
from netacwm.shift_report import write_shift_summary
from netacwm.utils import LOG, resolve_device


def main():
    p = base_parser(__doc__)
    p.add_argument("--exp", choices=["time", "cross"], required=True)
    p.add_argument("--datasets", nargs="*", default=None, help="time: datasets (default shift.time.datasets)")
    p.add_argument("--days", nargs="*", default=None, help="time: only these segment labels, e.g. 2018-02-16")
    p.add_argument("--targets", nargs="*", default=None, help="cross: target networks (default all)")
    p.add_argument("--profile", default=None)
    p.add_argument("--seeds", nargs="*", type=int, default=None)
    p.add_argument("--force", action="store_true")
    p.add_argument("--no-report", action="store_true")
    a = p.parse_args()
    cfg = setup(a)
    device = resolve_device(cfg)
    sc = cfg["shift"]
    profile = a.profile or sc["profile"]
    seeds = a.seeds if a.seeds is not None else sc["seeds"]
    root = output_dir(cfg) / "shift"
    LOG.info("device: %s | profile %s | seeds %s", device, profile, seeds)
    if a.exp == "time":
        for ds in a.datasets or sc["time"]["datasets"]:
            run_time_dataset(cfg, ds, profile, seeds, device, root / "time", a.force, a.days)
    else:
        for t in a.targets or sc["cross"]["datasets"]:
            run_cross_target(cfg, t, profile, seeds, device, root / "cross", a.force)
    if not a.no_report:
        LOG.info("summary: %s", write_shift_summary(root, cfg))


if __name__ == "__main__":
    main()
