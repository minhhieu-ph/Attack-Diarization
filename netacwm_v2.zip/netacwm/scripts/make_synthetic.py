"""Write synthetic NetFlow v3 CSVs to dataset/raw/ for the smoke tests.

  python scripts/make_synthetic.py            # synth_nf (E0 smoke test)
  python scripts/make_synthetic.py --shift    # synth_a, synth_b, synth_c (v2 shift smoke test)

synth_a  4 days, the reference network
synth_b  other hosts, other service mix, clients send 1.5x bigger requests - SAME consequence law
synth_c  other hosts and a DIFFERENT law (http replies 4x, https 0.3x, dns 2x): transfer should fail
"""
import argparse

from _cli import ROOT

from netacwm.synth import make_synth

SHIFT_ENVS = {
    "synth_a": dict(days=4, seed=11),
    "synth_b": dict(days=3, seed=12, n_clients=25, probs=[0.15, 0.45, 0.15, 0.15, 0.05, 0.05], size_scale=1.5,
                    subnet="172.16"),
    "synth_c": dict(days=3, seed=13, law={"http": 4.0, "https": 0.3, "dns": 2.0}, subnet="192.168"),
}


def write(name: str, df):
    out = ROOT / "dataset" / "raw" / name / f"{name}.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    for f in (ROOT / "outputs" / "cache" / name).glob("flows.*"):
        f.unlink()
    print(f"wrote {out} ({len(df):,} flows; attacks: {df['Attack'].value_counts().to_dict()})")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--n-benign", type=int, default=150_000)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--shift", action="store_true", help="write the three shift networks instead")
    a = p.parse_args()
    if a.shift:
        for name, kw in SHIFT_ENVS.items():
            write(name, make_synth(a.n_benign, **kw))
    else:
        write("synth_nf", make_synth(a.n_benign, a.seed))


if __name__ == "__main__":
    main()
