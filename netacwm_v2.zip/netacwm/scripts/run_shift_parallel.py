"""Run the v2 shift experiments on several GPUs at once (one process per GPU slot).

Jobs: time shift = one job per (dataset, seed), all target days inside; cross = one job per
(target network, seed). Finished results are skipped on rerun.

  python scripts/run_shift_parallel.py --config configs/a100.yaml --exp time            # step 1
  python scripts/run_shift_parallel.py --config configs/a100.yaml --exp cross           # step 2
  python scripts/run_shift_parallel.py --config configs/a100.yaml --exp time cross      # both
  python scripts/run_shift_parallel.py --config configs/a100.yaml --exp cross --set shift.onboard.enabled=true

Logs: outputs/logs/shift_<exp>_<n>.log. Summary: outputs/shift/summary.md
"""
import sys

from _cli import base_parser
from run_parallel import gpu_ids, run_pool

from netacwm.config import load_config, output_dir
from netacwm.shift_report import write_shift_summary
from netacwm.utils import available_cpus


def main():
    p = base_parser(__doc__)
    p.add_argument("--exp", nargs="+", choices=["time", "cross"], required=True)
    p.add_argument("--seeds", nargs="*", type=int, default=None)
    p.add_argument("--targets", nargs="*", default=None)
    p.add_argument("--gpus", default=None)
    p.add_argument("--jobs-per-gpu", type=int, default=1)
    p.add_argument("--force", action="store_true")
    a = p.parse_args()
    cfg = load_config(a.config, a.overrides)
    sc = cfg["shift"]
    seeds = a.seeds if a.seeds is not None else sc["seeds"]
    gpus = a.gpus.split(",") if a.gpus else (gpu_ids() or [None])
    slots = [g for g in gpus for _ in range(a.jobs_per_gpu)]
    threads = max(1, (available_cpus() - 2) // len(slots))
    common = sum((["--config", c] for c in a.config), []) + sum((["--set", o] for o in a.overrides), [])
    common += ["--set", f"compute.n_jobs={threads}", "--no-report"] + (["--force"] if a.force else [])
    cmds, names = [], []
    if "cross" in a.exp:        # cross jobs first: they load three datasets and take longest
        for t in a.targets or sc["cross"]["datasets"]:
            for s in seeds:
                cmds.append([sys.executable, "scripts/run_shift.py", *common, "--exp", "cross", "--targets", t,
                             "--seeds", str(s)])
                names.append("cross")
    if "time" in a.exp:
        for d in sc["time"]["datasets"]:
            for s in seeds:
                cmds.append([sys.executable, "scripts/run_shift.py", *common, "--exp", "time", "--datasets", d,
                             "--seeds", str(s)])
                names.append("time")
    log_dir = output_dir(cfg) / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    print(f"{len(cmds)} jobs on slots {slots} | {threads} CPU threads per job")
    failed = run_pool(cmds, slots, log_dir, prefix="shift")
    path = write_shift_summary(output_dir(cfg) / "shift", cfg)
    print(f"summary: {path}" + (f" | {failed} job(s) failed, see {log_dir}" if failed else ""))


if __name__ == "__main__":
    main()
