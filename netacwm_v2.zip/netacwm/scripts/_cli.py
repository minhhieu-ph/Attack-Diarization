"""Shared command-line setup for the scripts."""
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from netacwm.config import load_config  # noqa: E402
from netacwm.utils import setup_threads  # noqa: E402


def base_parser(doc: str) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=doc, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--config", action="append", default=[], help="extra YAML merged over configs/default.yaml")
    p.add_argument("--set", action="append", default=[], dest="overrides", help="key.sub=value override")
    return p


def setup(args) -> dict:
    cfg = load_config(args.config, args.overrides)
    setup_threads(cfg)
    return cfg
