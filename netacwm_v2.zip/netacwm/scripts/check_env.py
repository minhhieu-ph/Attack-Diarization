"""Check packages, GPUs, usable CPUs and where each configured dataset is found."""
import importlib
import platform
import shutil
import subprocess
import sys

from _cli import base_parser

from netacwm.config import load_config, resolve
from netacwm.data import locate
from netacwm.utils import available_cpus

OK, BAD = "\033[32mOK\033[0m", "\033[31mMISSING\033[0m"


def main():
    a = base_parser(__doc__).parse_args()
    cfg = load_config(a.config, a.overrides)
    print(f"python {sys.version.split()[0]} on {platform.platform()} | usable CPUs: {available_cpus()}")
    for m, why in [("numpy", ""), ("pandas", ""), ("pyarrow", "parquet IO"), ("sklearn", ""), ("scipy", ""),
                   ("yaml", ""), ("xgboost", "GPU regressor (else slow sklearn fallback)"),
                   ("torch", "autoencoder baseline (else PCA)")]:
        try:
            mod = importlib.import_module(m)
            print(f"  {m:<9} {getattr(mod, '__version__', '?'):<12} {OK}")
        except Exception:  # noqa: BLE001
            print(f"  {m:<9} {'':<12} {BAD} {why}")
    if shutil.which("nvidia-smi"):
        print(subprocess.run(["nvidia-smi", "--query-gpu=index,name,memory.total,driver_version",
                              "--format=csv,noheader"], capture_output=True, text=True).stdout.strip())
    try:
        import numpy as np
        import xgboost as xgb

        X = np.random.rand(2000, 5).astype("float32")
        xgb.XGBRegressor(n_estimators=5, device="cuda", tree_method="hist").fit(X, X[:, :2])
        print(f"xgboost multi-output on GPU: {OK}")
    except Exception as e:  # noqa: BLE001
        print(f"xgboost GPU check: {e.__class__.__name__}: {str(e)[:120]} (CPU will be used)")
    try:
        import torch

        print(f"torch {torch.__version__} cuda={torch.cuda.is_available()} devices={torch.cuda.device_count()}")
    except Exception:  # noqa: BLE001
        pass
    print("data roots:", ", ".join(str(resolve(r)) for r in cfg["paths"]["data_roots"]))
    for ds in cfg["data"]["datasets"]:
        found = locate(cfg, ds)
        print(f"  {ds:<24} " + (f"{OK} {found[0]}: {found[1]}" if found else f"{BAD} (not under processed/ or raw/)"))


if __name__ == "__main__":
    main()
