"""E0 feasibility gate in ONE process (one GPU). Finished (dataset, profile, seed) results are skipped.

  python scripts/run_e0.py --config configs/a100.yaml --datasets nf_ton_iot_v3 --profiles default --seeds 0
  python scripts/run_e0.py --config configs/smoke.yaml          # synthetic data

For all datasets on several GPUs at once use scripts/run_parallel.py.
"""
from _cli import base_parser, setup

from netacwm.config import output_dir
from netacwm.e0 import run_dataset
from netacwm.report import collect, write_summary
from netacwm.utils import LOG, resolve_device


def main():
    p = base_parser(__doc__)
    p.add_argument("--datasets", nargs="*", default=None)
    p.add_argument("--profiles", nargs="*", default=None, help="default | strict (default: features.profiles)")
    p.add_argument("--seeds", nargs="*", type=int, default=None)
    p.add_argument("--force", action="store_true", help="rerun even if the result file exists")
    p.add_argument("--no-report", action="store_true")
    a = p.parse_args()
    cfg = setup(a)
    device = resolve_device(cfg)
    LOG.info("device: %s", device)
    out = output_dir(cfg) / "e0"
    for ds in a.datasets or cfg["data"]["datasets"]:
        run_dataset(cfg, ds, a.profiles or cfg["features"]["profiles"], a.seeds if a.seeds is not None else cfg["seeds"],
                    device, out, a.force)
    if not a.no_report:
        path = write_summary(collect(out), cfg["gate"], out)
        LOG.info("summary: %s", path)


if __name__ == "__main__":
    main()
