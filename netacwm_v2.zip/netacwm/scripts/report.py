"""Rebuild outputs/e0/summary.md and summary.csv from the result files."""
from _cli import base_parser

from netacwm.config import load_config, output_dir
from netacwm.report import collect, write_summary


def main():
    a = base_parser(__doc__).parse_args()
    cfg = load_config(a.config, a.overrides)
    out = output_dir(cfg) / "e0"
    path = write_summary(collect(out), cfg["gate"], out)
    print(path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
