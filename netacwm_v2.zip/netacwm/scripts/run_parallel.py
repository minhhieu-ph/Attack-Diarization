"""Run E0 on several GPUs at once: one process per GPU slot, each sees a single GPU through
CUDA_VISIBLE_DEVICES. A job = one dataset x one profile (all seeds, so the dataset and its
context features are built once per job). Finished results are skipped on rerun.

  python scripts/run_parallel.py --config configs/a100.yaml                     # 8x A100
  python scripts/run_parallel.py --config configs/b300.yaml --jobs-per-gpu 3    # 1x B300
  python scripts/run_parallel.py --config configs/a100.yaml --granularity seed  # one job per seed

Logs: outputs/logs/e0_<n>.log. The summary is written at the end: outputs/e0/summary.md
"""
import os
import subprocess
import sys
import time

from _cli import ROOT, base_parser

from netacwm.config import load_config, output_dir
from netacwm.report import collect, write_summary
from netacwm.utils import available_cpus


def gpu_ids():
    try:
        out = subprocess.run(["nvidia-smi", "-L"], capture_output=True, text=True, timeout=20).stdout
        return [str(i) for i in range(sum(1 for l in out.splitlines() if l.startswith("GPU")))]
    except (OSError, subprocess.SubprocessError):
        return []


def main():
    p = base_parser(__doc__)
    p.add_argument("--datasets", nargs="*", default=None)
    p.add_argument("--profiles", nargs="*", default=None)
    p.add_argument("--seeds", nargs="*", type=int, default=None)
    p.add_argument("--gpus", default=None, help="e.g. 0,1,2,3 (default: all)")
    p.add_argument("--jobs-per-gpu", type=int, default=1)
    p.add_argument("--granularity", choices=["profile", "seed"], default="profile")
    p.add_argument("--force", action="store_true")
    a = p.parse_args()
    cfg = load_config(a.config, a.overrides)
    datasets = a.datasets or cfg["data"]["datasets"]
    profiles = a.profiles or cfg["features"]["profiles"]
    seeds = a.seeds if a.seeds is not None else cfg["seeds"]
    gpus = a.gpus.split(",") if a.gpus else (gpu_ids() or [None])
    slots = [g for g in gpus for _ in range(a.jobs_per_gpu)]
    threads = max(1, (available_cpus() - 2) // len(slots))
    common = sum((["--config", c] for c in a.config), []) + sum((["--set", o] for o in a.overrides), [])
    common += ["--set", f"compute.n_jobs={threads}", "--no-report"] + (["--force"] if a.force else [])
    if a.granularity == "seed":
        jobs = [(d, pr, [s]) for d in datasets for pr in profiles for s in seeds]
    else:
        jobs = [(d, pr, seeds) for d in datasets for pr in profiles]
    # biggest datasets first so the pool finishes evenly
    order = {"nf_cse_cic_ids2018_v3": 0, "nf_ton_iot_v3": 1, "nf_bot_iot_v3": 2, "nf_unsw_nb15_v3": 3}
    jobs.sort(key=lambda j: order.get(j[0], 9))
    cmds = [[sys.executable, "scripts/run_e0.py", *common, "--datasets", d, "--profiles", pr,
             "--seeds", *map(str, ss)] for d, pr, ss in jobs]
    log_dir = output_dir(cfg) / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    print(f"{len(cmds)} jobs on slots {slots} | {threads} CPU threads per job")
    failed = run_pool(cmds, slots, log_dir)
    out = output_dir(cfg) / "e0"
    path = write_summary(collect(out), cfg["gate"], out)
    print(f"summary: {path}" + (f" | {failed} job(s) failed, see {log_dir}" if failed else ""))


def run_pool(cmds, slots, log_dir, prefix="e0"):
    free, running, queue, failed = list(slots), {}, list(enumerate(cmds)), 0
    while queue or running:
        while queue and free:
            i, cmd = queue.pop(0)
            slot = free.pop(0)
            env = dict(os.environ)
            if slot is not None:
                env["CUDA_VISIBLE_DEVICES"] = slot
            log = open(log_dir / f"{prefix}_{i:02d}.log", "w")
            print(f"[start] #{i} {'GPU ' + slot if slot is not None else 'CPU'}: {' '.join(cmd[-6:])}", flush=True)
            proc = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
            running[proc] = (i, slot, log)
        time.sleep(5)
        for proc in [pr for pr in running if pr.poll() is not None]:
            i, slot, log = running.pop(proc)
            log.close()
            free.append(slot)
            failed += proc.returncode != 0
            print(f"[done ] #{i} rc={proc.returncode} log={log_dir / f'{prefix}_{i:02d}.log'}", flush=True)
    return failed


if __name__ == "__main__":
    main()
