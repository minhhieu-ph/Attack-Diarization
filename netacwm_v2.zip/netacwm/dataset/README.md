# dataset/

Code tìm từng bộ NetFlow v3 theo thứ tự sau, trong mỗi thư mục của `paths.data_roots`
(mặc định là `dataset/` này, rồi đến `../attack-diarization/dataset/`):

1. `processed/<tên>/flows.parquet` (hoặc `.pkl`): file do `scripts/prepare.py` của dự án
   attack-diarization ghi ra. Các bộ đã tải đợt trước đều có sẵn dạng này.
2. `raw/<tên>/`: CSV / parquet gốc của UQ, hoặc file zip chứa chúng. Code tự đọc các bảng
   có cột `IPV4_SRC_ADDR`.

| tên | nguồn |
|---|---|
| `nf_unsw_nb15_v3` | https://staff.itee.uq.edu.au/marius/NIDS_datasets/ |
| `nf_ton_iot_v3` | như trên |
| `nf_cse_cic_ids2018_v3` | như trên |
| `nf_bot_iot_v3` | như trên; gần như không có benign nên không chạy mặc định |
| `synth_nf` | dữ liệu tổng hợp cho smoke test (`python scripts/make_synthetic.py`) |

Sau lần đọc đầu tiên, bảng đã chuẩn hóa được lưu ở `outputs/cache/<tên>/` để các lần sau
đọc nhanh hơn. Nếu đổi nguồn dữ liệu thì xóa cache này bằng `make clean-cache`.
