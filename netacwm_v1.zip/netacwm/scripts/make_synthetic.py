"""Write a synthetic NetFlow v3 CSV to dataset/raw/synth_nf/ for the smoke test."""
import argparse

from _cli import ROOT

from netacwm.synth import make_synth


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--n-benign", type=int, default=150_000)
    p.add_argument("--seed", type=int, default=0)
    a = p.parse_args()
    out = ROOT / "dataset" / "raw" / "synth_nf" / "synth_nf.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    df = make_synth(a.n_benign, a.seed)
    df.to_csv(out, index=False)
    cache = ROOT / "outputs" / "cache" / "synth_nf"
    for f in cache.glob("flows.*"):
        f.unlink()
    print(f"wrote {out} ({len(df):,} flows; attacks: {df['Attack'].value_counts().to_dict()})")


if __name__ == "__main__":
    main()
