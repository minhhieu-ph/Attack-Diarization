"""NetFlow v3 field roles for NetACWM.

nProbe convention in the UQ NetFlow v3 datasets: IN_* = source -> destination
(the flow initiator, i.e. the client), OUT_* = destination -> source (the reply).

    action (A)        what the initiator chose: service, how much and how fast it sent, its flags
    consequence (C1)  what the system answered in the same flow
    context           computed separately from flow history (features.causal_context)
    dropped           identifiers, absolute time, OS fingerprints (TTL, TCP window) and fields
                      that mix both directions (they would leak the consequence into the action)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

# --- action: numeric fields (log1p) ------------------------------------------------
ACTION_NUM = [
    "IN_BYTES", "IN_PKTS", "DURATION_IN", "SRC_TO_DST_SECOND_BYTES", "SRC_TO_DST_AVG_THROUGHPUT",
    "RETRANSMITTED_IN_BYTES", "RETRANSMITTED_IN_PKTS",
    "SRC_TO_DST_IAT_MIN", "SRC_TO_DST_IAT_MAX", "SRC_TO_DST_IAT_AVG", "SRC_TO_DST_IAT_STDDEV",
]
ACTION_FLAGS = ["CLIENT_TCP_FLAGS"]
# categorical action fields: port and protocol always, the rest only in the default profile
ACTION_CAT_ALWAYS = ["L4_DST_PORT", "PROTOCOL"]
ACTION_CAT_EXTRA = ["L7_PROTO", "DNS_QUERY_TYPE", "ICMP_TYPE"]

# --- consequence C1: numeric targets (log1p) ----------------------------------------
CONSEQ_NUM = [
    "OUT_BYTES", "OUT_PKTS", "DURATION_OUT", "DST_TO_SRC_SECOND_BYTES", "DST_TO_SRC_AVG_THROUGHPUT",
    "RETRANSMITTED_OUT_BYTES", "RETRANSMITTED_OUT_PKTS",
    "DST_TO_SRC_IAT_MIN", "DST_TO_SRC_IAT_MAX", "DST_TO_SRC_IAT_AVG", "DST_TO_SRC_IAT_STDDEV",
]
CONSEQ_FLAGS = ["SERVER_TCP_FLAGS"]
CONSEQ_EXTRA_NUM = ["DNS_TTL_ANSWER"]          # default profile only
CONSEQ_FTP = "FTP_COMMAND_RET_CODE"            # default profile only -> (has_code, is_error) targets

# --- never used as features --------------------------------------------------------
DROPPED = [
    "IPV4_SRC_ADDR", "IPV4_DST_ADDR", "L4_SRC_PORT", "FLOW_START_MILLISECONDS", "FLOW_END_MILLISECONDS",
    "MIN_TTL", "MAX_TTL", "TCP_WIN_MAX_IN", "TCP_WIN_MAX_OUT", "DNS_QUERY_ID", "ICMP_IPV4_TYPE",
    "TCP_FLAGS", "FLOW_DURATION_MILLISECONDS", "LONGEST_FLOW_PKT", "SHORTEST_FLOW_PKT",
    "MIN_IP_PKT_LEN", "MAX_IP_PKT_LEN", "NUM_PKTS_UP_TO_128_BYTES", "NUM_PKTS_128_TO_256_BYTES",
    "NUM_PKTS_256_TO_512_BYTES", "NUM_PKTS_512_TO_1024_BYTES", "NUM_PKTS_1024_TO_1514_BYTES",
]

# columns the loader needs (besides identifiers / time / labels)
NEEDED = sorted(set(ACTION_NUM + ACTION_FLAGS + ACTION_CAT_ALWAYS + ACTION_CAT_EXTRA + CONSEQ_NUM
                    + CONSEQ_FLAGS + CONSEQ_EXTRA_NUM + [CONSEQ_FTP]))

TCP_FLAG_BITS = ["FIN", "SYN", "RST", "PSH", "ACK", "URG", "ECE", "CWR"]


@dataclass
class Profile:
    name: str
    action_num: list[str]
    action_flags: list[str]
    action_cat: list[str]
    conseq_num: list[str]
    conseq_flags: list[str]
    use_ftp: bool
    notes: list[str] = field(default_factory=list)


def get_profile(name: str) -> Profile:
    if name == "default":
        return Profile(name, ACTION_NUM, ACTION_FLAGS, ACTION_CAT_ALWAYS + ACTION_CAT_EXTRA,
                       CONSEQ_NUM + CONSEQ_EXTRA_NUM, CONSEQ_FLAGS, True)
    if name == "strict":
        # shortcut check: only sizes, rates, timing, flags, port and protocol
        return Profile(name, ACTION_NUM, ACTION_FLAGS, list(ACTION_CAT_ALWAYS), list(CONSEQ_NUM),
                       CONSEQ_FLAGS, False, ["no L7/DNS/FTP/ICMP fields"])
    raise ValueError(f"unknown feature profile {name!r} (default | strict)")


def family_of(attack: str, families: dict) -> str:
    """Map an Attack label to 'benign' | 'consequence' | 'action' | 'mixed'."""
    a = str(attack).strip().lower()
    if a in {"benign", "normal", ""}:
        return "benign"
    for grp in ("consequence", "action"):
        for pat in families.get(grp, []):
            if re.search(re.escape(str(pat).lower()), a):
                return grp
    return "mixed"
