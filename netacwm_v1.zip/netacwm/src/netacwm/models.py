"""Models used by E0.

MultiRegressor  predicts all consequence targets at once (XGBoost on GPU, sklearn fallback)
Autoencoder     unconditional baseline over context + action + consequence (torch, PCA fallback)
IForest         isolation forest (action novelty s_A, and an unconditional baseline)
"""
from __future__ import annotations

import numpy as np

from .utils import LOG, has_module


class Standardizer:
    def fit(self, X: np.ndarray) -> "Standardizer":
        self.mu = X.mean(0)
        self.sd = np.maximum(X.std(0), 1e-3)
        return self

    def __call__(self, X: np.ndarray) -> np.ndarray:
        return ((X - self.mu) / self.sd).astype(np.float32)


class MultiRegressor:
    def __init__(self, rcfg: dict, device: str, seed: int, n_jobs: int):
        self.cfg, self.device, self.seed, self.n_jobs = rcfg, device, seed, n_jobs
        want = rcfg.get("backend", "auto")
        self.backend = "xgboost" if (want in ("auto", "xgboost") and has_module("xgboost")) else "sklearn"
        if want == "xgboost" and self.backend != "xgboost":
            LOG.warning("xgboost not installed -> sklearn HistGradientBoosting (slower, capped rows)")

    def fit(self, X: np.ndarray, Y: np.ndarray) -> "MultiRegressor":
        self.mean_ = Y.mean(0)
        self.const_ = Y.std(0) < 1e-8
        n_val = max(1, int(0.1 * len(X)))           # rows are time-ordered: last 10% validates
        Xtr, Ytr, Xva, Yva = X[:-n_val], Y[:-n_val], X[-n_val:], Y[-n_val:]
        if self.backend == "xgboost":
            self._fit_xgb(Xtr, Ytr, Xva, Yva)
        else:
            self._fit_sklearn(X, Y)
        return self

    def _fit_xgb(self, Xtr, Ytr, Xva, Yva):
        import xgboost as xgb

        c = self.cfg
        params = dict(n_estimators=c["n_estimators"], max_depth=c["max_depth"], learning_rate=c["learning_rate"],
                      subsample=c["subsample"], colsample_bytree=c["colsample_bytree"], tree_method="hist",
                      n_jobs=self.n_jobs, random_state=self.seed,
                      early_stopping_rounds=c.get("early_stopping_rounds", 30), eval_metric="rmse")
        for dev in ([self.device, "cpu"] if self.device != "cpu" else ["cpu"]):
            try:
                self.model = xgb.XGBRegressor(device=dev, **params)
                self.model.fit(Xtr, Ytr, eval_set=[(Xva, Yva)], verbose=False)
                self.used_device = dev
                return
            except Exception as e:  # noqa: BLE001
                if dev == "cpu":
                    raise
                LOG.warning("xgboost on %s failed (%s) -> CPU", dev, e)

    def _fit_sklearn(self, X, Y):
        from sklearn.ensemble import HistGradientBoostingRegressor

        c = self.cfg
        cap = c.get("max_rows_cpu")
        if cap and len(X) > cap:
            idx = np.sort(np.random.default_rng(self.seed).choice(len(X), cap, replace=False))
            X, Y = X[idx], Y[idx]
        self.models = []
        for j in range(Y.shape[1]):
            if self.const_[j]:
                self.models.append(None)
                continue
            m = HistGradientBoostingRegressor(max_iter=c["n_estimators"], learning_rate=c["learning_rate"],
                                              max_leaf_nodes=min(2 ** c["max_depth"] - 1, 255),
                                              early_stopping=True, validation_fraction=0.1,
                                              n_iter_no_change=c.get("early_stopping_rounds", 30),
                                              random_state=self.seed)
            self.models.append(m.fit(X, Y[:, j]))
        self.used_device = "cpu"

    def predict(self, X: np.ndarray, batch: int = 1_000_000) -> np.ndarray:
        out = np.empty((len(X), len(self.mean_)), dtype=np.float32)
        for s in range(0, len(X), batch):
            xb = X[s:s + batch]
            if self.backend == "xgboost":
                p = self.model.predict(xb)
                out[s:s + batch] = p.reshape(len(xb), -1)
            else:
                for j, m in enumerate(self.models):
                    out[s:s + batch, j] = self.mean_[j] if m is None else m.predict(xb)
        out[:, self.const_] = self.mean_[self.const_]
        return out


class Autoencoder:
    """Reconstruction error of standardized features. torch MLP when available, else PCA."""

    def __init__(self, acfg: dict, device: str, seed: int):
        self.cfg, self.device, self.seed = acfg, device, seed
        want = acfg.get("backend", "auto")
        self.backend = "torch" if (want in ("auto", "torch") and has_module("torch")) else "pca"
        if want == "torch" and self.backend != "torch":
            LOG.warning("torch not installed -> PCA reconstruction baseline")

    def fit(self, X: np.ndarray) -> "Autoencoder":
        self.std = Standardizer().fit(X)
        Z = self.std(X)
        if self.backend == "torch":
            self._fit_torch(Z)
        else:
            from sklearn.decomposition import PCA

            k = max(1, min(16, Z.shape[1] - 1))
            sub = Z if len(Z) <= 500_000 else Z[np.random.default_rng(self.seed).choice(len(Z), 500_000, replace=False)]
            self.pca = PCA(n_components=k, random_state=self.seed).fit(sub)
        return self

    def _fit_torch(self, Z):
        import torch
        from torch import nn

        torch.manual_seed(self.seed)
        dev = self.device if (self.device == "cuda" and torch.cuda.is_available()) else "cpu"
        d, hid = Z.shape[1], list(self.cfg.get("hidden", [256, 64, 16]))
        enc, dec, prev = [], [], d
        for h in hid:
            enc += [nn.Linear(prev, h), nn.ReLU()]
            prev = h
        for h in list(reversed(hid[:-1])) + [d]:
            dec += [nn.Linear(prev, h)] + ([nn.ReLU()] if h != d else [])
            prev = h
        self.net = nn.Sequential(*enc, *dec).to(dev)
        self.dev = dev
        opt = torch.optim.Adam(self.net.parameters(), lr=self.cfg.get("lr", 1e-3))
        X = torch.from_numpy(Z)
        bs = int(self.cfg.get("batch_size", 8192))
        g = torch.Generator().manual_seed(self.seed)
        for ep in range(int(self.cfg.get("epochs", 20))):
            perm = torch.randperm(len(X), generator=g)
            tot = 0.0
            self.net.train()
            for s in range(0, len(X), bs):
                xb = X[perm[s:s + bs]].to(dev, non_blocking=True)
                loss = ((self.net(xb) - xb) ** 2).mean()
                opt.zero_grad(set_to_none=True)
                loss.backward()
                opt.step()
                tot += float(loss) * len(xb)
            if ep == 0 or ep == int(self.cfg.get("epochs", 20)) - 1:
                LOG.info("  AE epoch %d loss %.4f", ep + 1, tot / len(X))

    def score(self, X: np.ndarray, batch: int = 262_144) -> np.ndarray:
        Z = self.std(X)
        if self.backend == "pca":
            rec = self.pca.inverse_transform(self.pca.transform(Z))
            return ((rec - Z) ** 2).mean(1)
        import torch

        out = np.empty(len(Z), dtype=np.float32)
        self.net.eval()
        with torch.no_grad():
            for s in range(0, len(Z), batch):
                xb = torch.from_numpy(Z[s:s + batch]).to(self.dev)
                out[s:s + batch] = ((self.net(xb) - xb) ** 2).mean(1).float().cpu().numpy()
        return out


class IForest:
    def __init__(self, icfg: dict, seed: int, n_jobs: int):
        self.cfg, self.seed, self.n_jobs = icfg, seed, n_jobs

    def fit(self, X: np.ndarray) -> "IForest":
        from sklearn.ensemble import IsolationForest

        self.std = Standardizer().fit(X)
        self.m = IsolationForest(n_estimators=self.cfg.get("n_estimators", 200),
                                 max_samples=min(int(self.cfg.get("max_samples", 65536)), len(X)),
                                 n_jobs=self.n_jobs, random_state=self.seed).fit(self.std(X))
        return self

    def score(self, X: np.ndarray, chunk: int = 200_000) -> np.ndarray:
        """Chunks scored in parallel threads (tree traversal releases the GIL)."""
        from joblib import Parallel, delayed

        def one(s):
            return -self.m.score_samples(self.std(X[s:s + chunk]))

        parts = Parallel(n_jobs=self.n_jobs, prefer="threads")(delayed(one)(s) for s in range(0, len(X), chunk))
        return np.concatenate(parts).astype(np.float32) if parts else np.zeros(0, np.float32)
