# NetACWM — cổng khả thi E0

Code cho bước đầu tiên của đề cương *World Model hệ quả cho phát hiện xâm nhập mạng (IDS-1)*:
cổng E0 kiểm tra nhanh H1 và H2 trên NetFlow v3 trước khi xây mô hình đầy đủ.

- **H1:** khi đã biết hành động (client gửi gì), hệ quả (server đáp gì, host đích làm gì sau đó) có dễ đoán hơn rõ so với chỉ biết ngữ cảnh không? Đo bằng R² trên flow benign giữ lại.
- **H2:** điểm bất ngờ có điều kiện `s_C` có bắt nhóm tấn công lạ ở hệ quả (backdoor, bot, infiltration, ransomware, theft) tốt hơn baseline không điều kiện (autoencoder, isolation forest) ở FPR 0,1% không? Đo bằng TPR kèm khoảng tin cậy bootstrap ghép cặp.

## Cấu trúc

```
netacwm/
├── dataset/                 # raw/<tên>/ hoặc processed/<tên>/ (xem dataset/README.md)
├── configs/                 # default.yaml + a100.yaml, b300.yaml, smoke.yaml
├── src/netacwm/
│   ├── schema.py            # trường NetFlow v3 nào là hành động / hệ quả / bị loại
│   ├── data.py              # đọc processed parquet của attack-diarization hoặc CSV gốc
│   ├── features.py          # ngữ cảnh nhân quả, hệ quả trễ C2, ma trận đặc trưng
│   ├── split.py             # chia theo thời gian, chỉ học trên benign
│   ├── models.py            # XGBoost đa đầu ra (GPU), autoencoder (torch), isolation forest
│   ├── scoring.py           # khoảng cách Mahalanobis + conformal theo nhóm dịch vụ (C3)
│   ├── e0.py                # một lần chạy: dataset × profile × seed
│   └── report.py            # gộp kết quả, ra kết luận GO / STOP
├── scripts/                 # run_e0.py, run_parallel.py, report.py, check_env.py, make_synthetic.py
├── tests/
└── outputs/                 # cache/, e0/, logs/
```

## 1. Cài môi trường

Dùng lại env của dự án trước (đã có torch, xgboost, pyarrow):

```bash
conda activate attackdiar
cd netacwm
USE_CURRENT_ENV=1 bash setup_env.sh     # cài bổ sung + pip install -e .
```

Hoặc tạo env mới tên `netacwm`: `bash setup_env.sh`.

## 2. Chỉ chỗ dữ liệu

Mặc định code tìm theo thứ tự:
1. `netacwm/dataset/`
2. `../attack-diarization/dataset/`, tức đặt hai thư mục `netacwm/` và `attack-diarization/` cạnh nhau.

Trong mỗi thư mục, code ưu tiên `processed/<tên>/flows.parquet` (bản đã chuẩn bị từ đợt trước), sau đó mới đến CSV gốc trong `raw/<tên>/`.

Nếu dữ liệu nằm chỗ khác, chọn một trong hai cách:

```bash
# cách 1: truyền đường dẫn khi chạy
python scripts/run_parallel.py --config configs/a100.yaml \
    --set "paths.data_roots=[/duong/dan/attack-diarization/dataset]"
# cách 2: tạo symlink
ln -s /duong/dan/attack-diarization/dataset/processed dataset/processed
```

Kiểm tra trước khi chạy: `make check CONFIG=configs/a100.yaml`. Lệnh này in package, GPU và vị trí tìm thấy từng bộ dữ liệu.

## 3. Chạy

```bash
make test                               # unit test (CPU, ~15 giây)
make smoke                              # dữ liệu tổng hợp → E0 → báo cáo (CPU, ~3 phút)

# 8×A100: mỗi job = 1 dataset × 1 profile (3 seed), mỗi job 1 GPU
make e0 CONFIG=configs/a100.yaml

# 1×B300: 3 job chạy chung một GPU
python scripts/run_parallel.py --config configs/b300.yaml --jobs-per-gpu 3

# xem nhanh 1 dataset, 1 seed
make e0-one CONFIG=configs/a100.yaml
```

Mặc định chạy 3 bộ (UNSW-NB15, ToN-IoT, CSE-CIC-IDS2018) × 2 profile × 3 seed:
- `default`: đầy đủ đặc trưng.
- `strict`: bỏ L7/DNS/FTP/ICMP, dùng để kiểm tra shortcut.

Job đã xong sẽ được bỏ qua khi chạy lại; thêm `--force` để chạy lại. Log nằm ở `outputs/logs/e0_*.log`.

## 4. Đọc kết quả

`outputs/e0/summary.md` ghi kết luận GO / STOP, kèm lý do theo từng bộ dữ liệu, rồi các bảng:
- TPR tại FPR 0,1% theo nhóm tấn công;
- TPR theo từng lớp tấn công;
- R² có và không có hành động;
- kiểm tra C3 (FPR thực tế theo từng nhóm dịch vụ).

Gửi lại file này, cùng `summary.csv` nếu cần.

| Bộ chấm | Ý nghĩa |
|---|---|
| `s_C` | độ bất ngờ của hệ quả khi đã biết ngữ cảnh + hành động, hiệu chỉnh conformal theo nhóm dịch vụ (C1 + C3) |
| `s_C_raw` | cùng khoảng cách nhưng không hiệu chỉnh conformal |
| `s_A` | độ lạ của hành động: autoencoder trên ngữ cảnh + hành động, hiệu chỉnh conformal |
| `s_max` | max(`s_C`, `s_A`): điểm phân hạng của cả hệ thống |
| `AE`, `AE_conf` | autoencoder không điều kiện trên mọi đặc trưng (thô / conformal) |
| `IF`, `IF_conf` | isolation forest không điều kiện trên mọi đặc trưng |

**Tiêu chí qua cổng** (mục `gate` trong configs/default.yaml), áp cho mỗi bộ dữ liệu:
- H1: R² tăng ít nhất 0,10.
- H2: `s_C` hơn baseline mạnh nhất ít nhất 5 điểm TPR@0,1% trên nhóm hệ quả, và cận dưới CI > 0 ở đa số seed.
- Shortcut: profile `strict` giữ được ít nhất một nửa mức chênh đó.

Kết luận GO khi ít nhất 2 bộ dữ liệu đạt cả ba tiêu chí.

## Ghi chú

- Ngữ cảnh và C2 được tính trên toàn bộ luồng theo thời gian, như một cảm biến thật nhìn thấy. Mô hình chỉ học trên flow benign giai đoạn đầu.
- IP, cổng nguồn, TTL, TCP window và các trường trộn hai chiều không bao giờ được dùng làm đặc trưng (`schema.py`).
- Thiếu xgboost thì code chuyển sang sklearn: chậm hơn và giới hạn 500k dòng huấn luyện. Thiếu torch thì autoencoder được thay bằng PCA. `make check` sẽ báo các trường hợp này.
- Đổi nguồn dữ liệu thì chạy `make clean-cache`.
