# NetACWM v4 — world model hệ quả: dịch chuyển môi trường và kill test hướng A

Code cho đề cương *World Model hệ quả cho phát hiện xâm nhập mạng (IDS-1)*.
- **v1 (E0):** cổng khả thi trong cùng một mạng. Kết quả: STOP 0/3, xem `outputs/e0/summary.md` của đợt trước.
- **v2 (mục 5 bên dưới):** câu hỏi mới. Quy luật "hành động → hệ quả" học trên một mạng (hoặc những ngày trước) có còn đúng ở mạng khác (hoặc ngày sau) không, nếu chỉ hiệu chỉnh ngưỡng bằng 1 giờ benign tại chỗ?
- **v4 (mục 6):** kill test cho hướng A — `s_C` có bắt được thứ baseline bỏ sót và có bền khi kẻ tấn công ngụy trang hành động không.

Phần dưới đây, đến hết mục 4, là hướng dẫn E0 của v1 và vẫn chạy được.

- **H1:** khi đã biết hành động (client gửi gì), hệ quả (server đáp gì, host đích làm gì sau đó) có dễ đoán hơn rõ so với chỉ biết ngữ cảnh không? Đo bằng R² trên flow benign giữ lại.
- **H2:** điểm bất ngờ có điều kiện `s_C` có bắt nhóm tấn công lạ ở hệ quả (backdoor, bot, infiltration, ransomware, theft) tốt hơn baseline không điều kiện (autoencoder, isolation forest) ở FPR 0,1% không? Đo bằng TPR kèm khoảng tin cậy bootstrap ghép cặp.

## Cấu trúc

```
netacwm/
├── dataset/                 # raw/<tên>/ hoặc processed/<tên>/ (xem dataset/README.md)
├── configs/                 # default.yaml + a100.yaml, b300.yaml, smoke.yaml
├── src/netacwm/
│   ├── schema.py            # trường NetFlow v3 nào là hành động / hệ quả / bị loại
│   ├── data.py              # đọc processed parquet của attack-diarization hoặc CSV gốc
│   ├── features.py          # ngữ cảnh nhân quả, hệ quả trễ C2, ma trận đặc trưng
│   ├── split.py             # chia theo thời gian, chỉ học trên benign
│   ├── models.py            # XGBoost đa đầu ra (GPU), autoencoder (torch), isolation forest
│   ├── scoring.py           # khoảng cách Mahalanobis + conformal theo nhóm dịch vụ (C3)
│   ├── e0.py                # một lần chạy: dataset × profile × seed
│   ├── report.py            # gộp kết quả, ra kết luận GO / STOP
│   ├── envs.py, shift.py, shift_report.py          # v2: dịch chuyển thời gian / giữa các mạng
│   └── killtest.py, killtest_report.py             # v4: kill test hướng A
├── scripts/                 # run_e0.py, run_parallel.py, report.py, check_env.py, make_synthetic.py
├── tests/
└── outputs/                 # cache/, e0/, logs/
```

## 1. Cài môi trường

Dùng lại env của dự án trước (đã có torch, xgboost, pyarrow):

```bash
conda activate attackdiar
cd netacwm
USE_CURRENT_ENV=1 bash setup_env.sh     # cài bổ sung + pip install -e .
```

Hoặc tạo env mới tên `netacwm`: `bash setup_env.sh`.

## 2. Chỉ chỗ dữ liệu

Mặc định code tìm theo thứ tự:
1. `netacwm/dataset/`
2. `../attack-diarization/dataset/`, tức đặt hai thư mục `netacwm/` và `attack-diarization/` cạnh nhau.

Trong mỗi thư mục, code ưu tiên `processed/<tên>/flows.parquet` (bản đã chuẩn bị từ đợt trước), sau đó mới đến CSV gốc trong `raw/<tên>/`.

Nếu dữ liệu nằm chỗ khác, chọn một trong hai cách:

```bash
# cách 1: truyền đường dẫn khi chạy
python scripts/run_parallel.py --config configs/a100.yaml \
    --set "paths.data_roots=[/duong/dan/attack-diarization/dataset]"
# cách 2: tạo symlink
ln -s /duong/dan/attack-diarization/dataset/processed dataset/processed
```

Kiểm tra trước khi chạy: `make check CONFIG=configs/a100.yaml`. Lệnh này in package, GPU và vị trí tìm thấy từng bộ dữ liệu.

## 3. Chạy

```bash
make test                               # unit test (CPU, ~15 giây)
make smoke                              # dữ liệu tổng hợp → E0 → báo cáo (CPU, ~3 phút)

# 8×A100: mỗi job = 1 dataset × 1 profile (3 seed), mỗi job 1 GPU
make e0 CONFIG=configs/a100.yaml

# 1×B300: 3 job chạy chung một GPU
python scripts/run_parallel.py --config configs/b300.yaml --jobs-per-gpu 3

# xem nhanh 1 dataset, 1 seed
make e0-one CONFIG=configs/a100.yaml
```

Mặc định chạy 3 bộ (UNSW-NB15, ToN-IoT, CSE-CIC-IDS2018) × 2 profile × 3 seed:
- `default`: đầy đủ đặc trưng.
- `strict`: bỏ L7/DNS/FTP/ICMP, dùng để kiểm tra shortcut.

Job đã xong sẽ được bỏ qua khi chạy lại; thêm `--force` để chạy lại. Log nằm ở `outputs/logs/e0_*.log`.

## 4. Đọc kết quả

`outputs/e0/summary.md` ghi kết luận GO / STOP, kèm lý do theo từng bộ dữ liệu, rồi các bảng:
- TPR tại FPR 0,1% theo nhóm tấn công;
- TPR theo từng lớp tấn công;
- R² có và không có hành động;
- kiểm tra C3 (FPR thực tế theo từng nhóm dịch vụ).

Gửi lại file này, cùng `summary.csv` nếu cần.

| Bộ chấm | Ý nghĩa |
|---|---|
| `s_C` | độ bất ngờ của hệ quả khi đã biết ngữ cảnh + hành động, hiệu chỉnh conformal theo nhóm dịch vụ (C1 + C3) |
| `s_C_raw` | cùng khoảng cách nhưng không hiệu chỉnh conformal |
| `s_A` | độ lạ của hành động: autoencoder trên ngữ cảnh + hành động, hiệu chỉnh conformal |
| `s_max` | max(`s_C`, `s_A`): điểm phân hạng của cả hệ thống |
| `AE`, `AE_conf` | autoencoder không điều kiện trên mọi đặc trưng (thô / conformal) |
| `IF`, `IF_conf` | isolation forest không điều kiện trên mọi đặc trưng |

**Tiêu chí qua cổng** (mục `gate` trong configs/default.yaml), áp cho mỗi bộ dữ liệu:
- H1: R² tăng ít nhất 0,10.
- H2: `s_C` hơn baseline mạnh nhất ít nhất 5 điểm TPR@0,1% trên nhóm hệ quả, và cận dưới CI > 0 ở đa số seed.
- Shortcut: profile `strict` giữ được ít nhất một nửa mức chênh đó.

Kết luận GO khi ít nhất 2 bộ dữ liệu đạt cả ba tiêu chí.

## 5. v2: dịch chuyển môi trường

### Ý tưởng và các nhánh so sánh

Mạng đích được cắt tại thời điểm `t_cal`:

```
lịch sử của mạng đích | W_on: K giây trước t_cal | W_cal: 1 giờ benign sau t_cal | test (benign sau đó + tấn công)
```

Mọi nhánh được hiệu chỉnh (C3) trên **cùng** W_cal và test trên **cùng** tập flow.

| Nhánh | Học trên | Vai trò |
|---|---|---|
| `src:<A>` | benign của mạng A | chuyển giao zero-shot |
| `src:<A>+<B>` | benign của mọi mạng khác | học sẵn trên nhiều mạng |
| `loc` | lịch sử benign của chính mạng đích | mốc tham chiếu (huấn luyện tại chỗ đầy đủ) |
| `scr3600` | 1 giờ benign của mạng đích, trong W_on | baseline "cứ học tại chỗ 1 giờ là đủ" |
| `ftK`, `scrK` (bước 3) | mô hình `src` nhiều mạng fine-tune trên K giây / học từ đầu trên K giây | đường cong làm quen |

Bộ chấm mới so với E0:
- `s_C_mech`: chỉ dùng các trường hệ quả cơ chế giao thức (cờ TCP phía server, số gói trả lời).
- `s_C_content`: chỉ dùng các trường nội dung (số byte, thông lượng).

Thay đổi so với v1 để mọi mạng có chung không gian đặc trưng:
- **Danh sách cổng cố định** (`schema.WELL_KNOWN_PORTS`); cổng ngoài danh sách vào 3 nhóm theo dải. Đặt `features.port_vocab=data` để quay về top-K như v1.
- **Chuẩn hóa ngữ cảnh theo từng mạng** (`features.ctx_norm`, mặc định `quantile`). Số đếm flow phụ thuộc quy mô mạng, nên mỗi mạng được chuẩn hóa bằng benign của chính nó: tập huấn luyện với mạng nguồn, W_cal với mạng đích.
- **Profile `strict` mặc định:** bỏ L7, DNS, FTP, ICMP vì các trường này phụ thuộc cách từng testbed được dựng.
- **Sàn thang đo phần dư 0,05** (`shift.scale_floor`): một trường tình cờ không đổi trong 1 giờ hiệu chỉnh không được biến mọi lệch nhỏ về sau thành báo động.

### Chạy theo thứ tự (8×A100)

```bash
make test                                          # ~2 phút, gồm smoke test v2 trên dữ liệu tổng hợp

# Bước 0 (vài phút, CPU): xem cách chia ngày của từng bộ dữ liệu
make inspect CONFIG=configs/a100.yaml               # -> outputs/inspect/<dataset>.md

# Bước 1 (G1): CIC, học các ngày trước -> test ngày sau; 3 job (3 seed)
make shift-time CONFIG=configs/a100.yaml

# Bước 2: chuyển giữa 3 mạng; 9 job (3 mạng đích x 3 seed)
make shift-cross CONFIG=configs/a100.yaml

# Bước 3 (chỉ chạy khi bước 2 có triển vọng): thêm nhánh fine-tune 15 phút / 1 giờ / 4 giờ
make shift-onboard CONFIG=configs/a100.yaml          # chạy lại các job bước 2 kèm nhánh mới
```

Bước 1 và 2 độc lập, có thể chạy cùng lúc: `python scripts/run_shift_parallel.py --config configs/a100.yaml --exp time cross`.

Theo dõi tiến độ:
- `tail -f outputs/logs/shift_*.log`
- `watch -n 30 nvidia-smi`
- `ls outputs/shift/*/*/`

Job đã xong được bỏ qua khi chạy lại. Tổng hợp lại kết quả: `make shift-report`.

### Gửi lại để đánh giá

1. Sau bước 0: `outputs/inspect/*.md`. Nếu ngày bị chia sai (ví dụ một ngày capture bị cắt đôi), chỉnh `shift.time.tz_offset_hours` hoặc dùng `--set shift.time.segment=gap`.
2. Sau bước 1–2: `outputs/shift/summary.md`, kèm nén thư mục `outputs/shift/` (các file JSON).

### Tiêu chí đặt trước (`gate_shift` trong configs/default.yaml)

| Cổng | Đạt khi |
|---|---|
| **G1** (bước 1) | Hiệu chỉnh fresh giữ FPR theo nhóm dịch vụ của `s_C` ≤ 2α (α = 0,1%) ở ≥ 80% số ngày, **và** có ít nhất một lớp tấn công mà `s_C` hơn mọi baseline ≥ 5 điểm TPR@0,1% |
| **H1-T** | R² trung vị (có hành động) khi chuyển giao ≥ 70% mức tại chỗ (`loc`), **và** hơn mô hình chỉ ngữ cảnh ≥ 0,10; đạt ở ≥ 50% số cặp nguồn → đích |
| **H2-T** | `s_max` của nhánh `src` hơn đối thủ mạnh nhất ≥ 5 điểm TPR@0,1% trên mọi tấn công của mạng đích; đạt ở ≥ 50% số cặp. Đối thủ là cái tốt nhất trong: AE/IF học trên cùng mạng nguồn, và AE/IF học 1 giờ tại chỗ |
| **C3-T** | FPR theo nhóm dịch vụ của `s_C` trong 24 giờ sau W_cal ≤ 2α; đạt ở ≥ 80% số cặp |

H2-T dùng `s_max` (cả detector) trên mọi tấn công, không dùng `s_C` trên "nhóm hệ quả" như E0. Lý do: E0 cho thấy cách chia nhóm tấn công tiên nghiệm không đúng với dữ liệu flow (Bot lạ ở hành động, không phải ở hệ quả). `s_C` vẫn được báo cáo kèm.

Báo cáo có thêm **bản đồ chuyển giao**: R² theo từng loại hệ quả (mechanics, content, timing, netcond, delayed), chuyển giao so với tại chỗ. Dự đoán là mechanics chuyển giao tốt, content và timing thì kém.

### Thử trên dữ liệu tổng hợp (CPU)

```bash
make smoke-shift      # synth_a, synth_b (cùng quy luật), synth_c (quy luật khác) -> outputs/shift/summary.md
```

Trên dữ liệu tổng hợp, `synth_b → synth_a` giữ ~100% R², còn `synth_c → synth_a` chỉ giữ ~66%. Phần mất nằm ở content và timing, còn mechanics vẫn 1,0. Đây là kiểm tra rằng thước đo phân biệt được hai trường hợp.

## 6. v4: kill test cho hướng A (consequence-verified NIDS)

### Câu hỏi

Kẻ tấn công điều khiển được **hành động** (client gửi gì, gửi nhanh hay chậm), nhưng không điều khiển trực tiếp được **hệ quả** (server trả lời ra sao). Nếu world model thật sự có giá trị, thì:
- **K1:** `s_C` bắt được những lớp tấn công mà mọi detector không điều kiện đều bỏ sót.
- **K2:** khi kẻ tấn công ngụy trang hành động, `s_C` vẫn hơn baseline mạnh nhất.
- **K3:** kết quả K1 không đến từ cổng đích.

Bối cảnh giống bước 1 của v2: CIC-IDS2018, mỗi lần một ngày đích, học trên benign các ngày trước, hiệu chỉnh trên giờ đầu của ngày đó.

### Các bộ chấm

| Bộ chấm | Nhìn vào |
|---|---|
| `s_C` | world model: hệ quả có khớp với dự đoán từ ngữ cảnh + hành động không |
| `s_A` | autoencoder trên ngữ cảnh + hành động (AE **không có** trường hệ quả) |
| `s_max` | max(`s_C`, `s_A`) |
| `AE_conf` | autoencoder trên ngữ cảnh + hành động + hệ quả (AE **có** trường hệ quả) |
| `AE_C` | autoencoder trên ngữ cảnh + hệ quả, **không nhìn hành động** |
| `IF_conf` | isolation forest trên mọi trường |

`AE_C` là đối thủ quan trọng nhất của K2. Nó không nhìn hành động, nên việc ngụy trang hành động không ảnh hưởng gì đến nó. Nếu sau khi bị tấn công `s_C` không hơn được `AE_C`, thì "chỉ cần nhìn hệ quả là đủ", và việc điều kiện theo hành động (tức world model) không đem lại gì.

### Các kiểu tấn công

Cả ba kiểu chỉ áp lên flow tấn công, và **không bao giờ đổi trường hệ quả**.

| Kiểu | Kẻ tấn công làm gì |
|---|---|
| T1 | Độn byte (×1–8, gói tăng theo hoặc gói to tới MTU) và đổi nhịp thời gian (×0,5–2); tấn công vẫn hoạt động |
| T2 | Chép toàn bộ trường số của hành động và cờ TCP phía client từ một flow benign cùng dịch vụ (lấy trong giờ hiệu chỉnh); giữ nguyên tốc độ/ngữ cảnh |
| T3 | Như T2, chép thêm cả ngữ cảnh (tốc độ flow) |

Mỗi kiểu tấn công thích nghi theo **từng** bộ chấm. Với mỗi flow, kẻ tấn công thử 30 (T1) hoặc 65 (T2, T3) phương án, rồi giữ phương án cho điểm thấp nhất trên bộ chấm đang bị nhắm. Ngưỡng lấy từ benign sạch, nên điểm thấp hơn đồng nghĩa với TPR thấp hơn.

Giới hạn cần nói rõ: giả định "hệ quả không đổi khi hành động đổi" có lợi cho `s_C`. Ngoài đời, đổi hành động có thể làm server phản ứng khác đi. Phải có testbed (tuần 5–6 trong kế hoạch) mới đo được C thật.

### Tiêu chí đặt trước (`gate_killtest`)

| | Đạt khi |
|---|---|
| **K1** | Có ≥ 3 cặp (ngày, lớp; ≥ 50 flow) mà `s_C` hơn **mọi** baseline (`s_A`, `AE_conf`, `AE_C`, `IF_conf`) ≥ 5 điểm TPR@0,1% (trung bình 3 seed) |
| **K2** | Dưới T2, trung bình theo ngày: TPR sau tấn công của `s_C` − TPR sau tấn công của baseline mạnh nhất ≥ 5 điểm, **và** tỉ lệ giữ TPR của `s_C` ≥ của `AE_conf` |
| **K3** | K1 vẫn đạt với profile `noport` (strict, bỏ cổng đích khỏi đặc trưng; nhóm dịch vụ để hiệu chỉnh vẫn theo cổng) |

**GO** khi cả ba đạt. Khi đó mới làm tiếp: conformal trực tuyến, mô hình hệ quả xác suất, bộ dữ liệu thứ hai, testbed. Trượt K1 hoặc K2 thì dừng hướng A.

### Chạy

```bash
make test                                   # ~2 phút
make killtest CONFIG=configs/a100.yaml      # 6 job (strict, noport x 3 seed), mỗi job 9 ngày CIC
make killtest-bot CONFIG=configs/a100.yaml  # tùy chọn: ngày Bot với từ vựng cổng theo dữ liệu như E0
```

Theo dõi tiến độ bằng `tail -f outputs/logs/kill_*.log`: mỗi ngày in một dòng TPR sạch và sau T2. Kết quả nằm ở `outputs/killtest/summary.md`. Gửi lại file này, kèm thư mục `outputs/killtest/` đã nén.

## Ghi chú

- Ngữ cảnh và C2 được tính trên toàn bộ luồng theo thời gian, như một cảm biến thật nhìn thấy. Mô hình chỉ học trên flow benign giai đoạn đầu.
- IP, cổng nguồn, TTL, TCP window và các trường trộn hai chiều không bao giờ được dùng làm đặc trưng (`schema.py`).
- Thiếu xgboost thì code chuyển sang sklearn: chậm hơn và giới hạn 500k dòng huấn luyện. Thiếu torch thì autoencoder được thay bằng PCA. `make check` sẽ báo các trường hợp này.
- Đổi nguồn dữ liệu thì chạy `make clean-cache`.
