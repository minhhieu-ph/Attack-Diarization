"""v4 kill test: threat models change only what the attacker controls; end-to-end on synthetic data."""
import numpy as np

from netacwm.config import load_config
from netacwm.e0 import Stream
from netacwm.features import Matrices
from netacwm.killtest import (DETECTORS, DonorPool, _t1_block, action_layout, candidates, run_kill, t1_grid)
from netacwm.killtest_report import write_kill_summary
from netacwm.schema import get_profile
from netacwm.shift import time_targets
from netacwm.synth import make_synth
from netacwm.utils import save_json

PROF = get_profile("strict")
NAMES = [f"a_{c.lower()}" for c in PROF.action_num] + [f"a_cflag_{i}" for i in range(8)] + ["a_l4_dst_port=80", "a_x"]


def _att(n=3, seed=0):
    rng = np.random.default_rng(seed)
    act = np.abs(rng.normal(3, 1, size=(n, len(NAMES)))).astype(np.float32)
    act[:, -2:] = [1.0, 0.0]
    return Matrices(np.arange(n), rng.normal(size=(n, 4)).astype(np.float32), act,
                    rng.normal(size=(n, 5)).astype(np.float32), np.array([7, 7, 9])[:n], ["c"] * 4, NAMES, ["y"] * 5)


def test_t1_pads_and_paces_on_the_raw_scale():
    lay = action_layout(NAMES, PROF)
    a = _att().act
    grid = [(1.0, "pack", 1.0), (4.0, "scale", 2.0)]
    out = _t1_block(a, lay, grid, 1500.0).reshape(len(a), 2, -1)
    assert np.allclose(out[:, 0], a)                                   # first candidate = original
    j = lay["num"]["IN_BYTES"]
    assert np.allclose(np.expm1(out[:, 1, j]), 4 * np.expm1(a[:, j]), rtol=1e-4)
    k = lay["num"]["DURATION_IN"]
    assert np.allclose(np.expm1(out[:, 1, k]), 2 * np.expm1(a[:, k]), rtol=1e-4)
    assert np.allclose(out[:, 1, -2:], a[:, -2:])                        # port one-hot untouched
    assert t1_grid({"t1_size": [1, 2], "t1_time": [1]})[0] == (1.0, "pack", 1.0)


def test_t2_t3_replace_only_attacker_controlled_fields():
    lay = action_layout(NAMES, PROF)
    att = _att()
    donors = _att(n=3, seed=5)
    donors.group = np.array([7, 7, 7])
    pool = DonorPool(donors, n_port=8, min_donors=1)
    rng = np.random.default_rng(0)
    kc = {"donors_k": 4}
    for thr in ("T2", "T3"):
        m, K = candidates(thr, att, lay, pool, kc, rng)
        assert K == 5 and len(m.rows) == 15
        act = m.act.reshape(3, K, -1)
        ctx = m.ctx.reshape(3, K, -1)
        assert np.allclose(act[:, 0], att.act) and np.allclose(ctx[:, 0], att.ctx)   # original kept
        assert np.allclose(act[:, 1:, -2:], att.act[:, None, -2:])                    # service kept
        assert np.allclose(m.y.reshape(3, K, -1), att.y[:, None, :])                  # consequence never changes
        donor_rows = {tuple(r) for r in donors.act[:, lay["replace"]].round(5)}
        assert all(tuple(r) in donor_rows for r in act[:, 1:, lay["replace"]].reshape(-1, len(lay["replace"])).round(5))
        if thr == "T2":
            assert np.allclose(ctx[:, 1:], att.ctx[:, None, :])
        else:
            assert not np.allclose(ctx[:, 1:], att.ctx[:, None, :])


def test_kill_test_end_to_end(tmp_path):
    raw = tmp_path / "dataset" / "raw" / "sa"
    raw.mkdir(parents=True)
    make_synth(24_000, days=3, seed=21).to_csv(raw / "sa.csv", index=False)
    cfg = load_config(["configs/smoke_shift.yaml", "configs/smoke_kill.yaml"], [
        f"paths.data_roots=[{tmp_path / 'dataset'}]", f"paths.output_dir={tmp_path / 'out'}",
        "models.regressor.n_estimators=40", "models.iforest.n_estimators=30", "models.ae.epochs=2",
        "compute.n_jobs=2", "shift.calib_min_flows=1500", "killtest.datasets=[sa]", "killtest.attack_eval_per_class=150",
        "killtest.donors_k=6"])
    st = Stream(cfg, "sa")
    segs, targets = time_targets(cfg, st)
    for prof in ("strict", "noport"):
        r = run_kill(cfg, st, targets[0], segs, prof, 0, "cpu")
        assert set(DETECTORS) <= set(r["metrics"])
        for thr in ("T1", "T2", "T3"):
            for d in DETECTORS:
                x = r["attacks"][thr][d]
                assert x["tpr_after"] <= x["tpr_before"] + 1e-9            # the attacker never helps the detector
        for thr in ("T1", "T2"):                                          # AE_C ignores the action
            assert abs(r["attacks"][thr]["AE_C"]["tpr_after"] - r["attacks"][thr]["AE_C"]["tpr_before"]) < 1e-9
        save_json(r, tmp_path / "out" / "killtest" / "sa" / r["segment"]["label"] / f"{prof}_seed0.json")
    text = write_kill_summary(tmp_path / "out" / "killtest", cfg).read_text()
    assert "K1" in text and "K2" in text and "sa / `strict`" in text
