"""Rebuild outputs/killtest/summary.md from the result files (no computation)."""
from _cli import base_parser, setup

from netacwm.config import output_dir
from netacwm.killtest_report import write_kill_summary


def main():
    a = base_parser(__doc__).parse_args()
    cfg = setup(a)
    print(write_kill_summary(output_dir(cfg) / "killtest", cfg))


if __name__ == "__main__":
    main()
