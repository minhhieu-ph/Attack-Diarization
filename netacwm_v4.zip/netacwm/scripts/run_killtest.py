"""v4 kill test for direction A in ONE process (one GPU). Finished results are skipped.

  python scripts/run_killtest.py --config configs/a100.yaml --profiles strict --seeds 0
  python scripts/run_killtest.py --config configs/a100.yaml --days 2018-03-02 --tag -datavocab \\
      --set features.port_vocab=data          # optional: was the Bot result of E0 a port-vocabulary effect?

For all jobs on several GPUs use scripts/run_killtest_parallel.py.
"""
from _cli import base_parser, setup

from netacwm.config import output_dir
from netacwm.killtest import run_kill_dataset
from netacwm.killtest_report import write_kill_summary
from netacwm.utils import LOG, resolve_device


def main():
    p = base_parser(__doc__)
    p.add_argument("--datasets", nargs="*", default=None)
    p.add_argument("--days", nargs="*", default=None)
    p.add_argument("--profiles", nargs="*", default=None)
    p.add_argument("--seeds", nargs="*", type=int, default=None)
    p.add_argument("--tag", default="", help="suffix of the result files, e.g. -datavocab")
    p.add_argument("--force", action="store_true")
    p.add_argument("--no-report", action="store_true")
    a = p.parse_args()
    cfg = setup(a)
    device = resolve_device(cfg)
    kc = cfg["killtest"]
    root = output_dir(cfg) / "killtest"
    for ds in a.datasets or kc["datasets"]:
        run_kill_dataset(cfg, ds, a.profiles or kc["profiles"], a.seeds if a.seeds is not None else kc["seeds"],
                         device, root, a.force, a.days, a.tag)
    if not a.no_report:
        LOG.info("summary: %s", write_kill_summary(root, cfg))


if __name__ == "__main__":
    main()
