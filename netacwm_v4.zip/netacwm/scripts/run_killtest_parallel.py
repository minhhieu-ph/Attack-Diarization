"""v4 kill test on several GPUs: one job per (dataset, profile, seed), each job runs all target days.

  python scripts/run_killtest_parallel.py --config configs/a100.yaml

Logs: outputs/logs/kill_<n>.log. Summary: outputs/killtest/summary.md
"""
import sys

from _cli import base_parser
from run_parallel import gpu_ids, run_pool

from netacwm.config import load_config, output_dir
from netacwm.killtest_report import write_kill_summary
from netacwm.utils import available_cpus


def main():
    p = base_parser(__doc__)
    p.add_argument("--profiles", nargs="*", default=None)
    p.add_argument("--seeds", nargs="*", type=int, default=None)
    p.add_argument("--gpus", default=None)
    p.add_argument("--jobs-per-gpu", type=int, default=1)
    p.add_argument("--force", action="store_true")
    a = p.parse_args()
    cfg = load_config(a.config, a.overrides)
    kc = cfg["killtest"]
    seeds = a.seeds if a.seeds is not None else kc["seeds"]
    gpus = a.gpus.split(",") if a.gpus else (gpu_ids() or [None])
    slots = [g for g in gpus for _ in range(a.jobs_per_gpu)]
    threads = max(1, (available_cpus() - 2) // len(slots))
    common = sum((["--config", c] for c in a.config), []) + sum((["--set", o] for o in a.overrides), [])
    common += ["--set", f"compute.n_jobs={threads}", "--no-report"] + (["--force"] if a.force else [])
    cmds = [[sys.executable, "scripts/run_killtest.py", *common, "--datasets", d, "--profiles", pr, "--seeds", str(s)]
            for d in kc["datasets"] for pr in (a.profiles or kc["profiles"]) for s in seeds]
    log_dir = output_dir(cfg) / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    print(f"{len(cmds)} jobs on slots {slots} | {threads} CPU threads per job")
    failed = run_pool(cmds, slots, log_dir, prefix="kill")
    path = write_kill_summary(output_dir(cfg) / "killtest", cfg)
    print(f"summary: {path}" + (f" | {failed} job(s) failed, see {log_dir}" if failed else ""))


if __name__ == "__main__":
    main()
