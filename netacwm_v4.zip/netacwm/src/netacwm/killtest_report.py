"""Aggregate the v4 kill test (outputs/killtest/<dataset>/<day>/<profile><tag>_seed<k>.json) into
outputs/killtest/summary.md with the pre-registered verdicts K1, K2, K3 (gate_killtest)."""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path

import numpy as np

from .killtest import BASELINES, DETECTORS
from .utils import load_json


def _nan(x):
    return np.nan if x is None else float(x)


def _mean(xs):
    v = np.array([_nan(x) for x in xs], dtype=float)
    return float(np.nanmean(v)) if np.isfinite(v).any() else np.nan


def _pct(x):
    return "–" if x is None or not np.isfinite(x) else f"{100 * x:.1f}"


def collect(root: Path) -> list[dict]:
    return [load_json(p) for p in sorted(Path(root).glob("*/*/*_seed*.json"))]


def _label(r):
    return f"{r['profile']}{r.get('tag', '')}"


def unique_wins(rs_by_day: dict, g: dict, key_fpr: str) -> list[tuple]:
    """(day, class, n, {detector: mean TPR}, margin) where s_C beats every baseline by >= unique_gain."""
    out = []
    for day, rs in sorted(rs_by_day.items()):
        classes = set().union(*[r["per_class"].keys() for r in rs])
        for c in sorted(classes):
            n = int(np.nanmean([r["per_class"].get(c, {}).get("n", np.nan) for r in rs]))
            if n < g["min_class_flows"]:
                continue
            v = {d: _mean([r["per_class"].get(c, {}).get(d) for r in rs]) for d in DETECTORS}
            best = max(v[b] for b in BASELINES)
            if np.isfinite(v["s_C"]) and np.isfinite(best):
                out.append((day, c, n, v, v["s_C"] - best))
    return out


def label_section(ds: str, label: str, rs_by_day: dict, cfg: dict) -> tuple[list[str], dict]:
    g = cfg["gate_killtest"]
    gf = cfg["eval"]["gate_fpr"]
    key = f"tpr@{gf:g}"
    L = [f"### {ds} — profile `{label}`", "",
         f"#### Không tấn công: TPR (%) tại FPR {gf:g}, mọi tấn công của ngày", "",
         "| Ngày | Seed | Tấn công | " + " | ".join(DETECTORS) + " | FPR nhóm max s_C |",
         "|---|---|---|" + "---|" * len(DETECTORS) + "---|"]
    for day, rs in sorted(rs_by_day.items()):
        c3 = _mean([r["c3"]["s_C"].get("all", {}).get(f"alpha={gf:g}", {}).get("max_group_fpr") for r in rs])
        L.append(f"| {day} | {len(rs)} | {rs[0]['plan']['test_attack']:,} | "
                 + " | ".join(_pct(_mean([r["metrics"][d]["all"][key] for r in rs])) for d in DETECTORS)
                 + f" | {_pct(c3)}% |")
    wins = unique_wins(rs_by_day, g, key)
    good = [w for w in wins if w[4] >= g["unique_gain"]]
    L += ["", f"#### K1: lớp tấn công mà s_C hơn MỌI baseline (s_A, AE_conf, AE_C, IF_conf) ≥ "
              f"{100 * g['unique_gain']:.0f} điểm", ""]
    if good:
        L += ["| Ngày | Lớp | n | s_C | s_A | AE_conf | AE_C | IF_conf | Hơn |", "|---|---|---|---|---|---|---|---|---|"]
        L += [f"| {d} | {c} | {n:,} | " + " | ".join(_pct(v[x]) for x in ("s_C", "s_A", "AE_conf", "AE_C", "IF_conf"))
              + f" | {_pct(m)} |" for d, c, n, v, m in good]
    else:
        L.append("Không có lớp nào.")
    k1 = len(good) >= g["unique_pairs"]
    L += ["", f"K1: {len(good)} cặp (ngày, lớp), cần ≥ {g['unique_pairs']} → **{'đạt' if k1 else 'không đạt'}**", ""]

    # attacks
    k2 = None
    for thr in cfg["killtest"].get("threats", ["T1", "T2", "T3"]):
        rows, gaps, bef, aft = [], [], defaultdict(list), defaultdict(list)
        for day, rs in sorted(rs_by_day.items()):
            rr = [r["attacks"].get(thr) for r in rs if r["attacks"].get(thr)]
            if not rr:
                continue
            b = {d: _mean([x[d]["tpr_before"] for x in rr]) for d in DETECTORS}
            a = {d: _mean([x[d]["tpr_after"] for x in rr]) for d in DETECTORS}
            for d in DETECTORS:
                bef[d].append(b[d])
                aft[d].append(a[d])
            gaps.append(a["s_C"] - max(a[x] for x in BASELINES))
            rows.append(f"| {day} | " + " | ".join(f"{_pct(b[d])} → {_pct(a[d])}" for d in DETECTORS) + " |")
        if not rows:
            continue
        name = {"T1": "T1 — độn byte và đổi nhịp (kẻ tấn công vẫn giữ tấn công hoạt động)",
                "T2": "T2 — giả hành động benign cùng dịch vụ (giữ tốc độ/ngữ cảnh)",
                "T3": "T3 — giả cả hành động lẫn ngữ cảnh"}[thr]
        L += [f"#### {name}", "", f"TPR (%) tại FPR {gf:g}: trước → sau khi tấn công thích nghi theo từng bộ chấm.", "",
              "| Ngày | " + " | ".join(DETECTORS) + " |", "|---|" + "---|" * len(DETECTORS)] + rows
        L.append("| **Trung bình** | " + " | ".join(f"{_pct(_mean(bef[d]))} → {_pct(_mean(aft[d]))}"
                                                   for d in DETECTORS) + " |")
        if thr == g["k2_threat"]:
            gap = _mean(gaps)
            ret = {d: (_mean(aft[d]) / _mean(bef[d]) if _mean(bef[d]) > 0 else np.nan) for d in DETECTORS}
            k2 = bool(np.isfinite(gap) and gap >= g["k2_gain"] and np.isfinite(ret["s_C"])
                      and (not np.isfinite(ret["AE_conf"]) or ret["s_C"] >= ret["AE_conf"]))
            L += ["", f"K2 ({thr}): s_C sau tấn công hơn baseline mạnh nhất sau tấn công trung bình {_pct(gap)} điểm "
                      f"(cần ≥ {100 * g['k2_gain']:.0f}); tỉ lệ giữ TPR s_C {_pct(ret['s_C'])}% so với AE_conf "
                      f"{_pct(ret['AE_conf'])}% → **{'đạt' if k2 else 'không đạt'}**"]
        L.append("")
    return L, {"k1": k1, "k1_pairs": len(good), "k2": k2}


def write_kill_summary(root: Path, cfg: dict) -> Path:
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    res = collect(root)
    by = defaultdict(lambda: defaultdict(list))        # (dataset, label) -> day -> results
    for r in res:
        by[(r["dataset"], _label(r))][r["segment"]["label"]].append(r)
    g = cfg["gate_killtest"]
    main_profiles = [p for p in cfg["killtest"]["profiles"] if p != g["k3_profile"]]
    body, verdict = [], {}
    for (ds, label), days in sorted(by.items()):
        L, v = label_section(ds, label, days, cfg)
        body += L
        verdict[(ds, label)] = v
    head = ["# NetACWM v4 — kill test hướng A (consequence-verified NIDS)", "", "## Kết luận", ""]
    if not res:
        head.append("Chưa có kết quả trong outputs/killtest/.")
    for (ds, label), v in sorted(verdict.items()):
        base = label
        for p in main_profiles:
            if label.startswith(p):
                k3_label = g["k3_profile"] + label[len(p):]
                k3 = verdict.get((ds, k3_label), {}).get("k1")
                ok = v["k1"] and v["k2"] and k3
                head.append(f"- **{ds} / `{base}`: {'GO' if ok else 'STOP'}** — K1 {'đạt' if v['k1'] else 'không'} "
                            f"({v['k1_pairs']} cặp), K2 {'đạt' if v['k2'] else 'không' if v['k2'] is False else 'chưa có'}, "
                            f"K3 (`{k3_label}`) {'đạt' if k3 else 'không' if k3 is False else 'chưa có'}")
    head += ["", "GO khi cả K1, K2, K3 đạt. Ý nghĩa: K1 = world model bắt được thứ mà mọi detector không điều kiện "
             "bỏ sót; K2 = khi kẻ tấn công ngụy trang hành động, s_C vẫn hơn baseline mạnh nhất (kể cả AE_C, vốn không "
             "nhìn hành động nên không bị ngụy trang ảnh hưởng); K3 = kết quả K1 không dựa vào cổng đích.", ""]
    path = root / "summary.md"
    path.write_text("\n".join(head + body), encoding="utf-8")
    return path
