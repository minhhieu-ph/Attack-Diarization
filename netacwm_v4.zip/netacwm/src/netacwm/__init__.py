"""NetACWM: action-conditioned consequence world model for NetFlow intrusion detection."""
__version__ = "0.4.0"
