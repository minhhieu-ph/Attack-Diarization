"""v4 — kill test for direction A ("consequence-verified NIDS").

Claim to test: the attacker controls the ACTION fields of a flow (what the client sends, how
fast) but not the CONSEQUENCE fields (what the server answers). A detector that scores the
consequence GIVEN the action (s_C) should therefore (K1) catch attacks that unconditional
detectors miss and (K2) stay robust when the attacker disguises the action, where detectors
built on the action collapse. K3 repeats K1 without the destination port as a feature.

Setting = the time shift of v2 (CIC-IDS2018, one target day at a time): the models are trained
on the benign flows of all earlier days and calibrated on the first hour of the target day.

Detectors (higher = more anomalous, all conformal per service group):
  s_C      world model: surprise of the consequence given context + action
  s_A      autoencoder over context + action        (= "AE without the consequence fields")
  s_max    max(s_C, s_A)
  AE_conf  autoencoder over context + action + consequence ("AE with the consequence fields")
  AE_C     autoencoder over context + consequence    (looks at the consequence, ignores the action)
  IF_conf  isolation forest over context + action + consequence

Threat models (applied to the attack flows only; consequence fields are never changed):
  T1  padding and pacing: bytes x {1..8} (packets scaled or packed up to the MTU), timing x {0.5, 1, 2}
  T2  action mimicry: all numeric action fields and client TCP flags copied from a benign flow of
      the same service (taken from the calibration window); the flow rate (context) is kept
  T3  T2 plus the context (flow-rate features) of the same benign flow
Every attack is adaptive: for each detector separately the attacker keeps, per flow, the
candidate with the LOWEST score of that detector (the original flow is always a candidate).
Thresholds come from the clean benign test flows, so a lower attack score means a lower TPR.
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np

from . import __version__
from .e0 import Stream
from .envs import cap, cap_per_class, plan_target
from .features import Matrices, build, fit_vocab, n_port_codes
from .metrics import tpr_at_fpr
from .models import Autoencoder
from .schema import get_profile, target_category
from .scoring import MondrianConformal, ResidualScorer
from .shift import _labels, _norm, c3_check, evaluate, h1_arm, mats, take, time_targets, train_arm, xa
from .utils import LOG, check_memory, save_json, set_seed, timer

DETECTORS = ["s_C", "s_A", "s_max", "AE_conf", "AE_C", "IF_conf"]
BASELINES = ["s_A", "AE_conf", "AE_C", "IF_conf"]
THREATS = ["T1", "T2", "T3"]

SIZE, PKTS = "IN_BYTES", "IN_PKTS"
TIMES = ["DURATION_IN", "SRC_TO_DST_IAT_MIN", "SRC_TO_DST_IAT_MAX", "SRC_TO_DST_IAT_AVG", "SRC_TO_DST_IAT_STDDEV"]
RATES = ["SRC_TO_DST_SECOND_BYTES", "SRC_TO_DST_AVG_THROUGHPUT"]


# ---------------------------------------------------------------- detectors on a calibration window
class Fitted:
    """One trained arm + the AE_C baseline, calibrated on a benign window (fit / ref halves)."""

    def __init__(self, arm, ae_c: Autoencoder, fit: Matrices, ref: Matrices, cfg: dict):
        sc = cfg["shift"]
        mg = int(sc["scoring_min_group"])
        self.arm, self.ae_c = arm, ae_c
        Rf = arm.Y(fit) - arm.cond.predict(xa(fit))
        Rr = arm.Y(ref) - arm.cond.predict(xa(ref))
        self.rs = ResidualScorer(scale_floor=float(sc["scale_floor"])).fit(Rf, fit.group, Rr, ref.group, mg)
        self.conf = {
            "s_A": MondrianConformal().fit(arm.ae_act.score(xa(ref)), ref.group, mg),
            "AE_conf": MondrianConformal().fit(arm.ae_full.score(self._full(ref)), ref.group, mg),
            "AE_C": MondrianConformal().fit(ae_c.score(self._cy(ref)), ref.group, mg),
            "IF_conf": MondrianConformal().fit(arm.iforest.score(self._full(ref)), ref.group, mg),
        }

    def _full(self, m):
        return np.hstack([m.ctx, m.act, self.arm.Y(m)])

    def _cy(self, m):
        return np.hstack([m.ctx, self.arm.Y(m)])

    def score(self, m: Matrices, which=DETECTORS) -> dict[str, np.ndarray]:
        which = set(which)
        out = {}
        if which & {"s_C", "s_max"}:
            out["s_C"] = self.rs.score(self.arm.Y(m) - self.arm.cond.predict(xa(m)), m.group)
        if which & {"s_A", "s_max"}:
            out["s_A"] = self.conf["s_A"].score(self.arm.ae_act.score(xa(m)), m.group)
        if "s_max" in which:
            out["s_max"] = np.maximum(out["s_C"], out["s_A"])
        if "AE_conf" in which:
            out["AE_conf"] = self.conf["AE_conf"].score(self.arm.ae_full.score(self._full(m)), m.group)
        if "AE_C" in which:
            out["AE_C"] = self.conf["AE_C"].score(self.ae_c.score(self._cy(m)), m.group)
        if "IF_conf" in which:
            out["IF_conf"] = self.conf["IF_conf"].score(self.arm.iforest.score(self._full(m)), m.group)
        return {k: out[k] for k in DETECTORS if k in which}


# ---------------------------------------------------------------- threat models
def action_layout(names_act: list[str], prof) -> dict:
    col = {n: i for i, n in enumerate(names_act)}
    num = {c: col[f"a_{c.lower()}"] for c in prof.action_num if f"a_{c.lower()}" in col}
    flags = [i for i, n in enumerate(names_act) if n.startswith("a_cflag_")]
    return {"num": num, "flags": flags, "replace": sorted(list(num.values()) + flags)}


def t1_grid(kcfg: dict) -> list[tuple]:
    g = [(float(s), mode, float(t)) for s in kcfg["t1_size"] for mode in ("scale", "pack") for t in kcfg["t1_time"]]
    return [(1.0, "pack", 1.0)] + [x for x in g if x != (1.0, "pack", 1.0)]   # original first


def _t1_block(act: np.ndarray, lay: dict, grid, mtu: float) -> np.ndarray:
    """(n, d) action rows -> (n * len(grid), d) padded / paced variants, flow-major order.
    Action numerics are log1p(value); variants are computed on the raw scale."""
    n = len(act)
    out = np.repeat(act[:, None, :], len(grid), axis=1)
    num = lay["num"]
    raw = {c: np.expm1(act[:, j].astype(np.float64)) for c, j in num.items()}
    for k, (s, mode, tau) in enumerate(grid):
        if SIZE in num:
            b = raw[SIZE] * s
            out[:, k, num[SIZE]] = np.log1p(b)
            if PKTS in num:
                p = raw[PKTS] * s if mode == "scale" else np.maximum(raw[PKTS], np.ceil(b / mtu))
                out[:, k, num[PKTS]] = np.log1p(p)
        for c in TIMES:
            if c in num:
                out[:, k, num[c]] = np.log1p(raw[c] * tau)
        for c in RATES:
            if c in num:
                out[:, k, num[c]] = np.log1p(raw[c] * s / tau)
    return out.reshape(n * len(grid), -1).astype(np.float32)


class DonorPool:
    """Benign flows of the calibration window, indexed by service group (fallback: protocol, all)."""

    def __init__(self, donors: Matrices, n_port: int, min_donors: int):
        self.m = donors
        g = donors.group.astype(np.int64)
        self.by_group = {int(k): np.flatnonzero(g == k) for k in np.unique(g)}
        self.by_proto = {int(k): np.flatnonzero(g // n_port == k) for k in np.unique(g // n_port)}
        self.all = np.arange(len(g))
        self.n_port, self.min = n_port, min_donors

    def pick(self, groups: np.ndarray, k: int, rng) -> np.ndarray:
        """(n, k) donor row indices; the first column is unused (reserved for the original flow)."""
        out = np.empty((len(groups), k), dtype=np.int64)
        for g in np.unique(groups):
            rows = np.flatnonzero(groups == g)
            pool = self.by_group.get(int(g))
            if pool is None or len(pool) < self.min:
                pool = self.by_proto.get(int(g) // self.n_port)
            if pool is None or len(pool) < self.min:
                pool = self.all
            out[rows] = pool[rng.integers(0, len(pool), size=(len(rows), k))]
        return out


def candidates(threat: str, att: Matrices, lay: dict, pool: DonorPool, kcfg: dict, rng):
    """Candidate matrices for a chunk of attack flows: (Matrices with n * K rows, K)."""
    n = len(att.rows)
    if threat == "T1":
        grid = t1_grid(kcfg)
        K = len(grid)
        act = _t1_block(att.act, lay, grid, float(kcfg["mtu"]))
        ctx = np.repeat(att.ctx, K, axis=0)
    else:
        K = int(kcfg["donors_k"]) + 1
        idx = pool.pick(att.group, K, rng)
        act = np.repeat(att.act[:, None, :], K, axis=1)
        ctx = np.repeat(att.ctx[:, None, :], K, axis=1)
        rep = lay["replace"]
        d_act = pool.m.act[idx[:, 1:]]                      # (n, K-1, d)
        act[:, 1:, rep] = d_act[:, :, rep]
        if threat == "T3":
            ctx[:, 1:, :] = pool.m.ctx[idx[:, 1:]]
        act = act.reshape(n * K, -1)
        ctx = ctx.reshape(n * K, -1)
    m = Matrices(np.repeat(att.rows, K), ctx, act, np.repeat(att.y, K, axis=0), np.repeat(att.group, K),
                 att.names_ctx, att.names_act, att.names_y)
    return m, K


def attack_scores(fitted: Fitted, att: Matrices, threat: str, lay: dict, pool: DonorPool, kcfg: dict,
                  rng) -> dict[str, np.ndarray]:
    """Per detector: the lowest score the attacker can reach for each attack flow."""
    K = len(t1_grid(kcfg)) if threat == "T1" else int(kcfg["donors_k"]) + 1
    per = max(1, int(kcfg["chunk_rows"]) // K)
    out = {d: np.empty(len(att.rows)) for d in DETECTORS}
    for s in range(0, len(att.rows), per):
        idx = np.arange(s, min(s + per, len(att.rows)))
        cm, K = candidates(threat, take(att, idx), lay, pool, kcfg, rng)
        sc = fitted.score(cm)
        for d in DETECTORS:
            out[d][idx] = sc[d].reshape(len(idx), K).min(axis=1)
    return out


# ---------------------------------------------------------------- one target day
def run_kill(cfg: dict, st: Stream, seg_index: int, segs, profile: str, seed: int, device: str) -> dict:
    t0 = time.time()
    set_seed(seed)
    rng = np.random.default_rng(seed)
    sc, kc = cfg["shift"], cfg["killtest"]
    n_jobs = int(cfg["compute"]["n_jobs"])
    prof = get_profile(profile)
    seg = segs[seg_index]
    plan = plan_target(st.df, seg.t0, sc, rng, t_stop=seg.t1, t_start=seg.t0)
    LOG.info("[kill %s/%s/%s/seed%d] plan %s", st.name, seg.label, profile, seed,
             {k: v for k, v in plan.summary.items() if k != "test_attack_per_class"})
    hist = cap(plan.history, sc["max_train_per_env"], rng)
    vocab = fit_vocab(st.df, hist, cfg, prof)
    raw = build(st.df, hist, st.ctx, st.ctx_names, st.c2, st.c2_names, vocab, prof)
    norm = _norm(cfg, raw.ctx, seed)
    raw.ctx = norm.transform(raw.ctx)
    with timer("build target matrices"):
        fit, ref, test = (mats(st, r, vocab, prof, norm) for r in (plan.cal_fit, plan.cal_ref, plan.test))
    arm = train_arm("hist", raw, cfg, device, seed, n_jobs, with_ctx=False)
    with timer("[hist] autoencoder context+consequence (AE_C)"):
        ae_c = Autoencoder(cfg["models"]["ae"], device, seed).fit(np.hstack([raw.ctx, arm.Y(raw)]))
    del raw
    fitted = Fitted(arm, ae_c, fit, ref, cfg)
    with timer("score clean test"):
        clean = fitted.score(test)
    lab, att, fam = _labels(st, plan.test)
    ben = ~lab
    metrics, per_class = evaluate(clean, lab, att, fam, cfg["eval"]["fprs"], cfg["eval"]["gate_fpr"])
    t_test = st.df["t"].values[plan.test]
    c3 = {s: c3_check(clean[s], ben, test.group, t_test, plan.cal_end, sc["c3_horizons_sec"], sc["c3_alphas"],
                      sc["c3_min_n_factor"], vocab) for s in ("s_C", "s_max")}
    tb = np.flatnonzero(ben)
    tb = tb if len(tb) <= sc["r2_eval_max"] else np.sort(rng.choice(tb, sc["r2_eval_max"], replace=False))
    h1 = h1_arm(arm, take(test, tb), fit)

    # ---- adaptive attacks on a capped subset of the attack flows
    gf = cfg["eval"]["gate_fpr"]
    ai = np.flatnonzero(lab)
    ai = cap_per_class(ai, att[ai], kc["attack_eval_per_class"], rng)
    attacks = {}
    if len(ai):
        lay = action_layout(test.names_act, prof)
        donors = Matrices(np.r_[fit.rows, ref.rows], np.vstack([fit.ctx, ref.ctx]), np.vstack([fit.act, ref.act]),
                          np.vstack([fit.y, ref.y]), np.r_[fit.group, ref.group], fit.names_ctx, fit.names_act,
                          fit.names_y)
        pool = DonorPool(donors, n_port_codes(vocab), int(kc["min_donors"]))
        am = take(test, ai)
        cls = att[ai]
        for thr in kc.get("threats", THREATS):
            with timer(f"attack {thr} on {len(ai):,} flows"):
                adv = attack_scores(fitted, am, thr, lay, pool, kc, rng)
            res = {}
            for d in DETECTORS:
                sb = clean[d][ben]
                res[d] = {"tpr_before": tpr_at_fpr(sb, clean[d][ai], gf), "tpr_after": tpr_at_fpr(sb, adv[d], gf),
                          "per_class_after": {str(c): tpr_at_fpr(sb, adv[d][cls == c], gf) for c in np.unique(cls)},
                          "per_class_before": {str(c): tpr_at_fpr(sb, clean[d][ai][cls == c], gf)
                                               for c in np.unique(cls)}}
            attacks[thr] = res
    check_memory(cfg, "kill test")
    return {"version": __version__, "experiment": "killtest", "dataset": st.name, "segment": seg.as_dict(),
            "profile": profile, "seed": seed, "device": device, "regressor_backend": arm.cond.backend,
            "regressor_device": getattr(arm.cond, "used_device", "cpu"), "ae_backend": arm.ae_act.backend,
            "plan": plan.summary, "n_attack_eval": int(len(ai)), "families": st.family,
            "target_category": {n: target_category(n) for n in test.names_y},
            "n_features": {"context": test.ctx.shape[1], "action": test.act.shape[1], "targets": int(arm.active.sum())},
            "h1": h1, "metrics": metrics, "per_class": per_class, "c3": c3, "attacks": attacks,
            "seconds": round(time.time() - t0, 1)}


def run_kill_dataset(cfg: dict, name: str, profiles, seeds, device: str, out_root: Path, force=False, only=None,
                     tag: str = "") -> list[Path]:
    st = Stream(cfg, name)
    segs, targets = time_targets(cfg, st)
    LOG.info("%s: targets %s", name, [segs[i].label for i in targets])
    written = []
    for i in targets:
        if only is not None and segs[i].label not in only:
            continue
        for prof in profiles:
            for s in seeds:
                path = out_root / name / segs[i].label / f"{prof}{tag}_seed{s}.json"
                if path.exists() and not force:
                    continue
                res = run_kill(cfg, st, i, segs, prof, s, device)
                res["tag"] = tag
                save_json(res, path)
                gf = f"tpr@{cfg['eval']['gate_fpr']:g}"
                msg = " | ".join(f"{d} {res['metrics'][d]['all'][gf]:.3f}" for d in DETECTORS
                                 if res["metrics"][d]["all"][gf] is not None)
                t2 = res["attacks"].get("T2", {})
                msg2 = " | ".join(f"{d} {t2[d]['tpr_after']:.3f}" for d in DETECTORS if d in t2)
                LOG.info("[kill %s/%s/%s%s/seed%d] clean: %s || T2: %s | %.0fs", name, segs[i].label, prof, tag, s,
                         msg, msg2, res["seconds"])
                written.append(path)
    return written
